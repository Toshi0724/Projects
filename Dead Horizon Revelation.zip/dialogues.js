'use strict';
/* ================= DEAD HORIZON: REVELATION — DIALOGUE TREES =================
   Node shape: { who, text: string|(S=>string), opts:[{label, tag?, next?, cha?, karma?,
   trust?, action?, ending?, showIf?:(S=>bool)}] }
   The engine hides any option whose showIf(S) returns false. `action` strings are
   matched in runDialogueAction(); `action` beginning with 'recruit_' is handled
   generically (recruits COMPANIONS[id]). */

const DIALOGUES = {

 camp_leader: {
  start: {
   who: `Camp Leader — Elias Marsh`,
   text: (S)=>{
    if(S.flags.camp_siege_active) return `Hold the line, comrade! Keep clearing them out — Bo and Nikita up in the towers have your back.`;
    if(!S.flags.camp_cleared) return `Another face. Good — we need it. Listen, comrade — this camp's crawling with more of them than we can handle alone. Could you lend us a hand clearing it out? Bo and Nikita will cover you from the towers.`;
    if(!S.flags.doctor_quest_given) return `Good to see a friendly face. This camp's still standing because of what you did. Actually — before you go, we picked up something on the radio you should hear about.`;
    if(S.flags.boss_defeated && !S.flags.harrowed_reported) return `You're back. You look like a person carrying news. Well?`;
    if(S.flags.harrowed_reported) return `Truck's fueled and waiting whenever you're ready to go, comrade. Nobody's in a hurry to talk you out of it.`;
    return `Good to see a friendly face. This camp's still standing because of what you did.`;
   },
   opts: [
    {label:`I'll help you clear it out.`, action:'start_camp_siege', showIf:(S)=> !S.flags.camp_siege_active && !S.flags.camp_cleared},
    {label:`Not yet.`, showIf:(S)=> !S.flags.camp_siege_active && !S.flags.camp_cleared},
    {label:`Back to it.`, showIf:(S)=> S.flags.camp_siege_active},
    {label:`The Harrowed is dead.`, next:'harrowed_report', showIf:(S)=> S.flags.camp_cleared && S.flags.boss_defeated && !S.flags.harrowed_reported},
    {label:`What do you need done?`, next:'need', showIf:(S)=>S.flags.camp_cleared && !(S.flags.boss_defeated && !S.flags.harrowed_reported)},
    {label:`What is this place?`, next:'about', showIf:(S)=>S.flags.camp_cleared},
    {label:`What happened out there?`, tag:'Lore', next:'ridge', showIf:(S)=>S.flags.camp_cleared},
    {label:`You mentioned a distress signal?`, next:'doctor_intro', showIf:(S)=> S.flags.camp_cleared && !S.flags.doctor_quest_given},
    {label:`Just looking around.`, showIf:(S)=>S.flags.camp_cleared}
   ]
  },
  harrowed_report:{
   who:`Elias Marsh`,
   text:`(He goes very quiet for a second.) Say that again.`,
   opts:[{label:`It's dead. Whatever RVL-9 was, it's not getting up again.`, next:'harrowed_report2'}]
  },
  harrowed_report2:{
   who:`Elias Marsh`,
   text:`I don't — I don't know what to do with that. Three years of running from that thing's shadow and you're telling me it's just... over. There's an old cargo truck we've kept fueled since before you got here, for exactly this. Nobody really believed we'd need it. Get anything you still want to carry — once that truck rolls out, we're not coming back for it.`,
   opts:[{label:`Let's get everyone out.`, action:'report_harrowed'}]
  },
  need: {
   who:`Elias Marsh`,
   text:`Joe can outfit you if you've got tokens to spare. Past that? Keep breathing. That's most of the job now.`,
   opts:[{label:`Understood.`, cha:1}]
  },
  about:{
   who:`Elias Marsh`,
   text:`Sixty-some of us, behind a fence made of car doors and prayer. We had two hundred, first month. Camp holds because people like you made it hold.`,
   opts:[{label:`Back to business.`, next:'start'}]
  },
  ridge:{
   who:`Elias Marsh`,
   text:`Revelation Biotech ran a facility up on the north ridge. Whatever they were building got out three days before the news called it an "isolated health event." Find the answers if you want them. I stopped needing them to sleep at night.`,
   opts:[{label:`Back to business.`, next:'start'}]
  },
  doctor_intro:{
   who:`Elias Marsh`,
   text:`We picked up a distress signal two nights back, off St. Mercy Hospital's old emergency band. Voice on it claimed to be a Dr. Voss — begged for anyone still out there to come get her. I can't spare the people to check it out. Could you head to the hospital, find her, and bring her back here alive?`,
   opts:[
    {label:`I'll find her.`, action:'accept_doctor_quest'},
    {label:`Not right now.`, next:'start'}
   ]
  }
 },

 joe_intro:{
  start:{
   who:`Joe`,
   text:`Tokens or trade, friend, doesn't matter to me. Guns, gear, armor, packs — whatever's still standing in this county, I can probably get you a piece of it.`,
   opts:[
    {label:`Let's trade.`, action:'open_trade'},
    {label:`I found gold bars.`, next:'gold_confirm', showIf:(S)=> S.inventory.some(i=>i.id==='gold_bars')},
    {label:`Where's Elias, anyway?`, next:'where_leader'},
    {label:`Just passing through.`}
   ]
  },
  gold_confirm:{
   who:`Joe`,
   text:(S)=>{ const g=S.inventory.find(i=>i.id==='gold_bars'); return `Gold, huh. Can't spend it, can't eat it — but I know someone who'll take it off your hands. ${g?g.qty:0} bars, I'll give you 100 tokens flat for the lot.`; },
   opts:[
    {label:`Deal.`, action:'exchange_gold'},
    {label:`Not yet.`, next:'start'}
   ]
  },
  where_leader:{
   who:`Joe`,
   text:(S)=> S.flags.camp_cleared ? `Just go to the camp hall, and you'll meet our camp leader.` : `Somewhere around camp, probably chewing on the fence line. Hard to miss him.`,
   opts:[{label:`Thanks.`, next:'start'}]
  }
 },

 hospital_doctor:{
  start:{
   who:`Dr. Voss (through the door)`,
   text:(S)=>{
    if(findInv(S,'hospital_keycard')) return `Thank God, someone came to save me. Wait — is that an access card? That's it, that's exactly it! Please, use it on the door panel!`;
    return `Thank God, someone came to save me. You need to find my access keycard. I might have dropped it somewhere inside the hospital because of the chaos. And I think I'm the only one alive. Can you please help me?`;
   },
   opts:[
    {label:`Use the keycard to free her.`, tag:'Karma +', next:'save_confirm', showIf:(S)=>!!findInv(S,'hospital_keycard')},
    {label:`I'll find your keycard.`, showIf:(S)=>!findInv(S,'hospital_keycard')},
    {label:`Not my problem.`, tag:'Karma −', next:'abandon_confirm'}
   ]
  },
  save_confirm:{
   who:`Dr. Voss`,
   text:`Thank you. I mean that. Whatever's left of this county, it's going to need people willing to open doors instead of walking past them. I'll follow you back to safety — just say the word when you're ready to move.`,
   opts:[{label:`Let's go.`, action:'hospital_save'}]
  },
  abandon_confirm:{
   who:`Dr. Voss`,
   text:`Wait — WAIT! You can't just — I have information about RVL-9 that could— The voice fades as you walk away.`,
   opts:[{label:`Keep moving.`, action:'hospital_abandon'}]
  }
 },

 /* Generic "locked door" inner-monologue, reused by every keycard/key-gated
    room (vault, armory, bunker, etc). engine.js sets `lockedDoorContext`
    (the door's description + the item needed) right before opening this,
    same pattern as the hospital door above but reusable anywhere. */
 locked_room:{
  start:{
   who:`You`,
   text:(S)=> {
    const ctx = lockedDoorContext || {};
    return (ctx.doorText||'This door is locked tight.')+` I need to find ${ctx.itemName||'the right keycard'} to get through here — there should be one somewhere around this place.`;
   },
   opts:[{label:`Keep looking.`}]
  }
 },
 read_board:{
  start:{
   who:`Notice`,
   text:(S)=> boardReadContext || '...',
   opts:[{label:`Move on.`}]
  }
 },


 warehouse_bandit:{
  start:{
   who:`Kade`,
   text:(S)=> S.flags.warehouse_choice ? `Back again. This floor's still ours — same terms as last time, if you're asking.` : `This floor's ours now. Turn around, pay a toll, or find out the hard way what happens to people who don't do either.`,
   opts:[
    {label:`I'm not paying anybody.`, tag:'Fight', next:'fight_confirm'},
    {label:`What's the toll?`, tag:'Peace', next:'peace_confirm'},
    {label:`What if I worked with you instead?`, tag:'Corrupt', next:'corrupt_confirm'}
   ]
  },
  fight_confirm:{ who:`Kade`, text:`Wrong answer. Everybody up!`, opts:[{label:`Ready weapon.`, action:'warehouse_fight'}] },
  peace_confirm:{ who:`Kade`, text:`Smart. Hand over some of what you're carrying, and this whole floor's yours to loot in peace.`, opts:[{label:`Deal.`, action:'warehouse_peace'}] },
  corrupt_confirm:{ who:`Kade`, text:`Now that's a language I speak. Keep your mouth shut about what you see here and there's tokens in it for you.`, opts:[{label:`Wouldn't dream of it.`, action:'warehouse_corrupt'}] }
 },

 warehouse_guard:{
  start:{
   who:`Kade's Guard`,
   text:(S)=>{
    if(S.flags.warehouse_choice==='fight') return `You've got some nerve showing your face back here. Kade wants you gone — or dead.`;
    return `Nothing personal, friend. Kade runs a tight floor and pays on time. Long as you don't start trouble, neither will we.`;
   },
   opts:[{label:(S)=> S.flags.warehouse_choice==='fight' ? `...` : `Understood.`}]
  }
 },

 ruins_trader:{
  start:{
   who:`Milo`,
   text:`Hey, hey — good gear, good prices, no questions. Interested?`,
   opts:[
    {label:`Take a closer look at his stock.`, next:'investigate'},
    {label:`Not interested.`}
   ]
  },
  investigate:{
   who:`Milo`,
   text:`The serial numbers are filed off. The "medicine" is loose pills in a sandwich bag. This isn't salvage — it's a trap for anyone desperate enough not to look twice.`,
   opts:[
    {label:`Call him out.`, tag:'Expose', next:'expose_confirm'},
    {label:`Say nothing. Walk away.`, tag:'Ignore', next:'ignore_confirm'}
   ]
  },
  expose_confirm:{ who:`Milo`, text:`He doesn't even deny it — just shrugs and starts packing up. "Word'll get around now. Fine. Plenty other buyers in this county."`, opts:[{label:`Leave.`, action:'ruins_expose'}] },
  ignore_confirm:{ who:`Milo`, text:`He slips you a little something for keeping quiet. "Pleasure doing business. Or not doing it, in this case."`, opts:[{label:`Leave.`, action:'ruins_ignore'}] }
 },

 ghost_story:{
  start:{
   who:`???`,
   text:`Something pale moves between the headstones — there and gone, always at the edge of the flashlight beam. It doesn't attack. It doesn't flee. It just watches.`,
   opts:[ {label:`Follow it.`, next:'follow'}, {label:`Leave it alone.`} ]
  },
  follow:{
   who:`???`,
   text:`It leads you to a small, freshly-dug plot with no headstone — just a child's pillow, soaked through, laid gently on the dirt. When you look up, whatever was watching you is gone.`,
   opts:[{label:`Take the pillow. Someone should remember this.`, action:'ghost_easter_egg'}]
  }
 },

 boss_intro:{
  start:{
   who:`???`,
   text:`The access door reads DEEP LAB — RESTRICTED in stenciled amber paint. Beyond it, something huge is breathing in the dark, slow and wet and much too aware of the door opening.`,
   opts:[ {label:`This is what you came for. Go in.`, action:'start_boss'}, {label:`...Not yet.`} ]
  }
 },

 final_choice:{
  start:{
   who:`???`,
   text:`The Harrowed stops moving. Past its ruin of a body, a console still blinks, patient, waiting on a decision three days of dying never got to make: what happens to RVL-9 now.`,
   opts:[
    {label:`Burn the samples. Burn all of it.`, tag:'Good', ending:'good'},
    {label:`Take the samples. Someone will pay.`, tag:'Bad', ending:'bad'},
    {label:`Seal the lab. Walk away.`, tag:'Neutral', ending:'neutral'}
   ]
  }
 }

};

/* ---------- Companion recruitment + bonding, generated per COMPANIONS entry ---------- */
const COMPANION_FLAVOR = {
 john:    {ask:`Ask how he's really doing.`,       resp:`Honestly? Some nights I still expect the radio to say this is over. It won't. But the fence held, and that's something. Thanks for asking.`, greet:`Fence held again last night. Barely. You holding up out there?`},
 alexa:   {ask:`Ask about her old life.`,            resp:`Dad taught me to hunt before I could ride a bike. Never thought I'd be grateful for it like this.`, greet:`You've got that look — counting whether the ammo you've got will outlast the ammo you'll need.`},
 rorke:   {ask:`Ask what he did before all this.`,   resp:`Moved furniture. Big trucks, bad backs, decent pay. Nobody trains you for this. You just find out what you can carry when you have to.`, greet:`(Cleaning the SAW, not looking up.) You need something, or you just like watching a man work?`},
 nikolai: {ask:`Sit with him a while.`,               resp:`(He doesn't say much. Neither do you. It helps anyway.) This is good. We should do this again — assuming, you know. Everything.`, greet:`You look like a person who needs to sit down and not think for five minutes.`},
 dana:    {ask:`Ask what keeps her going now.`,      resp:`Keeping this crew alive. That's it, that's the whole answer. Used to pour drinks so people felt looked-after for one night. Turns out I just kept doing that.`, greet:`(Wiping down the SPAS like it's a bar top out of habit.) Don't ask me about before.`}
};

COMPANIONS.forEach(c=>{
 const flav = COMPANION_FLAVOR[c.id];
 DIALOGUES['companion_'+c.id] = {
  start:{
   who: c.name,
   text:(S)=>{
    if(S.companions.includes(c.id)){
     if(S.companionResting && S.companionResting[c.id]) return `${c.name} is resting up at camp. "Say the word and I'm ready to move."`;
     return flav.greet;
    }
    const cost = companionRecruitCost(S.companions.length);
    if(cost===null) return `${c.name} nods at you but stays put. "Squad's full up. Camp needs me right where I am."`;
    const unit = cost.type==='karma' ? 'Karma' : 'Tokens';
    const have = cost.type==='karma' ? S.karma : S.tokens;
    if(have >= cost.amount) return `${c.name} looks you over. "Word gets around, you know — about what you do out there. I'd follow that." (Costs ${cost.amount} ${unit} — you have ${have})`;
    return `${c.name} shrugs. "Ask me again once you've done more good out there than harm." (Needs ${cost.amount} ${unit} — you have ${have})`;
   },
   opts:[
    {label:flav.ask, trust:1, next:'response', showIf:(S)=>S.companions.includes(c.id) && !(S.companionResting && S.companionResting[c.id])},
    {label:`Rest here at camp for now.`, action:'rest_'+c.id, showIf:(S)=>S.companions.includes(c.id) && !(S.companionResting && S.companionResting[c.id])},
    {label:`Ready to go?`, action:'follow_'+c.id, showIf:(S)=>S.companions.includes(c.id) && !!(S.companionResting && S.companionResting[c.id])},
    {label:(S)=>{ const cost=companionRecruitCost(S.companions.length); const unit=cost.type==='karma'?'Karma':'Tokens'; return `Recruit them (−${cost.amount} ${unit})`; }, action:'recruit_'+c.id, showIf:(S)=>{
      const cost = companionRecruitCost(S.companions.length);
      if(!cost) return false;
      const have = cost.type==='karma' ? S.karma : S.tokens;
      return !S.companions.includes(c.id) && have>=cost.amount;
     }},
    {label:`Nothing right now.`}
   ]
  },
  response:{
   who:c.name, text:flav.resp,
   opts:[{label:`Take care of yourself.`}]
  }
 };
});

/* ---------- SURVIVOR QUEST-GIVERS (generated per SURVIVOR_NPCS entry) ---------- */
SURVIVOR_NPCS.forEach(n=>{
 DIALOGUES['survivor_'+n.id] = {
  start:{
   who: n.name,
   text:(S)=> S.flags['survivor_done_'+n.id] ? n.doneText : n.askText,
   opts:[
    {label:`Good to see a friendly face.`, action:'survivor_meet_'+n.id, cha:1, showIf:(S)=>!S.flags['survivor_met_'+n.id]},
    {label:`Here — ${n.want.label}.`, action:'survivor_turnin_'+n.id, showIf:(S)=> !S.flags['survivor_done_'+n.id]},
    {label:`Not yet. I'll keep an eye out.`, showIf:(S)=> !S.flags['survivor_done_'+n.id]},
    {label:`Take care of yourself.`, showIf:(S)=> !!S.flags['survivor_done_'+n.id]}
   ]
  }
 };
});

/* ---------- MILITARY BLOCKADE TRADER ---------- */
DIALOGUES.blockade_trader = {
 start:{
  who:`Quartermaster Duval`,
  text:`Guns and ammunition, that's the whole inventory — Blockade command doesn't authorize me to carry anything else. If it fires a round, I can probably get you one.`,
  opts:[
   {label:`Let's see the armory.`, action:'open_trade_blockade'},
   {label:`Just passing through.`}
  ]
 }
};

/* ---------- CAMP DOCTOR ---------- */
DIALOGUES.camp_doctor = {
 start:{
  who:`Dr. Voss`,
  text:`Good to have a proper infirmary going again. What do you need?`,
  opts:[
   {label:`Patch me up. (Costs Tokens)`, action:'doctor_heal'},
   {label:`Let's see your medicine.`, action:'open_trade_doctor'},
   {label:`Here — some medicine for the camp.`, action:'doctor_fetch_supplies'},
   {label:`Just saying hi.`}
  ]
 }
};

/* ---------- MILITARY BLOCKADE BACKGROUND NPCS ---------- */
DIALOGUES.military_patrol = {
 start:{
  who:`Soldier`,
  text:`Keep your head down out there. Convoy's not due for another few days.`,
  opts:[{label:`Will do.`}]
 }
};
DIALOGUES.tower_sentry = {
 start:{
  who:`Watch Sentry`,
  text:`Nothing's getting past this checkpoint. Not on my watch.`,
  opts:[{label:`Good to know.`}]
 }
};
