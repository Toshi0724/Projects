'use strict';
/* ================= DEAD HORIZON: REVELATION — DATA ================= */

/* ---------- SURVIVORS ---------- */
const SURVIVORS = [
 {id:'ana',name:'Ana',role:'Doctor',color:'#8ab82f',skin:'#e0b088',hair:'#2b2116',hairStyle:'bun',accessory:'headband',END:4,AGI:5,STR:4,PER:7,STA:5,perk:'Field Kit — healing items restore +15% more HP.',kit:['bandage','ninemm'],startWeapon:'ninemm',startAmmo:{mm9:16}},
 {id:'robbie',name:'Robbie',role:'Engineer',color:'#e8b23d',skin:'#c98a55',hair:'#1a1a1a',hairStyle:'short',accessory:'goggles',END:5,AGI:4,STR:7,PER:6,STA:4,perk:'Jury-Rig — reload speed +15%.',kit:['wrench'],startWeapon:'wrench'},
 {id:'aika',name:'Aika',role:'Teen',color:'#3fa0d8',skin:'#f0c8a0',hair:'#402010',hairStyle:'ponytail',accessory:'beanie',END:4,AGI:8,STR:3,PER:6,STA:6,perk:'Light on Her Feet — sprint stamina drain −15%.',kit:['knife'],startWeapon:'knife'},
 {id:'jack',name:'Jack',role:'Lumberjack',color:'#a4341f',skin:'#c98a55',hair:'#5a3010',hairStyle:'beard',accessory:'none',END:6,AGI:5,STR:8,PER:3,STA:5,perk:'Timber — melee weapons deal +20% damage.',kit:['axe'],startWeapon:'axe'},
 {id:'axel',name:'Axel',role:'Army',color:'#556b2f',skin:'#a56a3a',hair:'#0f0f0f',hairStyle:'buzz',accessory:'helmet',END:8,AGI:5,STR:6,PER:5,STA:6,perk:'Drilled — ranged spread −15%.',kit:['ninemm'],startWeapon:'ninemm',startAmmo:{mm9:16}},
 {id:'jasmine',name:'Jasmine',role:'Police',color:'#c94a2e',skin:'#e0b088',hair:'#1a1008',hairStyle:'tied',accessory:'cap',END:5,AGI:6,STR:5,PER:7,STA:5,perk:'Trained Reflexes — 6% chance to avoid melee damage.',kit:['ninemm'],startWeapon:'ninemm',startAmmo:{mm9:16}},
 {id:'james',name:'James',role:'Firefighter',color:'#c1541c',skin:'#8a5a35',hair:'#100a05',hairStyle:'short',accessory:'fireHelmet',END:8,AGI:5,STR:6,PER:4,STA:6,perk:'Smoke Trained — infection severity rises 20% slower.',kit:['sledgehammer'],startWeapon:'sledgehammer'},
 {id:'stacey',name:'Stacey',role:'Citizen',color:'#dcd6bd',skin:'#f0c8a0',hair:'#8a6a24',hairStyle:'long',accessory:'none',END:5,AGI:5,STR:5,PER:5,STA:5,perk:'Adaptable — all XP gain +10%.',kit:['bat'],startWeapon:'bat'},
 {id:'cory',name:'Cory',role:'Builder',color:'#e8b23d',skin:'#a56a3a',hair:'#3a2412',hairStyle:'short',accessory:'hardhat',END:6,AGI:4,STR:8,PER:4,STA:5,perk:'Load Bearer — +10 carrying capacity.',kit:['pitchfork'],startWeapon:'pitchfork'},
 {id:'akira',name:'Akira',role:'Hacker',color:'#3fa0d8',skin:'#e0b088',hair:'#101010',hairStyle:'short',accessory:'headphones',END:4,AGI:5,STR:3,PER:9,STA:5,perk:'Analyst — +15% chance to find rare loot.',kit:['knife'],startWeapon:'knife'}
];

/* ---------- COMPANIONS (recruited at camp, gated by karma) ---------- */
const COMPANIONS = [
 {id:'john',name:'John',color:'#8ab82f',skin:'#c98a55',hair:'#1a1208',weapon:'m16',glyph:'👤',bonus:'Squad Discipline — +8% accuracy for the whole party.'},
 {id:'alexa',name:'Alexa',color:'#3fa0d8',skin:'#e0b088',hair:'#3a2210',weapon:'hunting_rifle',glyph:'👤',bonus:"Spotter — +15% chance to find rare loot while she's with you."},
 {id:'rorke',name:'Rorke',color:'#a4341f',skin:'#8a5a35',hair:'#0a0a0a',weapon:'saw',glyph:'👤',bonus:'Suppressing Fire — reduces incoming damage by 10% while active.'},
 {id:'nikolai',name:'Nikolai',color:'#c94a2e',skin:'#c98a55',hair:'#2a1a0a',weapon:'ak47',glyph:'👤',bonus:"Overrun — your party kills zombies 10% faster."},
 {id:'dana',name:'Dana',color:'#e8b23d',skin:'#e0b088',hair:'#4a2a10',weapon:'spas12',glyph:'👤',bonus:'Close Quarters — +12% stealth kill chance on unaware enemies.'}
];
/* Karma cost to recruit the Nth companion (order-independent — costs rise with how many you already have) */
const COMPANION_KARMA_COST = [10, 25, 50, 100];
/* The 5th and final companion is recruited with Tokens instead of Karma */
const COMPANION_FIFTH_COST = 150;
function companionRecruitCost(idx){
 if(idx < COMPANION_KARMA_COST.length) return {type:'karma', amount:COMPANION_KARMA_COST[idx]};
 if(idx === COMPANION_KARMA_COST.length) return {type:'tokens', amount:COMPANION_FIFTH_COST};
 return null;
}

/* ---------- AMMO ---------- */
const AMMO_TYPES = {
 mm9:{name:'9mm Rounds', icon:'🔸'},
 mm9_ap:{name:'Pistol AP Rounds', icon:'🔺'},
 magnum:{name:'Magnum Rounds', icon:'🔶'},
 rifle:{name:'Rifle Rounds', icon:'🔹'},
 rifle_ap:{name:'Rifle AP Rounds', icon:'🔻'},
 shells:{name:'Shotgun Shells', icon:'🟠'},
 rocket:{name:'Rocket Rounds', icon:'🚀'}
};
/* AP (armor-piercing) rounds are a separate reserve pool from their base
   caliber. reloadActive() draws normal ammo first and only dips into AP as
   overflow, and it's strictly caliber-locked: pistol AP only ever loads into
   a weapon whose `ammo` is 'mm9', rifle AP only into 'rifle' — see
   AP_AMMO_FOR below, which is the single source of truth so a pistol can
   never accidentally chamber rifle AP rounds or vice versa. */
const AP_AMMO_FOR = { mm9:'mm9_ap', rifle:'rifle_ap' };
const AP_DAMAGE_MULT = 1.10;

/* ---------- WEAPONS ---------- */
/* Melee: dmg, range(px), cooldownMs, swing{type:'arc'|'thrust', arcDeg, reach}, price */
const WEAPONS_MELEE = {
 fists:      {id:'fists',      name:'Fists',          icon:'✊', dmg:4,  range:30, cooldown:450, swing:{type:'arc', arcDeg:70, reach:30}, price:0, stamina:0},
 knife:      {id:'knife',      name:'Knife',          icon:'🔪',        dmg:10, range:28, cooldown:280, swing:{type:'arc', arcDeg:50, reach:28}, price:14, stamina:3},
 wrench:     {id:'wrench',     name:'Wrench',         icon:'🔧',       dmg:11, range:34, cooldown:460, swing:{type:'arc', arcDeg:70, reach:34}, price:17, stamina:4},
 bat:        {id:'bat',        name:'Baseball Bat',   icon:'🏏',          dmg:14, range:42, cooldown:500, swing:{type:'arc', arcDeg:100,reach:42}, price:21, stamina:5},
 axe:        {id:'axe',        name:'Axe',            icon:'🪓',          dmg:18, range:40, cooldown:600, swing:{type:'arc', arcDeg:80, reach:40}, price:29, stamina:7},
 pitchfork:  {id:'pitchfork',  name:'Pitchfork',      icon:'🍴',    dmg:16, range:55, cooldown:550, swing:{type:'thrust',arcDeg:20, reach:55}, price:25, stamina:6},
 scythe:     {id:'scythe',     name:'Scythe',         icon:'☠️',       dmg:20, range:50, cooldown:650, swing:{type:'arc', arcDeg:130,reach:50}, price:46, cleave:true, stamina:8},
 sledgehammer:{id:'sledgehammer',name:'Sledgehammer', icon:'🔨', dmg:32, range:46, cooldown:950, swing:{type:'arc', arcDeg:90, reach:46}, price:52, stamina:11},
 pillow:     {id:'pillow',      name:'Pillow',         icon:'🛏️', dmg:1,  range:30, cooldown:300, swing:{type:'arc', arcDeg:80, reach:30}, price:0, stamina:0}
};

/* Ranged: dmg per shot, range, fire cooldown, magSize, reloadMs, ammo type, projectile speed(px/s), spread(deg), price */
const WEAPONS_RANGED = {
 ninemm:        {id:'ninemm',        name:'9mm',            icon:'🔫',        slot:'secondary', dmg:14, range:320, cooldown:230, mag:12, reload:850,  ammo:'mm9',    pspeed:640, spread:4, price:40},
 revolver:      {id:'revolver',      name:'.357 Magnum',    icon:'🔫',      slot:'secondary', dmg:26, range:370, cooldown:500, mag:6,  reload:1250, ammo:'magnum', pspeed:640, spread:3, price:65},
 hunting_rifle: {id:'hunting_rifle', name:'Hunting Rifle',  icon:'🎯',slot:'primary',   dmg:36, range:560, cooldown:750, mag:5,  reload:1500, ammo:'rifle',  pspeed:900, spread:1, price:95},
 ak47:          {id:'ak47',          name:'AK-47',          icon:'🔫', slot:'primary',   dmg:20, range:460, cooldown:150, mag:30, reload:1800, ammo:'rifle',  pspeed:820, spread:5, price:110},
 m16:           {id:'m16',           name:'M16',            icon:'🔫', slot:'primary',   dmg:18, range:460, cooldown:135, mag:30, reload:1700, ammo:'rifle',  pspeed:820, spread:4, price:105},
 scar:          {id:'scar',          name:'SCAR',           icon:'🔫',           slot:'primary',   dmg:24, range:480, cooldown:140, mag:20, reload:1600, ammo:'rifle',  pspeed:840, spread:3, price:135},
 m1garand:      {id:'m1garand',      name:'M1 Garand',      icon:'🎖️',           slot:'primary',   dmg:34, range:520, cooldown:520, mag:8,  reload:1700, ammo:'rifle',  pspeed:880, spread:2, price:125},
 spas12:        {id:'spas12',        name:'SPAS-12',        icon:'🔫',        slot:'primary',   dmg:44, range:220, cooldown:650, mag:8,  reload:1600, ammo:'shells', pspeed:700, spread:10,price:100},
 saw:           {id:'saw',           name:'M249 SAW',       icon:'🔫',           slot:'primary',   dmg:16, range:480, cooldown:95,  mag:100,reload:3000, ammo:'rifle',  pspeed:820, spread:6, price:170},
 rpg:           {id:'rpg',           name:'RPG',            icon:'🚀',           slot:'rocket',    dmg:150,range:520, cooldown:1200,mag:1,  reload:3000, ammo:'rocket', pspeed:520, spread:0, price:260, splash:90},
 /* Military Blockade exclusives */
 deagle:        {id:'deagle',        name:'Desert Eagle',   icon:'🔫',           slot:'secondary', dmg:32, range:350, cooldown:540, mag:7,  reload:1300, ammo:'magnum', pspeed:660, spread:3, price:120, exclusive:'blockade'},
 awm:           {id:'awm',           name:'AWM',            icon:'🎯',           slot:'primary',   dmg:70, range:720, cooldown:1150,mag:5,  reload:1900, ammo:'rifle',  pspeed:1000,spread:0, price:340, exclusive:'blockade'},
 barrett:       {id:'barrett',       name:'.50 Cal Barrett',icon:'🎯',           slot:'primary',   dmg:95, range:760, cooldown:1500,mag:5,  reload:2200, ammo:'rifle',  pspeed:1050,spread:0, price:420, exclusive:'blockade'},
 law:           {id:'law',           name:'LAW',            icon:'🚀',           slot:'rocket',    dmg:175,range:540, cooldown:1400,mag:1,  reload:3200, ammo:'rocket', pspeed:540, spread:0, price:300, splash:100, exclusive:'blockade'},
 plasma_rifle:  {id:'plasma_rifle',  name:'Plasma Rifle',   icon:'💠',           slot:'rocket',    dmg:130,range:640, cooldown:180, mag:999,reload:0,    ammo:null,     pspeed:1100,spread:0, price:0, reward:true}
};

/* Throwables: dmg, splash radius, fuseMs (0 = on impact), price */
const WEAPONS_THROWABLE = {
 grenade: {id:'grenade', name:'Frag Grenade', icon:'💣', dmg:60, splash:80, fuse:1400, price:25},
 molotov: {id:'molotov', name:'Molotov',      icon:'🧨', dmg:30, splash:70, fuse:0,    price:20, burn:true},
 pipebomb:{id:'pipebomb',name:'Pipe Bomb',    icon:'🧨', dmg:85, splash:100,fuse:2200, price:32}
};

function findWeaponById(id){
 return WEAPONS_MELEE[id] || WEAPONS_RANGED[id] || WEAPONS_THROWABLE[id] || null;
}
function weaponCategory(id){
 if(WEAPONS_MELEE[id]) return 'melee';
 if(WEAPONS_RANGED[id]) return 'ranged';
 if(WEAPONS_THROWABLE[id]) return 'throwable';
 return null;
}

/* ---------- ARMOR ---------- */
const ARMOR = {
 civilian: {id:'civilian', name:'Civilian Set', icon:'🧥', reduction:0.15, durability:60,  price:40},
 hunter:   {id:'hunter',   name:'Hunter Set',   icon:'🥾', reduction:0.30, durability:90,  price:50},
 police:   {id:'police',   name:'Police Set',   icon:'🛡️', reduction:0.50, durability:130, price:70},
 army:     {id:'army',     name:'Army Set',     icon:'🎖️', reduction:0.75, durability:180, price:100},
 assault:  {id:'assault',  name:'Assault Set',  icon:'🪖', reduction:0.95, durability:250, price:150},
 cbrn:     {id:'cbrn',     name:'CBRN Suit',    icon:'☣️', reduction:0.55, durability:220, price:200, infectionImmune:true}
};

/* ---------- BACKPACKS ---------- */
const BACKPACK_BASE_CAPACITY = 50;
const BACKPACKS = {
 school:   {id:'school',   name:'School Backpack',  icon:'🎒', bonus:10, price:20},
 mountain: {id:'mountain', name:'Mountain Backpack',icon:'🎒', bonus:30, price:45},
 tactical: {id:'tactical', name:'Tactical Backpack',icon:'🎒', bonus:50, price:80},
 exo:      {id:'exo',      name:'Exo Bag',          icon:'🧰', bonus:150, speedBonus:2, price:0, reward:true}
};

/* ---------- CONSUMABLES ---------- */
/* buff: {stat, mult|add, ms} applied temporarily; cure: status key cured */
const DRINKS = {
 popcola:   {id:'popcola',   name:'Pop Cola',    icon:'🥤', thirst:25, price:6},
 nukacola:  {id:'nukacola',  name:'Nuka Cola',   icon:'☢️', thirst:15, price:14, buff:{stat:'healRegen', mult:2, ms:10000}},
 megacrusher:{id:'megacrusher',name:'MegaCrusher',icon:'🥤', thirst:10, price:16, buff:{stat:'meleeDmg', mult:1.10, ms:60000}},
 royal:     {id:'royal',     name:'Royal',       icon:'🥤', thirst:30, price:10, buff:{stat:'staminaRegen', mult:1.20, ms:30000}},
 drprepper: {id:'drprepper', name:'Dr. Prepper',icon:'🥤', thirst:20, price:12, cure:'sick'},
 fitz:      {id:'fitz',      name:'Fitz',        icon:'🥤', thirst:20, price:12, buff:{stat:'staminaMax', add:10, ms:45000}},
 kvas:      {id:'kvas',      name:'Kvas',        icon:'🍺', thirst:25, price:9,  hunger:10}
};
const FOODS = {
 jerky:   {id:'jerky',   name:'Beef Jerky',   icon:'🥓', hunger:20, price:10},
 bread:   {id:'bread',   name:'Bread',        icon:'🍞', hunger:15, price:7},
 protein: {id:'protein', name:'Protein Bar',  icon:'🍫', hunger:18, price:11, buff:{stat:'staminaRegen', mult:1.15, ms:30000}},
 chips:   {id:'chips',   name:'Chips',        icon:'🍟', hunger:10, price:5},
 rice:    {id:'rice',    name:'Rice',         icon:'🍚', hunger:25, price:9},
 mre:     {id:'mre',     name:'MRE',          icon:'🍱', hunger:50, thirst:50, price:26}
};
const MEDS = {
 bandage:    {id:'bandage',    name:'Bandage',     icon:'🩹', heal:5,  price:8,  cure:'bleeding'},
 medkit:     {id:'medkit',     name:'Medkit',      icon:'💊', heal:40, price:22, cure:'sick'},
 antibiotics:{id:'antibiotics',name:'Antibiotics', icon:'💉', heal:8,  price:30, cure:'infected_early'},
 serum:      {id:'serum',      name:'Serum',       icon:'🧬', heal:10, price:0,  cure:'infected', rare:true}
};
/* Armor-Piercing Rounds: temporary damage boosts, sold only at the Military Blockade */
const BUFF_ITEMS = {
 ap_pistol: {id:'ap_pistol', name:'AP Rounds (Pistol)', icon:'🔺', price:45, exclusive:'blockade', buff:{stat:'apPistolDmg', mult:1.35, ms:90000}},
 ap_rifle:  {id:'ap_rifle',  name:'AP Rounds (Rifle)',  icon:'🔻', price:60, exclusive:'blockade', buff:{stat:'apRifleDmg',  mult:1.35, ms:90000}}
};
function findConsumableById(id){ return DRINKS[id]||FOODS[id]||MEDS[id]||BUFF_ITEMS[id]||null; }
/* ---------- KEYCARDS ----------
   A generic, reusable framework: each location can declare a `keycardDrop`
   id from this registry. One crate spawns holding it somewhere in that
   location until found. The card is consumed the moment it unlocks whatever
   it gates — after that, the place it opened stays open for the rest of
   the game (tracked via a S.flags['keycard_used_'+id] style flag). */
const KEYCARDS = {
 hospital_keycard: {id:'hospital_keycard', name:'Hospital Access Card', icon:'🪪', desc:"A laminated St. Mercy Hospital staff access card, still on its lanyard."},
 bank_keycard: {id:'bank_keycard', name:'Bank Vault Keycard', icon:'🪪', desc:"A manager's keycard, still warm from someone's pocket."},
 police_armory_key: {id:'police_armory_key', name:'Armory Key', icon:'🗝️', desc:"A heavy brass key, tagged ARMORY in the chief's handwriting."},
 ridge_keycard: {id:'ridge_keycard', name:'Level 1 Access Keycard', icon:'🪪', desc:"A Revelation Biotech clearance card, Level 1 — enough to reach the bunker door."},
 ridge_keycard_l2: {id:'ridge_keycard_l2', name:'Level 2 Access Keycard', icon:'🪪', desc:"Pried from the Harrowed's ruined console. Deeper clearance than anything else in the facility."}
};
function findKeycardById(id){ return KEYCARDS[id]||null; }

/* ---------- STATUS EFFECTS ---------- */
/* ---------- ZOMBIE VARIANTS ----------
   threat: rough tier used for spawn-pool gating by location danger.
   hpMult/speedMult/dmgMult scale the location's base zombie stats.
   weapon: a WEAPONS_MELEE/WEAPONS_RANGED id purely for the glyph shown when
   this variant is rendered — enemies don't use the player weapon system. */
const ZOMBIE_VARIANTS = {
 walker:   {id:'walker',   name:'Walker',              glyph:'🧟', threat:1, hpMult:1.0, speedMult:1.0,  dmgMult:1.0},
 labor:    {id:'labor',    name:'Labor Zombie',        glyph:'👷', threat:1, hpMult:1.1, speedMult:0.85, dmgMult:1.0},
 nurse:    {id:'nurse',    name:'Nurse Zombie',        glyph:'👩‍⚕️', threat:1, hpMult:0.9, speedMult:1.05, dmgMult:1.0, weapon:'knife'},
 scavenger:{id:'scavenger',name:'Scavenger Zombie',    glyph:'🎒', threat:1, hpMult:0.9, speedMult:1.1,  dmgMult:0.95,weapon:'knife'},
 miner:    {id:'miner',    name:'Miner Zombie',        glyph:'⛏️', threat:2, hpMult:1.3, speedMult:0.85, dmgMult:1.3, weapon:'scythe'},
 mechanic: {id:'mechanic', name:'Mechanic Zombie',     glyph:'🧑‍🔧',threat:2, hpMult:1.2, speedMult:0.95, dmgMult:1.1, weapon:'wrench'},
 baseball: {id:'baseball', name:'Baseball Zombie',     glyph:'⚾', threat:2, hpMult:1.1, speedMult:1.15, dmgMult:1.15,weapon:'bat'},
 butcher:  {id:'butcher',  name:'Butcher Zombie',      glyph:'🔪', threat:2, hpMult:1.35,speedMult:0.9,  dmgMult:1.3, weapon:'knife'},
 screamer: {id:'screamer', name:'Screamer Zombie',     glyph:'😱', threat:2, hpMult:0.8, speedMult:1.05, dmgMult:0.7, scream:true},
 dog:      {id:'dog',      name:'Zombie Dog',          glyph:'🐕', threat:2, hpMult:0.65,speedMult:1.9,  dmgMult:0.9},
 fireman:  {id:'fireman',  name:'Fireman Zombie',      glyph:'🧯', threat:3, hpMult:1.4, speedMult:0.9,  dmgMult:1.25,weapon:'axe'},
 police:   {id:'police',   name:'Police Zombie',       glyph:'👮', threat:3, hpMult:1.3, speedMult:0.9,  dmgMult:1.0, weapon:'revolver', ranged:true},
 medic:    {id:'medic',    name:'Medic Soldier Zombie',glyph:'⚕️', threat:3, hpMult:1.2, speedMult:0.9,  dmgMult:0.85,weapon:'ninemm',   ranged:true},
 soldier:  {id:'soldier',  name:'Soldier Zombie',      glyph:'🪖', threat:4, hpFlat:300, speedMult:0.9,  dmgMult:1.1, weapon:'ak47',      ranged:true},
 tank:     {id:'tank',     name:'Tank Zombie',         glyph:'🧟', threat:5, hpFlat:5000,speedMult:0.6, dmgMult:3.0, ranged:true, throws:true, charge:true, rare:true}
};

/* ---------- BANDIT VARIANTS ----------
   armor is cosmetic flavor (shown via bandana/tint), the real toughness
   comes from hpMult. weapon drives both the glyph and, for ranged/throws
   variants, their attack pattern. */
const BANDIT_VARIANTS = {
 grunt:      {id:'grunt',      name:'Bandit',                glyph:'🏴', threat:1, weapon:'knife',    armor:null,      hpMult:1.0, speedMult:1.15, dmgMult:1.0},
 hooded:     {id:'hooded',     name:'Hooded Bandit',         glyph:'🏴', threat:2, weapon:'revolver', armor:null,      hpMult:1.0, speedMult:0.9,  dmgMult:1.0, ranged:true},
 grenadier:  {id:'grenadier',  name:'Grenadier Bandit',      glyph:'💣', threat:3, weapon:'pipebomb', armor:'civilian',hpMult:1.1, speedMult:0.9,  dmgMult:1.4, throws:true},
 light_armor:{id:'light_armor',name:'Light Armored Bandit',  glyph:'🏴', threat:3, weapon:'scar',     armor:'hunter',  hpMult:1.5, speedMult:0.95, dmgMult:1.1, ranged:true},
 captain:    {id:'captain',    name:'Bandit Captain',        glyph:'🎖️', threat:4, weapon:'m1garand', armor:'hunter',  hpMult:1.9, speedMult:0.95, dmgMult:1.3, ranged:true},
 heavy_armor:{id:'heavy_armor',name:'Heavy Armored Bandit',  glyph:'🏴', threat:5, weapon:'saw',       armor:'police',  hpMult:2.6, speedMult:0.8,  dmgMult:1.15,ranged:true}
};

/* ---------- TROPHIES ----------
   Kill enough of a given variant, then claim a permanent stat boost. Several
   variants feed the same boost so there's more than one path to each one. */
const TROPHY_BOOSTS = {
 hp:      {name:'Iron Constitution', icon:'❤️',  desc:'+15 Max HP'},
 crit:    {name:'Killer Instinct',   icon:'🎯',  desc:'+5% Critical Hit Chance'},
 accuracy:{name:'Steady Hands',      icon:'🧭',  desc:'-15% Weapon Spread'},
 loot:    {name:"Scavenger's Eye",   icon:'📦',  desc:'+15% Bonus Loot Chance'},
 armor:   {name:'Hardened',          icon:'🛡️',  desc:'+10% Damage Reduction'},
 speed:   {name:'Fleet of Foot',     icon:'👟',  desc:'+10% Movement Speed'},
 carry:   {name:'Pack Mule',         icon:'🎒',  desc:'+15 Carry Capacity'},
 melee:   {name:'Brute Force',       icon:'💪',  desc:'+12% Melee Damage'},
 ranged:  {name:'Marksmanship',      icon:'🔫',  desc:'+12% Ranged Damage'}
};
const TROPHY_DEFS = {
 labor:      {threshold:300, boost:'carry'},
 miner:      {threshold:300, boost:'melee'},
 fireman:    {threshold:300, boost:'armor'},
 mechanic:   {threshold:300, boost:'speed'},
 baseball:   {threshold:300, boost:'crit'},
 police:     {threshold:200, boost:'accuracy'},
 soldier:    {threshold:100, boost:'ranged'},
 medic:      {threshold:200, boost:'hp'},
 nurse:      {threshold:200, boost:'loot'},
 butcher:    {threshold:200, boost:'melee'},
 scavenger:  {threshold:200, boost:'loot'},
 screamer:   {threshold:100, boost:'accuracy'},
 dog:        {threshold:200, boost:'speed'},
 tank:       {threshold:50,  boost:'armor'},
 grunt:      {threshold:300, boost:'melee'},
 hooded:     {threshold:200, boost:'accuracy'},
 grenadier:  {threshold:100, boost:'armor'},
 light_armor:{threshold:100, boost:'ranged'},
 captain:    {threshold:100, boost:'crit'},
 heavy_armor:{threshold:100, boost:'hp'}
};
function trophyDisplayName(vid){
 return (ZOMBIE_VARIANTS[vid]||BANDIT_VARIANTS[vid]||{}).name || vid;
}

const STATUS_INFO = {
 bleeding: {name:'Bleeding', icon:'🩸', desc:'Losing HP over time. Cure with a Bandage.'},
 infected: {name:'Infected', icon:'🦠', desc:'Worsens over time. Antibiotics helps early; Serum cures it outright.'},
 sick:     {name:'Sick',     icon:'🤢', desc:'Reduced stamina regen. Cure with a Medkit or Dr. Prepper.'},
 hungry:   {name:'Starving', icon:'🍽️', desc:'Hunger depleted — losing HP over time. Eat something.'},
 dehydrated:{name:'Dehydrated',icon:'💧', desc:'Thirst depleted — losing HP over time. Drink something.'}
};

/* ---------- SKILL TREE (levels go to 100, 1 skill point per level) ---------- */
const SKILL_TREE = {
 survivor:[
  {id:'field_medic', name:'Field Medic', cost:1, desc:'Healing items restore +20% more HP.'},
  {id:'iron_gut', name:'Iron Gut', cost:1, desc:'Hunger and thirst deplete 25% slower.'},
  {id:'fast_metabolism', name:'Fast Metabolism', cost:2, req:'iron_gut', desc:'Food and drink items restore +20% more.'},
  {id:'thick_skin', name:'Thick Skin', cost:2, desc:'+20 maximum HP.'},
  {id:'packmule', name:'Packmule', cost:2, desc:'+15 carrying capacity.'},
  {id:'armorer', name:'Armorer', cost:3, desc:'Equipped armor reduction +5% (flat), durability lasts 20% longer.'},
  {id:'scavenger', name:"Scavenger's Eye", cost:2, desc:'+15% chance to find rare loot.'},
  {id:'iron_lungs', name:'Iron Lungs', cost:2, desc:'Infection severity rises 30% slower.'},
  {id:'second_wind', name:'Second Wind', cost:3, desc:'Once per run, survive a killing blow at 1 HP.'}
 ],
 agility:[
  {id:'sprinter', name:'Sprinter', cost:1, desc:'Sprint speed +10%.'},
  {id:'light_feet', name:'Light Feet', cost:1, desc:'Sprint stamina drain −15%.'},
  {id:'fleet_footed', name:'Fleet Footed', cost:2, req:'light_feet', desc:'Stamina regeneration +20%.'},
  {id:'quick_hands', name:'Quick Hands', cost:2, desc:'Reload speed +20%.'},
  {id:'evasive', name:'Evasive', cost:2, desc:'8% chance to avoid incoming melee damage entirely.'},
  {id:'silent_steps', name:'Silent Steps', cost:2, desc:'Zombie aggro range reduced 25%.'}
 ],
 weapons:[
  {id:'melee_mastery', name:'Melee Mastery', cost:1, desc:'Melee damage +15%.'},
  {id:'marksman', name:'Marksman', cost:1, desc:'Ranged damage +15%.'},
  {id:'steady_aim', name:'Steady Aim', cost:2, req:'marksman', desc:'Ranged spread −25%.'},
  {id:'ammo_efficiency', name:'Ammo Efficiency', cost:2, desc:'12% chance to not consume ammo when firing.'},
  {id:'berserker', name:'Berserker', cost:2, desc:'Melee attack cooldown −15%.'},
  {id:'heavy_hands', name:'Heavy Hands', cost:3, desc:'Rocket and SAW damage +20%.'},
  {id:'demolitionist', name:'Demolitionist', cost:2, desc:'Throwable blast radius +25%.'},
  {id:'executioner', name:'Executioner', cost:3, req:'melee_mastery', desc:'+25% damage to enemies below 25% HP.'}
 ]
};
function xpToNext(level){ return Math.round(80 * Math.pow(level, 1.55)); }
const MAX_LEVEL = 100;

/* ---------- ACHIEVEMENTS ---------- */
const ACHIEVEMENTS = [
 {id:'first_blood', name:'First Blood', icon:'🩸', desc:'Kill your first zombie.'},
 {id:'exterminator', name:'Exterminator', icon:'💀', desc:'Kill 50 zombies.'},
 {id:'pack_rat', name:'Pack Rat', icon:'🎒', desc:'Carry 40+ units of items at once.'},
 {id:'silver_tongue', name:'Silver Tongue', icon:'💬', desc:'Reach 15 Charisma.'},
 {id:'good_samaritan', name:'Good Samaritan', icon:'🤝', desc:'Reach 30 Karma.'},
 {id:'hard_case', name:'Hard Case', icon:'😈', desc:'Reach −15 Karma.'},
 {id:'iron_will', name:'Iron Will', icon:'❤️', desc:'Survive a fight at 5 HP or less.'},
 {id:'complete_journal', name:'Complete Journal', icon:'📖', desc:'Find every journal page.'},
 {id:'armory_complete', name:'Armory Complete', icon:'🔫', desc:'Own 5 different ranged weapons.'},
 {id:'squad_goals', name:'Squad Goals', icon:'👥', desc:'Recruit all 5 possible companions.'},
 {id:'hardened_survivor', name:'Hardened Survivor', icon:'🏆', desc:'Reach level 25.'},
 {id:'old_habits', name:'Old Habits', icon:'🕹️', desc:'???'},
 {id:'fully_geared', name:'Fully Geared', icon:'🪖', desc:'Equip the Assault Set and a Tactical Backpack.'},
 {id:'bandit_hunter', name:'Bandit Hunter', icon:'🏴', desc:'Kill 25 bandits.'},
 {id:'camp_defender', name:'Camp Defender', icon:'🏕️', desc:'Clear 20 zombies from the Survivor Camp.'},
 {id:'first_page', name:'Paper Trail', icon:'📄', desc:'Find your first journal page.'},
 {id:'side_hustler', name:'Side Hustler', icon:'🗒️', desc:'Complete 10 side quests.'},
 {id:'well_traveled', name:'Well Traveled', icon:'🧭', desc:'Set foot in every location on the map.'}
];

/* ---------- JOURNAL PAGES (story collectibles) ----------
   Each page is found at exactly one location — one spawns per matching site
   until picked up. Reading them all unlocks the Complete Journal achievement. */
const JOURNAL_PAGES = [
 {id:'j1', loc:'suburbs', title:'Evacuation Notice — Day 1', text:`"RESIDENTS ARE ADVISED TO SHELTER IN PLACE." That's the flyer, stapled crooked to half the doors on this block. Somebody's kids drew on the back of theirs before they left — a stick-figure family, a sun, a dog. I hope they made it out. I hope the dog did too.`},
 {id:'j2', loc:'hospital', title:'Ward 3 — Admission Log', text:`Seventeen admissions in six hours, all with the same fever, the same tremor in the left hand before it spreads. Dr. Voss keeps saying "contain the ward," but the ward is the whole building now. Whatever RVL-9 is, it doesn't read triage charts.`},
 {id:'j3', loc:'warehouse', title:"Kade's Ledger", text:`Tally marks in a torn notebook — supplies taken, tolls collected, names crossed out. Near the back, one line stands apart, underlined twice: "Not becoming what's out there. Just surviving it." Whoever wrote it seems to be arguing with themselves.`},
 {id:'j4', loc:'ruins', title:'Old Town Marker', text:`A hand-painted sign, half burned: WELCOME TO OLD TOWN — SETTLED 1891. Somebody's added underneath, in fresher paint: STILL HERE. BARELY. The town square behind it is rubble, but the sign's still standing.`},
 {id:'j5', loc:'quarantine_zone', title:'CDC Field Memo', text:`"RVL-9 is not influenza-class. Recommend Revelation Biotech's onsite containment protocols be treated as classified pending review." The rest of the page is redacted in thick black marker — except one line someone circled by hand: "They knew before we did."`},
 {id:'j6', loc:'bank', title:"Teller's Note", text:`Taped inside the vault door, written in shaking handwriting: "If you're reading this, the drawers are empty — we gave everything to the people still coming through the doors. Money's worthless now anyway. Take the water instead."`},
 {id:'j7', loc:'shipyard', title:"Dockhand's Radio Log", text:`"Last ship out left without half its manifest. Captain said weight limits, but everyone on the dock knew what he meant. Some of us just weren't chosen." The entry ends mid-sentence, like the writer meant to come back to it.`},
 {id:'j8', loc:'airport', title:'Black Box Transcript (Partial)', text:`"...ground control, we have movement in the cabin, repeat, movement in the— " Transcript ends there. The rest of the recording, according to a note clipped to the page, was "unrecoverable."`},
 {id:'j9', loc:'embassy', title:'Diplomatic Cable, Unsent', text:`A draft cable, never transmitted: "Advise immediate quarantine escalation to Level 4. Revelation Biotech representatives are no longer answering calls from this office." The signature line is blank.`},
 {id:'j10', loc:'military_base', title:'Dr. Marisol Reyes — Final Entry', text:`"RVL-9 was never supposed to leave containment. I told the board that regeneration without a kill switch was a weapon, not a cure. Nobody listened until it started walking. If anyone finds this: burn it. Burn all of it. There is no version of this worth saving."`},
 {id:'j11', loc:'police_station', title:'Dispatch Log, Final Shift', text:`"All units, all units, disregard previous callout priority — everything is a callout now." That's the last line in the dispatch log before the handwriting changes to someone else's, someone who just wrote: "held the desk as long as I could."`},
 {id:'j12', loc:'army_outpost', title:'Requisition Order, Denied', text:`A requisition form for reinforcements, stamped DENIED in red ink, with a note scrawled underneath: "No reinforcements exist anymore. You're the reinforcements. Hold what you can."`},
 {id:'j13', loc:'radio_station', title:'Broadcast Transcript, Hour 61', text:`"If anyone's still receiving this signal, the Blockade is holding on the county line. Head for the checkpoint, not the city." The transcript notes the broadcast looped automatically for three days after the operator stopped responding to check-ins.`},
 {id:'j14', loc:'church', title:'Guestbook, Last Page', text:`Names, dozens of them, signed under a single printed line: "You are safe here." Some entries are dated after the sign-in sheet clearly ran out of room, squeezed sideways into the margins by people who needed somewhere to write their name down.`},
 {id:'j15', loc:'city_hall', title:'Emergency Session Minutes', text:`Council minutes from what the clerk labeled "the last meeting," where the recorded vote was unanimous on exactly one motion: adjourn, and go find your families.`},
 {id:'j16', loc:'farm', title:"Tom's Ledger", text:`A weathered notebook tracking who took what from the farm's stores, no prices listed — just names and dates, and one line underlined twice: "Nobody starves on my land. Not while I'm still standing on it."`},
 {id:'j17', loc:'train_station', title:'Timetable, Hand-Amended', text:`The printed schedule has been crossed out entirely in marker, replaced with a single handwritten line: "No trains are coming. Walk if you have to. Just go."`},
 {id:'j18', loc:'quarantine_zone', special:true, title:'Subject Zero — Containment Failure Report', text:`CLASSIFIED — REVELATION BIOTECH INTERNAL / RIDGE FACILITY. Subject Zero, designation unrecorded, was the first controlled human trial for RVL-9's regenerative cascade. Tissue response exceeded projections within 48 hours — cellular repair continued long after the subject's baseline vitals should have flatlined. Containment believed this was a success. It was not: the regeneration never received a stop signal, and neither, it turned out, did the subject. What breached the lower levels three years ago was Subject Zero, still "healing," still moving, no longer anything the trial notes have a name for. Survivors on the surface have started calling it the Harrowed. Every case since traces back to exposure through it, directly or through the bitten. The compound doesn't infect identically twice — field autopsies log at least a dozen distinct presentations, laborers, medical staff, soldiers, even a K-9 unit, all sharing the same base pathology but expressing wildly different mutation, aggression, and durability. Whatever RVL-9 actually is, it stopped being a virus a long time ago. It's still deciding what it wants to be.`}
];
function findJournalPage(id){ return JOURNAL_PAGES.find(j=>j.id===id); }

/* ---------- LOCATIONS ---------- */
/* kit drives procedural prop layout in the engine. tier scales zombie/bandit strength & loot quality. */
const LOCATIONS = [
 {id:'suburbs', name:'Suburban Area', tier:1, kit:'suburbs', w:1400, h:1000, danger:'LOW', zRange:[4,7], banditChance:0.15, lootTier:1, ground:'grass'},
 {id:'camp', name:'Survivor Camp', tier:0, kit:'camp', w:1000, h:800, danger:'DEFEND', zRange:[1,3], banditChance:0, lootTier:0, noLoot:true, campDefense:true, ground:'dirt'},
 {id:'hospital', name:'St. Mercy Hospital', tier:2, kit:'hospital', w:1300, h:1000, danger:'MEDIUM', zRange:[6,10], banditChance:0.15, lootTier:2, ground:'stone', keycardDrop:'hospital_keycard'},
 {id:'warehouse', name:'Warehouse District', tier:2, kit:'warehouse', w:1400, h:1000, danger:'MEDIUM', zRange:[0,0], banditChance:0, lootTier:2, ground:'stone'},
 {id:'ruins', name:'Old Town Ruins', tier:2, kit:'ruins', w:1300, h:1000, danger:'MEDIUM', zRange:[6,9], banditChance:0.3, lootTier:2, ground:'dirt'},
 {id:'cemetery', name:'Cemetery', tier:1, kit:'cemetery', w:1100, h:900, danger:'LOW', zRange:[3,6], banditChance:0.05, lootTier:1, ground:'grass'},
 {id:'bus_station', name:'Bus Station', tier:1, kit:'bus_station', w:1100, h:900, danger:'LOW', zRange:[4,7], banditChance:0.1, lootTier:1, ground:'stone'},
 {id:'library', name:'Public Library', tier:1, kit:'library', w:1100, h:900, danger:'LOW', zRange:[3,6], banditChance:0.1, lootTier:1, ground:'stone'},
 {id:'supermarket', name:'Supermarket', tier:2, kit:'supermarket', w:1300, h:1000, danger:'MEDIUM', zRange:[6,10], banditChance:0.2, lootTier:2, ground:'stone'},
 {id:'bank', name:'Bank', tier:3, kit:'bank', w:1200, h:900, danger:'HIGH', zRange:[5,8], banditChance:0.5, lootTier:3, special:'vault_cracked', ground:'stone', keycardDrop:'bank_keycard'},
 {id:'parking_lot', name:'Parking Lot', tier:1, kit:'parking_lot', w:1300, h:1000, danger:'LOW', zRange:[4,7], banditChance:0.2, lootTier:1, ground:'stone'},
 {id:'quarantine_zone', name:'Quarantine Zone', tier:3, kit:'quarantine_zone', w:1400, h:1100, danger:'HIGH', zRange:[8,12], banditChance:0.25, lootTier:3, special:'quarantine_files', ground:'dirt'},
 {id:'shipyard', name:'Shipyard', tier:3, kit:'shipyard', w:1500, h:1100, danger:'HIGH', zRange:[7,11], banditChance:0.4, lootTier:3, ground:'stone'},
 {id:'airport', name:'Airport', tier:4, kit:'airport', w:1700, h:1200, danger:'VERY HIGH', zRange:[9,13], banditChance:0.35, lootTier:4, special:'black_box', ground:'stone'},
 {id:'embassy', name:'Embassy', tier:4, kit:'embassy', w:1300, h:1000, danger:'VERY HIGH', zRange:[7,10], banditChance:0.5, lootTier:4, special:'diplomatic_pouch', ground:'grass'},
 {id:'restaurant', name:'Roadside Diner', tier:1, kit:'restaurant', w:1000, h:800, danger:'LOW', zRange:[3,6], banditChance:0.1, lootTier:1, ground:'stone'},
 {id:'military_base', name:'North Ridge Facility', tier:5, kit:'military_base', w:2000, h:1500, danger:'EXTREME', zRange:[8,12], banditChance:0.3, lootTier:4, special:'boss_arena', locked:'both_choices', ground:'dirt', keycardDrop:'ridge_keycard'},
 {id:'police_station', name:'Police Station', tier:2, kit:'police_station', w:1200, h:900, danger:'MEDIUM', zRange:[5,8], banditChance:0.2, lootTier:2, ground:'stone', keycardDrop:'police_armory_key', special:'armory_unlocked'},
 {id:'army_outpost', name:'Military Base', tier:3, kit:'army_outpost', w:1400, h:1100, danger:'HIGH', zRange:[6,10], banditChance:0.3, lootTier:3, ground:'dirt'},
 {id:'radio_station', name:'Radio Station', tier:2, kit:'radio_station', w:1000, h:850, danger:'MEDIUM', zRange:[4,7], banditChance:0.15, lootTier:2, ground:'grass'},
 {id:'gas_station', name:'Gas Station', tier:1, kit:'gas_station', w:900, h:750, danger:'LOW', zRange:[3,5], banditChance:0.1, lootTier:1, ground:'stone'},
 {id:'church', name:'Church', tier:1, kit:'church', w:1000, h:850, danger:'LOW', zRange:[3,6], banditChance:0.05, lootTier:1, ground:'grass'},
 {id:'city_hall', name:'City Hall', tier:3, kit:'city_hall', w:1300, h:1000, danger:'HIGH', zRange:[6,9], banditChance:0.3, lootTier:3, ground:'stone'},
 {id:'military_blockade', name:'Military Blockade', tier:0, kit:'military_blockade', w:1200, h:900, danger:'SAFE', zRange:[0,0], banditChance:0, lootTier:0, noLoot:true, ground:'dirt'},
 {id:'farm', name:'Farm', tier:1, kit:'farm', w:1300, h:1000, danger:'LOW', zRange:[4,7], banditChance:0.1, lootTier:1, ground:'grass'},
 {id:'train_station', name:'Train Station', tier:2, kit:'train_station', w:1300, h:950, danger:'MEDIUM', zRange:[5,8], banditChance:0.2, lootTier:2, ground:'stone'},
 {id:'bandit_camp', name:'Bandit Camp', tier:3, kit:'bandit_camp', w:1300, h:1000, danger:'HIGH', zRange:[1,2], banditChance:1, lootTier:3, isBanditCamp:true, ground:'dirt'}
];
function findLocation(id){ return LOCATIONS.find(l=>l.id===id); }

/* ---------- SPECIAL POINTS (per-location scripted crates; NPC-resolved flags like
   hospital_choice/warehouse_choice/bad_trade/ghost_story are NOT here — those come
   from talking to an NPC, not looting a crate) ---------- */
const SPECIAL_POINTS = {
 bank:            {flag:'vault_cracked'},
 quarantine_zone: {flag:'quarantine_files'},
 airport:         {flag:'black_box'},
 embassy:         {flag:'diplomatic_pouch'},
 military_base:   {flag:'boss_arena'}
};

/* ---------- SURVIVOR QUEST-GIVERS (new locations) ----------
   Each wants a specific item brought to them. Turning it in grants +5 Karma
   and a random reward. Talking to them the first time grants +1 Charisma. */
const SURVIVOR_NPCS = [
 {id:'reyes',   loc:'police_station',   name:'Officer Reyes',   glyph:'👮', color:'#3fa0d8',
  want:{id:'bandage', qty:3, label:'3 Bandages'},
  askText:`We're out of first aid up here. If you find any bandages out there, my people could really use them.`,
  doneText:`Reyes gives you a nod. "Still holding the line up here, thanks to you."`,
  lackText:`You don't have enough bandages.`},
 {id:'cole',    loc:'army_outpost',     name:'Sgt. Cole',       glyph:'🪖', color:'#556b2f',
  want:{id:'ammo_rifle', qty:15, label:'15 Rifle Rounds'},
  askText:`Command went dark weeks ago. We're rationing rifle rounds down to nothing. Bring some and I'll make it worth your trip.`,
  doneText:`Cole taps his rifle. "Appreciate the resupply, soldier."`,
  lackText:`You don't have enough rifle rounds.`},
 {id:'wendell', loc:'radio_station',    name:'Wendell',         glyph:'📻', color:'#c1541c',
  want:{id:'bread', qty:4, label:'4 Bread'},
  askText:`Been broadcasting on batteries and stale bread for a week. If you've got food to spare, I'd owe you one.`,
  doneText:`Wendell gives a thumbs up through the studio glass. "Signal stays up because of you."`,
  lackText:`You don't have enough bread.`},
 {id:'hank',    loc:'gas_station',      name:'Hank',            glyph:'🔧', color:'#8a6a24',
  want:{id:'wrench', qty:1, label:'a Wrench'},
  askText:`Lost my good wrench trying to keep this place standing. Find me one and I'll square you up.`,
  doneText:`Hank spins the wrench in his hand. "Runs like new. Thanks for that."`,
  lackText:`You don't have a wrench.`},
 {id:'agnes',   loc:'church',           name:'Sister Agnes',    glyph:'✝️', color:'#dcd6bd',
  want:{id:'antibiotics', qty:2, label:'2 Antibiotics'},
  askText:`I've got sick folks sheltering here with nothing but prayer between them and infection. Antibiotics would help more.`,
  doneText:`Agnes presses her hands together. "Bless you for this. Truly."`,
  lackText:`You don't have enough antibiotics.`},
 {id:'owens',   loc:'city_hall',        name:'Clerk Owens',     glyph:'👤', color:'#8b8770',
  want:{id:'popcola', qty:4, label:'4 Pop Cola'},
  askText:`Still coming in to work, if you can believe that. Water's been out for days though — anything to drink would help.`,
  doneText:`Owens raises a bottle in your direction. "To getting through another day."`,
  lackText:`You don't have enough pop-cola.`},
 {id:'ibarra',  loc:'military_blockade',name:'Pvt. Ibarra',     glyph:'🎖️', color:'#3fa0d8',
  want:{id:'ammo_shells', qty:10, label:'10 Shotgun Shells'},
  askText:`Checkpoint's low on shotgun shells and command isn't sending resupply anytime soon. Help us out?`,
  doneText:`Ibarra checks the gate. "Blockade holds a little longer because of you."`,
  lackText:`You don't have enough shotgun shells.`},
 {id:'tom',     loc:'farm',             name:'Old Tom',         glyph:'👨‍🌾', color:'#8a6a24',
  want:{id:'rice', qty:5, label:'5 Rice'},
  askText:`Fields don't grow fast enough to feed everyone who's wandered up here. Spare rice would go a long way.`,
  doneText:`Tom tips his hat. "Debt repaid, and then some."`,
  lackText:`You don't have enough Rice.`},
 {id:'reeves',  loc:'train_station',    name:'Conductor Reeves',glyph:'🚂', color:'#c1541c',
  want:{id:'chips', qty:5, label:'5 Chips'},
  askText:`Train's not going anywhere, but the folks still holed up in these cars need to eat. Anything salty and packaged helps.`,
  doneText:`Reeves gives a two-fingered salute off his cap. "All aboard, whenever you're ready to move on."`,
  lackText:`You don't have enough Chips.`}
];
const NPC_MARKERS = {
 camp: [
  {id:'camp_leader', name:'Elias Marsh', x:320, y:350, glyph:'👤', color:'#e8b23d', dialogue:'camp_leader'},
  {id:'joe', name:'Joe', x:560, y:350, glyph:'💰', color:'#c1541c', dialogue:'joe_intro', trade:true}
  /* companions are appended dynamically by the engine based on COMPANIONS list */
 ],
 hospital: [ {id:'doctor', name:'Dr. Voss', x:990, y:370, glyph:'🚑', color:'#3fa0d8', dialogue:'hospital_doctor', once:'hospital_choice'} ],
 warehouse:[
  {id:'kade', name:'Kade', x:560, y:360, glyph:'☠', color:'#a4341f', dialogue:'warehouse_bandit'},
  {id:'guard1', name:"Kade's Guard", x:150, y:850, glyph:'🏴', color:'#a4341f', dialogue:'warehouse_guard', isWarehouseGuard:true, wander:true},
  {id:'guard2', name:"Kade's Guard", x:1250, y:120, glyph:'🏴', color:'#a4341f', dialogue:'warehouse_guard', isWarehouseGuard:true, wander:true},
  {id:'guard3', name:"Kade's Guard", x:400, y:300, glyph:'🏴', color:'#a4341f', dialogue:'warehouse_guard', isWarehouseGuard:true, wander:true},
  {id:'guard4', name:"Kade's Guard", x:900, y:600, glyph:'🏴', color:'#a4341f', dialogue:'warehouse_guard', isWarehouseGuard:true, wander:true}
 ],
 ruins:    [ {id:'milo', name:'Milo', x:360, y:320, glyph:'💰', color:'#c1541c', dialogue:'ruins_trader', once:'bad_trade'} ],
 cemetery: [ {id:'ghost', name:'???', x:500, y:420, glyph:'👻', color:'#dcd6bd', dialogue:'ghost_story', once:'ghost_story'} ],
 police_station:    [ {id:'reyes',   name:'Officer Reyes',    x:600, y:420, glyph:'👮', color:'#3fa0d8', dialogue:'survivor_reyes'} ],
 army_outpost:      [ {id:'cole',    name:'Sgt. Cole',        x:700, y:520, glyph:'🪖', color:'#556b2f', dialogue:'survivor_cole'} ],
 radio_station:     [ {id:'wendell', name:'Wendell',          x:500, y:400, glyph:'📻', color:'#c1541c', dialogue:'survivor_wendell'} ],
 gas_station:       [ {id:'hank',    name:'Hank',             x:450, y:360, glyph:'🔧', color:'#8a6a24', dialogue:'survivor_hank'} ],
 church:            [ {id:'agnes',   name:'Sister Agnes',     x:500, y:400, glyph:'✝️', color:'#dcd6bd', dialogue:'survivor_agnes'} ],
 city_hall:         [ {id:'owens',   name:'Clerk Owens',      x:650, y:480, glyph:'👤', color:'#8b8770', dialogue:'survivor_owens'} ],
 military_blockade: [
  {id:'ibarra',   name:'Pvt. Ibarra',    x:500, y:400, glyph:'🎖️', color:'#3fa0d8', dialogue:'survivor_ibarra'},
  {id:'quartermaster', name:'Quartermaster Duval', x:650, y:420, glyph:'💰', color:'#c1541c', dialogue:'blockade_trader', trade:true, tradeContext:'blockade'}
 ],
 farm:              [ {id:'tom',     name:'Old Tom',          x:550, y:450, glyph:'👨\u200d🌾', color:'#8a6a24', dialogue:'survivor_tom'} ],
 train_station:     [ {id:'reeves',  name:'Conductor Reeves', x:600, y:420, glyph:'🚂', color:'#c1541c', dialogue:'survivor_reeves'} ]
};

/* ---------- MAIN / SIDE QUESTS ---------- */
const MAIN_QUESTS = {
 m1:{id:'m1',title:'First Light',desc:"You woke up alone in the Suburban Area. Scavenge for supplies before you do anything else.",target:3,type:'loot',locHint:'suburbs',flag:null},
 m2:{id:'m2',title:'Camp Fire',desc:"Elias needs help clearing the camp of zombies — three waves, ten at a time, with the watchtower guards backing you up.",target:30,type:'kill_at_camp',locHint:'camp',flag:null},
 m5:{id:'m5',title:'Bedside Manner',desc:'A trapped doctor at the hospital says he has answers. Find him.',target:1,type:'special',locHint:'hospital',flag:'hospital_choice'},
 m6:{id:'m6',title:'Warehouse Floor',desc:'A warehouse crew has locked down the district. Deal with them, one way or another.',target:1,type:'special',locHint:'warehouse',flag:'warehouse_choice'},
 m7:{id:'m7',title:'North Ridge',desc:'With both districts settled, the way to the Revelation Biotech facility is open. Finish this.',target:1,type:'special',locHint:'military_base',flag:'boss_arena'},
 m8:{id:'m8',title:'Revelation',desc:'Whatever is down there, it ends today.',target:1,type:'boss',locHint:'military_base',flag:'boss_defeated'},
 m9:{id:'m9',title:'The Way Out',desc:'The Harrowed is dead. Get back to camp and tell Elias — it\'s time to leave Harrow County.',target:1,type:'special',locHint:'camp',flag:'harrowed_reported'}
};
const SIDE_QUESTS = {
 s5:{id:'s5',title:'Ghost Story',desc:"Something in the cemetery isn't a zombie. Find out what.",target:1,type:'special',locHint:'cemetery',flag:'ghost_story'},
 s6:{id:'s6',title:'Bad Trade',desc:'A trader in the ruins seems too eager to sell. Look closer.',target:1,type:'special',locHint:'ruins',flag:'bad_trade'},
 s7:{id:'s7',title:'Squad Up',desc:'Companions at camp will follow you if your karma is high enough. Recruit one.',target:1,type:'special',locHint:'camp',flag:'recruited_one'},
 s8:{id:'s8',title:'Fully Geared',desc:'Equip a full armor set and a backpack.',target:1,type:'special',locHint:'camp',flag:'geared_up'},
 s9:{id:'s9',title:'Overdue Books',desc:'The library still has shelves worth going through.',target:4,type:'loot_at',locHint:'library'},
 s10:{id:'s10',title:'Grocery Run',desc:'Camp could use whatever the supermarket still has on its shelves.',target:5,type:'loot_at',locHint:'supermarket'},
 s11:{id:'s11',title:'Vault Job',desc:'The bank vault is still sealed. Crack it.',target:1,type:'special',locHint:'bank',flag:'vault_cracked'},
 s12:{id:'s12',title:'Motor Pool',desc:'The parking lot has cars worth searching for parts and supplies.',target:4,type:'loot_at',locHint:'parking_lot'},
 s13:{id:'s13',title:'Quarantine Files',desc:'Find whatever records Revelation Biotech left behind in the quarantine tents.',target:1,type:'special',locHint:'quarantine_zone',flag:'quarantine_files'},
 s14:{id:'s14',title:'Salvage Run',desc:'The shipyard containers are worth cracking open.',target:5,type:'loot_at',locHint:'shipyard'},
 s15:{id:'s15',title:'Black Box',desc:"Somewhere in the airport wreckage is a flight recorder worth finding.",target:1,type:'special',locHint:'airport',flag:'black_box'},
 s16:{id:'s16',title:'Diplomatic Pouch',desc:'The embassy was mid-evacuation when it fell. Something official got left behind.',target:1,type:'special',locHint:'embassy',flag:'diplomatic_pouch'},
 s17:{id:'s17',title:'Blue Plate Special',desc:"The diner's kitchen hasn't been picked clean yet.",target:3,type:'loot_at',locHint:'restaurant'},
 s18:{id:'s18',title:'Bus Transfer',desc:'The bus station terminal still has luggage nobody claimed.',target:3,type:'loot_at',locHint:'bus_station'},
 s19:{id:'s19',title:'Paper Trail',desc:'Journal pages are scattered across Harrow County. Recover at least 5 of them.',target:5,type:'journal_count'},
 s20:{id:'s20',title:'Bandit Cleanup',desc:'Raiders keep picking off survivors on the road. Put a stop to 10 of them.',target:10,type:'kill_bandits'},
 s21:{id:'s21',title:'Depopulation',desc:'Every zombie down is one less at the fence line. Reach 75 kills.',target:75,type:'kill_total'},
 s22:{id:'s22',title:'Community Aid',desc:'Survivors scattered across the county need supplies. Help out 5 of them.',target:5,type:'community_aid'}
};
