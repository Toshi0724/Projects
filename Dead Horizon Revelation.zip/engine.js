'use strict';
/* ================= DEAD HORIZON: REVELATION — ENGINE ================= */

/* ---------- utility ---------- */
function rand(a,b){ return a + Math.random()*(b-a); }
function randInt(a,b){ return Math.floor(rand(a,b+1)); }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function clamp(v,a,b){ return Math.max(a, Math.min(b,v)); }
function dist(x1,y1,x2,y2){ return Math.hypot(x2-x1, y2-y1); }
function lerp(a,b,t){ return a + (b-a)*t; }
function angleTo(x1,y1,x2,y2){ return Math.atan2(y2-y1, x2-x1); }
function angleDiff(a,b){ let d = a-b; while(d>Math.PI) d-=Math.PI*2; while(d<-Math.PI) d+=Math.PI*2; return d; }

/* ---------- global state ---------- */
let S = null;           // survivor runtime state
let W = null;           // current world/location state
let dlgState = null;    // {tree, node, npc}
let RAF = null, lastT = 0;
const KEYS = {};
let selectedSurvivor = null;
let lockedDoorContext = null; // {doorText, itemName} — read by the 'locked_room' dialogue

const canvas = document.getElementById('gamecanvas');
const ctx = canvas.getContext('2d');
/* Character-model drawing functions read/write through `activeCtx` rather
   than `ctx` directly. It's always `ctx` during normal gameplay rendering;
   `getVariantIconDataUrl` briefly points it at an offscreen canvas (fully
   synchronously — JS never yields mid-swap) to snapshot a zombie/bandit
   model for the Trophies list without duplicating any drawing code. */
let activeCtx = ctx;
const fogCanvas = document.createElement('canvas');
const fogCtx = fogCanvas.getContext('2d');
function resizeCanvases(){
 canvas.width = window.innerWidth; canvas.height = window.innerHeight;
 fogCanvas.width = window.innerWidth; fogCanvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvases);
resizeCanvases();

const DAY_LENGTH_MS = 12*60*1000; // one full in-game day per 12 real minutes

/* ================= STATE FACTORY ================= */
function newState(survivorId){
 const sv = SURVIVORS.find(s=>s.id===survivorId);
 const st = {
  id:sv.id, name:sv.name, role:sv.role, perk:sv.perk, color:sv.color,
  END:sv.END, AGI:sv.AGI, STR:sv.STR, PER:sv.PER, STA:sv.STA,
  level:1, xp:0, xpNext:xpToNext(1), skillPoints:0, skills:{},
  maxHp:100+sv.END*5, hp:100+sv.END*5,
  maxStamina:70+sv.STA*4, stamina:70+sv.STA*4,
  hunger:100, thirst:100,
  charisma:5, karma:0, tokens:15, kills:0, banditKills:0, campKills:0,
  companions:[], companionTrust:{},
  equipped:{armor:null, backpack:null}, armorDurability:0,
  carryCap:BACKPACK_BASE_CAPACITY,
  inventory:[],
  weaponSlots:{melee:sv.startWeapon && WEAPONS_MELEE[sv.startWeapon] ? sv.startWeapon : 'fists', secondary:null, primary:null, rocket:null, throwable:null},
  magAmmo:{secondary:0, primary:0, rocket:0},
  reloadingSlot:null, reloadEndsAt:0,
  activeSlot:'melee',
  status:{bleeding:0, infected:0, infectedSeverity:0, sick:0},
  flags:{}, questsMain:{}, questsSide:{}, achievements:{}, journalPages:{}, visitedLocations:{},
  trophyKills:{}, trophyClaimed:{}, companionResting:{}, campSiege:{active:false, wave:0},
  flashlight:false, facing:{x:0,y:1},
  gameMinutes:480, dayCount:1,
  buffs:[], secondWindUsed:false, konami:false,
  currentLocation:null
 };
 COMPANIONS.forEach(c=> st.companionTrust[c.id]=0 );
 if(sv.kit) sv.kit.forEach(itemId=>{
  if(WEAPONS_RANGED[itemId]){ giveWeaponItem(st,itemId); }
  else if(findConsumableById(itemId)){ addToInventory(st,itemId, consumableKind(itemId), 1); }
 });
 if(sv.startAmmo){
  for(const ammoType in sv.startAmmo){
   addToInventory(st, 'ammo_'+ammoType, 'ammo', sv.startAmmo[ammoType]);
  }
 }
 for(const mq in MAIN_QUESTS) st.questsMain[mq] = {status:'locked', progress:0};
 for(const sq in SIDE_QUESTS) st.questsSide[sq] = {status:'locked', progress:0};
 for(const a of ACHIEVEMENTS) st.achievements[a.id] = false;
 return st;
}
function consumableKind(id){ if(DRINKS[id]) return 'drink'; if(FOODS[id]) return 'food'; if(MEDS[id]) return 'med'; if(BUFF_ITEMS[id]) return 'buff'; return 'item'; }

/* ================= INVENTORY ================= */
function itemWeight(kind){
 switch(kind){
  case 'weapon_melee': return 4;
  case 'weapon_ranged': return 7;
  case 'weapon_throwable': return 1;
  case 'ammo': return 0.1;
  case 'drink': case 'food': case 'med': return 1;
  case 'armor': return 6;
  case 'backpack': return 4;
  default: return 1;
 }
}
function carryWeight(st){
 let w=0;
 st.inventory.forEach(it=> w += itemWeight(it.kind)*it.qty );
 return Math.round(w*10)/10;
}
function findInv(st,id){ return st.inventory.find(i=>i.id===id); }
function addToInventory(st, id, kind, qty){
 qty = qty||1;
 const addWeight = itemWeight(kind)*qty;
 if(carryWeight(st)+addWeight > st.carryCap){ toast('Not enough carrying capacity.', 'bad'); return false; }
 const ex = findInv(st,id);
 if(ex){ ex.qty += qty; } else { st.inventory.push({id,kind,qty}); }
 return true;
}
function removeFromInventory(st, id, qty){
 qty = qty||1;
 const ex = findInv(st,id);
 if(!ex) return false;
 ex.qty -= qty;
 if(ex.qty<=0) st.inventory = st.inventory.filter(i=>i.id!==id);
 return true;
}
function giveWeaponItem(st, wid){
 const cat = weaponCategory(wid);
 if(cat==='melee'){
  addToInventory(st, wid, 'weapon_melee', 1);
 } else if(cat==='ranged'){
  addToInventory(st, wid, 'weapon_ranged', 1);
 } else if(cat==='throwable'){
  addToInventory(st, wid, 'weapon_throwable', 1);
 }
}
function equipWeaponFromInventory(st, wid){
 const cat = weaponCategory(wid);
 if(cat==='melee'){
  const old = st.weaponSlots.melee;
  st.weaponSlots.melee = wid;
  removeFromInventory(st, wid, 1);
  if(old && old!=='fists') addToInventory(st, old, 'weapon_melee', 1);
 } else if(cat==='ranged'){
  const w = WEAPONS_RANGED[wid]; const slot = w.slot;
  const old = st.weaponSlots[slot];
  if(old==='plasma_rifle'){ toast("The Plasma Rifle won't come off — it's welded into the mount.", 'bad'); return; }
  st.weaponSlots[slot] = wid;
  st.magAmmo[slot] = 0;
  st.ammoVariant = st.ammoVariant || {}; st.ammoVariant[slot] = 'normal';
  removeFromInventory(st, wid, 1);
  if(old) addToInventory(st, old, 'weapon_ranged', 1);
 } else if(cat==='throwable'){
  st.weaponSlots.throwable = wid;
 }
 renderWeaponSlots(); renderInventoryModal();
}
function equipArmor(st, aid){
 const a = ARMOR[aid]; if(!a) return;
 if(st.equipped.armor) addToInventory(st, st.equipped.armor, 'armor', 1);
 removeFromInventory(st, aid, 1);
 st.equipped.armor = aid; st.armorDurability = a.durability;
 toast('Equipped '+a.name+'.', 'amber');
 checkGearedUp(); renderInventoryModal();
}
function unequipArmor(st){
 if(!st.equipped.armor) return;
 addToInventory(st, st.equipped.armor, 'armor', 1);
 st.equipped.armor = null; st.armorDurability = 0;
 renderInventoryModal();
}
function equipBackpack(st, bid){
 const b = BACKPACKS[bid]; if(!b) return;
 if(st.equipped.backpack) addToInventory(st, st.equipped.backpack, 'backpack', 1);
 removeFromInventory(st, bid, 1);
 st.equipped.backpack = bid;
 st.carryCap = BACKPACK_BASE_CAPACITY + b.bonus + (st.skills.packmule?15:0) + trophyBonusSum('carry')*15;
 toast('Equipped '+b.name+'.', 'amber');
 checkGearedUp(); renderInventoryModal();
}
function unequipBackpack(st){
 if(!st.equipped.backpack) return;
 addToInventory(st, st.equipped.backpack, 'backpack', 1);
 st.equipped.backpack = null;
 st.carryCap = BACKPACK_BASE_CAPACITY + (st.skills.packmule?15:0) + trophyBonusSum('carry')*15;
 renderInventoryModal();
}
function checkGearedUp(){
 if(S.equipped.armor==='assault' && S.equipped.backpack==='tactical'){
  unlockAchievement('fully_geared');
 }
 if(S.equipped.armor && S.equipped.backpack && !S.flags.geared_up){
  S.flags.geared_up = true; completeQuestByFlag('geared_up');
 }
}

/* ================= COMPANIONS ================= */
function recruitCompanion(cid){
 if(S.companions.includes(cid)) return;
 const idx = S.companions.length;
 const cost = companionRecruitCost(idx);
 if(!cost){ toast('Your squad is already full.', 'bad'); return; }
 if(cost.type==='karma'){
  if(S.karma < cost.amount){ toast('Not enough karma yet (needs '+cost.amount+').', 'bad'); return; }
  S.karma -= cost.amount;
 } else {
  if(S.tokens < cost.amount){ toast('Not enough tokens yet (needs '+cost.amount+').', 'bad'); return; }
  S.tokens -= cost.amount;
 }
 S.companions.push(cid);
 const c = COMPANIONS.find(x=>x.id===cid);
 toast(c.name+' joins your squad. (−'+cost.amount+' '+(cost.type==='karma'?'Karma':'Tokens')+')', 'amber');
 if(!S.flags.recruited_one){ S.flags.recruited_one = true; completeQuestByFlag('recruited_one'); }
 if(S.companions.length>=COMPANIONS.length) unlockAchievement('squad_goals');
 spawnCompanionsInWorld();
 updateHudDynamic();
}

/* ================= LOCATION LAYOUT (procedural, per kit) ================= */
function seededRand(seed){ let s = seed%2147483647; if(s<=0) s+=2147483646; return function(){ s = s*16807 % 2147483647; return (s-1)/2147483646; }; }
function rectOverlap(ax,ay,aw,ah,bx,by,bw,bh){
 return ax < bx+bw && ax+aw > bx && ay < by+bh && ay+ah > by;
}
function buildRoads(loc){
 const roads = [];
 const W_=loc.w, H_=loc.h;
 function road(x,y,w,h){ roads.push({x,y,w,h}); }
 switch(loc.kit){
  case 'suburbs':
   road(0, H_/2-40, W_, 80);
   road(W_/2-40, 0, 80, H_);
   break;
  case 'parking_lot':
   road(0, H_-56, W_, 56);
   break;
  case 'bus_station':
   road(0, H_-46, W_, 46);
   break;
  case 'restaurant':
   road(0, 0, 60, H_);
   break;
  case 'bank':
   road(0, H_-64, W_, 64);
   break;
  case 'supermarket':
   road(0, H_-54, W_, 54);
   break;
  case 'warehouse':
   road(0, H_-60, W_, 60);
   break;
  case 'quarantine_zone':
   road(0, H_-40, W_, 40);
   break;
  case 'embassy':
   road(0, H_-40, W_, 40);
   break;
  case 'military_base':
   road(0, H_-60, W_, 60);
   break;
  case 'shipyard':
   road(0, H_-60, W_, 60);
   break;
  case 'airport':
   road(0, H_-70, W_-260, 70);
   break;
  case 'police_station':
   road(0, H_-50, W_, 50);
   break;
  case 'army_outpost':
   road(0, H_-60, W_, 60);
   break;
  case 'radio_station':
   road(0, H_-46, W_, 46);
   break;
  case 'gas_station':
   road(0, H_-50, W_, 50);
   break;
  case 'church':
   road(0, H_-40, W_, 40);
   break;
  case 'city_hall':
   road(0, H_-50, W_, 50);
   break;
  case 'military_blockade':
   road(0, H_/2-40, W_, 80);
   break;
  case 'farm':
   road(0, H_-50, W_, 50);
   break;
  case 'bandit_camp':
   road(0, H_-50, W_, 50);
   break;
 }
 return roads;
}
function buildProps(loc, roads){
 const rnd = seededRand(loc.id.length*97 + loc.w);
 const raw = [];
 const W_=loc.w, H_=loc.h;
 (roads||[]).forEach(r=> raw.push({x:r.x, y:r.y, w:r.w, h:r.h, __road:true}));
 function overlapsExisting(x,y,w,h){ return raw.some(p=>rectOverlap(x,y,w,h,p.x,p.y,p.w,p.h)); }
 function rect(x,y,w,h,label,fill){ raw.push({x,y,w,h,label,fill}); }
 function rectSpaced(x,y,w,h,label,fill){
  // used for freely-scattered layouts: retry a few times so props can't stack
  // into a dense, inescapable cluster (and now also steer clear of roads)
  for(let tries=0; tries<8 && overlapsExisting(x-24,y-24,w+48,h+48); tries++){
   x = 40+rnd()*(W_-w-80); y = 40+rnd()*(H_-h-80);
  }
  raw.push({x,y,w,h,label,fill});
 }
 switch(loc.kit){
  case 'suburbs':
   for(let i=0;i<7;i++){
    rectSpaced(80+rnd()*(W_-260), 80+rnd()*(H_-260), 90+rnd()*70, 60+rnd()*70, 'House', '#171810');
    raw[raw.length-1].variant = (i%3===0) ? 'flat' : 'peaked';
    if(i===2) raw[raw.length-1].burning = true;
   }
   for(let i=0;i<4;i++) rectSpaced(60+rnd()*(W_-160), 60+rnd()*(H_-160), 26, 40, 'Tree', '#3a4a1a');
   for(let i=0;i<3;i++) rectSpaced(60+rnd()*(W_-160), 60+rnd()*(H_-160), 50, 18, 'Bench', '#3a2a1a');
   for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-220), 80+rnd()*(H_-220), 110, 60, 'WreckedCar', '#141210');
   rect(60,60,10,60,'Lamppost','#2a2a1e');
   rect(W_-70,H_-120,10,60,'Lamppost','#2a2a1e');
   break;
  case 'camp':
   // Camp Hall sits well clear of the bottom barbwire run — both are solid,
   // and the player has a 16px collision radius on each side, so anything
   // closer than ~32px between the hall's door and the wire behind it would
   // squeeze the door shut with no reachable standing room in between.
   rect(70, H_-320, 280, 200, 'Camp Hall', '#1c1d13');
   rect(90, 90, 70, 200, 'Watchtower', '#20201a');
   rect(W_-160, 90, 70, 200, 'Watchtower', '#20201a');
   rect(180, 120, 140, 110, 'Tent', '#3a2a18');
   for(let i=0;i<6;i++) rect(60+i*140, 40, 40, 40, 'Tent', '#26271a');
   rect(370,640,36,50,'Barrel','#3a2a1a');
   rect(415,640,36,50,'Barrel','#3a2a1a');
      for(let i=0;i<2;i++) rect(W_-160+i*70,H_-140,50,18,'Bench','#3a2a1a');
   rect(W_-90,60,34,50,'Tree','#3a4a1a');
   // Perimeter barbwire — purely decorative, marks the camp as a secured
   // safe zone. Kept well clear of the watchtowers, Camp Hall's door, and
   // the benches so nothing becomes unreachable. Each segment carries a
   // hidden durability that only matters during an active siege wave (see
   // updateBarbwire) — a zombie push can tear a hole in it mid-fight, but it
   // fully mends the moment the camp is secured and never breaks again.
   rect(20, 40, 14, H_-80, 'Barbwire', '#4a4a40');
   rect(W_-34, 40, 14, H_-80, 'Barbwire', '#4a4a40');
   rect(40, H_-34, W_-80, 14, 'Barbwire', '#4a4a40');
   for(let i=raw.length-3;i<raw.length;i++){ raw[i].isBarbwire = true; raw[i].hp = 3; raw[i].maxHp = 3; }
   // Big Truck — the eventual way out. Sits in the open ground between the
   // hall and the eastern watchtower, clear of every other structure.
   rect(610, 430, 170, 110, 'Big Truck', '#2a3a2a');
break;
  case 'hospital':
   for(let i=0;i<5;i++) rect(100+i*220, 120, 180, 90, 'Ward', '#151710');
   rect(W_/2-60,230,120,80,'Nurse Station','#1c1d13');
      rect(80,H_-160,110,60,'Car','#3a3f45'); raw[raw.length-1].variant='sedan';
   rect(320,H_-180,110,60,'Ambulance','#d8d8d0'); raw[raw.length-1].vehicleLoot={kind:'ambulance', hasLoot:Math.random()<0.5, looted:false};
   rect(460,H_-180,110,60,'PoliceCar','#12151a'); raw[raw.length-1].vehicleLoot={kind:'police', hasLoot:Math.random()<0.5, looted:false};
   rect(W_/2-30,60,60,26,'RedCross','#f4f0e8');
   rect(900,300,180,140,'Laboratory','#0f1c1c');
   for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-260),34,50,'Tree','#3a4a1a');
break;
  case 'warehouse':
   for(let r=0;r<3;r++) for(let c=0;c<4;c++) rect(120+c*280, 100+r*260, 220, 160, 'Shelving', '#171810');
      rect(W_-220,H_-260,150,110,'Container','#151d1f');
   rect(80,H_-140,110,60,'WreckedCar','#141210');
   rect(W_-140,80,50,50,'Dumpster','#2a4a1a');
   rect(60,60,170,120,'Container','#151d1f');
   rect(W_-260,60,170,120,'Container','#151d1f');
   rect(200,H_-100,160,80,'Car','#20261a'); raw[raw.length-1].variant='truck';
   rect(W_-420,H_-100,160,80,'Car','#171d20'); raw[raw.length-1].variant='truck';
break;
  case 'ruins':
   for(let i=0;i<8;i++){
    rectSpaced(rnd()*(W_-180), rnd()*(H_-180), 70+rnd()*90, 70+rnd()*90, 'Rubble', '#141510');
    if(i===0) raw[raw.length-1].burning = true;
   }
      rect(120,H_-220,110,60,'WreckedCar','#141210');
   rect(W_-260,120,110,60,'WreckedCar','#141210'); raw[raw.length-1].burning = true;
   for(let i=0;i<3;i++) rectSpaced(80+rnd()*(W_-200),80+rnd()*(H_-200),34,34,'Bush','#2f4018');
break;
  case 'cemetery':
   for(let r=0;r<5;r++) for(let c=0;c<7;c++) rect(80+c*130,90+r*130,26,40,'Headstone','#22241a');
      for(let i=0;i<4;i++) rectSpaced(60+rnd()*(W_-160),60+rnd()*(H_-160),34,50,'Tree','#28381a');
   for(let i=0;i<2;i++) rectSpaced(60+rnd()*(W_-160),60+rnd()*(H_-160),50,18,'Bench','#3a2a1a');
break;
  case 'bus_station':
   rect(W_/2-220,120,440,140,'Terminal','#171810');
   for(let i=0;i<3;i++) rect(120+i*300,H_-160,160,60,'Bus','#20261a');
      for(let i=0;i<3;i++) rect(90+i*300,H_-80,50,18,'Bench','#3a2a1a');
   for(let i=0;i<3;i++) rect(120+i*280,H_-260,26,30,'TrafficCone','#c1541c');
   rect(W_-100,120,10,60,'Lamppost','#2a2a1e');
break;
  case 'library':
   for(let r=0;r<4;r++) for(let c=0;c<6;c++) rect(90+c*140,100+r*140,100,26,'Shelf','#171810');
      for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-260),50,18,'Bench','#3a2a1a');
   for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-260),34,50,'Tree','#3a4a1a');
break;
  case 'supermarket':
   for(let r=0;r<4;r++) for(let c=0;c<5;c++) rect(100+c*220,110+r*160,170,40,'Aisle','#171810');
      for(let i=0;i<3;i++) rect(80+i*160,H_-140,110,60,'Car', i%2===0?'#171d20':'#20261a');
   rect(W_-140,80,50,50,'Dumpster','#2a4a1a');
   for(let i=0;i<2;i++) rect(200+i*300,H_-220,26,30,'TrafficCone','#c1541c');
break;
  case 'bank':
   rect(W_/2-260,80,520,120,'Teller Row','#171810');
   rect(W_/2-80,560,160,160,'Vault','#221a12');
      rect(80,H_-160,110,60,'Car','#171d20');
   rect(W_-190,H_-160,110,60,'Car','#20261a');
   rect(90,120,10,60,'Lamppost','#2a2a1e');
   rect(W_/2-40,40,80,50,'DollarSign','#1c2a14');
   for(let i=0;i<4;i++) rect(900,240+i*160,240,120,'Cubicle','#2a2a20');
   rect(60,750,60,50,'ATM','#1a1a1a'); raw[raw.length-1].uselessInteract = true;
break;
  case 'parking_lot':
   for(let r=0;r<4;r++) for(let c=0;c<8;c++){
    const truck = (r+c)%3===0;
    rect(70+c*140,90+r*180,110,60,'Car', truck?'#20261a':'#171d20');
    raw[raw.length-1].variant = truck?'truck':'sedan';
   }
      for(let i=0;i<4;i++) rect(120+i*260,H_-120,26,30,'TrafficCone','#c1541c');
   rect(60,60,10,60,'Lamppost','#2a2a1e');
   rect(W_-70,60,10,60,'Lamppost','#2a2a1e');
break;
  case 'quarantine_zone':
   for(let i=0;i<10;i++){
    rectSpaced(80+rnd()*(W_-220), 80+rnd()*(H_-220), 80, 80, 'Tent', '#1c1408');
    if(i===0) raw[raw.length-1].burning = true;
   }
   rect(40,40,W_-80,20,'Barrier Fence','#3a2010'); rect(40,H_-60,W_-80,20,'Barrier Fence','#3a2010');
      rect(100,H_-180,110,60,'WreckedCar','#141210');
   for(let i=0;i<2;i++) rect(300+i*400,80,50,50,'Dumpster','#2a4a1a');
   for(let i=0;i<3;i++) rect(160+i*320,H_-260,26,30,'TrafficCone','#c1541c');
break;
  case 'shipyard':
   for(let r=0;r<3;r++) for(let c=0;c<6;c++) rect(80+c*220, 100+r*220, 180, 130, 'Container', '#151d1f');
   rect(W_-260,H_/2-40,180,80,'Crane Base','#20201a');
      rect(120,H_-180,110,60,'WreckedCar','#141210');
   for(let i=0;i<2;i++) rect(200+i*260,H_-90,26,30,'TrafficCone','#c1541c');
break;
  case 'airport':
   rect(120,140,W_-400,200,'Terminal','#171810');
   for(let i=0;i<4;i++) rect(160+i*260,H_-260,180,90,'Luggage Cart','#1a1a1a');
   rect(W_-260,80,160,H_-260,'Runway Edge','#101210');
      rect(220,H_-220,220,140,'CrashedHelicopter','#1a1d16');
   rect(560,H_-180,110,60,'WreckedCar','#141210');
   rect(1050,650,340,150,'Plane','#b9b9ae'); raw[raw.length-1].crashed = true; raw[raw.length-1].burning = true;
   for(let i=0;i<3;i++) rect(160+i*300,120,26,30,'TrafficCone','#c1541c');
break;
  case 'embassy':
   rect(W_/2-200,120,400,240,'Main Building','#171810');
   rect(80,80,W_-160,20,'Perimeter Fence','#2a2a1a'); rect(80,H_-100,W_-160,20,'Perimeter Fence','#2a2a1a');
   rect(W_/2-6,340,12,120,'Flagpole','#3a3a2a');
      for(let i=0;i<3;i++) rectSpaced(80+rnd()*(W_-260),120+rnd()*(H_-400),34,50,'Tree','#3a4a1a');
   for(let i=0;i<3;i++) rectSpaced(80+rnd()*(W_-260),120+rnd()*(H_-400),34,34,'Bush','#2f4018');
   rect(90,110,10,60,'Lamppost','#2a2a1e');
   rect(W_-100,110,10,60,'Lamppost','#2a2a1e');
break;
  case 'restaurant':
   for(let r=0;r<3;r++) for(let c=0;c<4;c++) rect(90+c*160,110+r*140,60,60,'Table','#1a1610');
   rect(W_-220,60,160,H_-140,'Kitchen','#20160e');
      rect(70,H_-160,110,60,'Car','#171d20');
   rect(70,H_-240,110,60,'Car','#20261a');
   rect(200,H_-70,26,30,'TrafficCone','#c1541c');
break;
  case 'military_base':
   rect(W_/2-260,100,520,180,'Bunker','#14150f');
   // Was originally centered on the map's guaranteed player-spawn clear zone
   // (900-1100, 650-850) and got silently deleted by the anti-softlock
   // filter below every single time — the boss door never actually existed
   // in the world. Moved clear of it.
   rect(910,1000,180,160,'Deep Lab Access','#241a0a');
      rect(120,H_-200,220,140,'CrashedHelicopter','#1a1d16');
   rect(W_-260,120,110,60,'WreckedCar','#141210');
   rect(150,150,200,150,'House','#1c2230'); raw[raw.length-1].burning = true;
   rect(W_-360,150,200,150,'House','#1c2230');
   for(let i=0;i<4;i++) rect(120+i*180,H_-420,140,110,'Tent','#26271a');
   rect(W_-460,H_-320,160,80,'Car','#2a3540'); raw[raw.length-1].variant='truck';
   rect(W_-260,H_-320,160,80,'Car','#2a3540'); raw[raw.length-1].variant='truck';
   rect(180,H_-620,160,80,'Car','#3a4030'); raw[raw.length-1].variant='truck';
   // Administrative building, with the facility's second secure door tucked
   // just behind it — this is where the Level 2 keycard actually leads.
   rect(1450,450,300,220,'Main Building','#1c2230');
   rect(1500,720,150,140,'L2 Vault','#1a1712');
break;
  case 'police_station':
   rect(W_/2-220,100,440,240,'Main Building','#1c2230');
   for(let i=0;i<3;i++) rect(90+i*160,H_-170,130,60,'Car','#1c2230');
   rect(80,80,W_-160,20,'Barrier Fence','#2a1a0a');
   rectSpaced(140,420,180,120,'Shelving','#171810');
   rectSpaced(W_-340,420,180,120,'Shelving','#171810');
   rect(60,H_-330,50,50,'Dumpster','#2a4a1a');
   rect(W_-90,140,10,60,'Lamppost','#2a2a1e');
   rect(80,150,140,110,'ChiefsOffice','#1c1a14');
   rect(W_-220,150,140,110,'Armory','#171810');
   for(let i=0;i<3;i++) rect(300+i*90,650,70,70,'JailCell','#141210');
   break;
  case 'army_outpost':
   rect(W_/2-260,100,520,180,'Bunker','#14150f');
   rect(90,90,70,220,'Watchtower','#20201a');
   rect(W_-160,90,70,220,'Watchtower','#20201a');
   rect(80,H_/2+40,W_-160,20,'Barrier Fence','#2a1a0a');
   for(let i=0;i<4;i++){
    rect(140+i*220,H_/2+120,160,110,'Container','#151d1f');
    if(i===1) raw[raw.length-1].burning = true;
   }
      rect(W_-260,H_-200,220,140,'CrashedHelicopter','#1a1d16');
   rect(120,H_-160,110,60,'WreckedCar','#141210');
   for(let i=0;i<2;i++) rect(300+i*300,H_-90,26,30,'TrafficCone','#c1541c');
break;
  case 'radio_station':
   rect(320,60,360,220,'House','#1c1a14');
   rect(720,60,30,300,'Antenna','#3a3a2a');
   rectSpaced(140,420,160,90,'Table','#1a1610');
      for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-260),H_-300+rnd()*160,34,50,'Tree','#3a4a1a');
   for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-260),H_-300+rnd()*160,34,34,'Bush','#2f4018');
break;
  case 'gas_station':
   rect(120,120,220,160,'House','#1c1a14');
   rect(420,260,60,80,'GasPump','#2a2a1e');
   rect(540,260,60,80,'GasPump','#2a2a1e');
   rect(420,380,110,60,'Car','#171d20'); raw[raw.length-1].burning = true;
   rect(560,380,110,60,'Car','#20261a');
   rect(700,120,60,90,'VendingMachine','#8a1a2a');
   rect(120,320,50,50,'Dumpster','#2a4a1a');
   break;
  case 'church':
   rect(W_/2-140,30,280,260,'Church','#241a12');
   for(let i=0;i<10;i++) rectSpaced(80+rnd()*(W_-260),H_-320+rnd()*160,26,34,'Headstone','#22241a');
   for(let i=0;i<2;i++) rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-500),50,18,'Bench','#3a2a1a');
   for(let i=0;i<3;i++) rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-500),34,50,'Tree','#3a4a1a');
   break;
  case 'city_hall':
   rect(W_/2-220,110,440,260,'Main Building','#1c1a14'); raw[raw.length-1].burning = true;
   rect(W_/2-6,380,12,110,'Flagpole','#3a3a2a');
   rectSpaced(120,H_-260,220,140,'Rubble','#141510');
   rectSpaced(W_-340,H_-260,220,140,'Rubble','#141510');
   for(let i=0;i<3;i++) rectSpaced(80+rnd()*(W_-260),H_-520+rnd()*140,50,18,'Bench','#3a2a1a');
   for(let i=0;i<3;i++) rectSpaced(80+rnd()*(W_-260),H_-520+rnd()*140,34,50,'Tree','#3a4a1a');
   rect(90,110,10,60,'Lamppost','#2a2a1e');
   rect(W_-100,110,10,60,'Lamppost','#2a2a1e');
   break;
  case 'military_blockade':
   rect(90,H_/2-260,80,220,'Watchtower','#20201a');
   rect(W_-170,H_/2-260,80,220,'Watchtower','#20201a');
   rect(90,H_/2+40,80,180,'Bunker','#14150f');
   rect(W_-170,H_/2+40,80,180,'Bunker','#14150f');
   for(let i=0;i<3;i++) rect(300+i*220,H_/2-180,140,90,'Container','#151d1f');
      for(let i=0;i<4;i++) rect(240+i*180,H_/2-14,26,30,'TrafficCone','#c1541c');
   rect(90,H_-140,10,60,'Lamppost','#2a2a1e');
   rect(W_-100,H_-140,10,60,'Lamppost','#2a2a1e');
break;
  case 'farm':
   rect(140,H_-380,220,180,'House','#3a2418');
   rect(420,H_-360,170,170,'Barn','#5a1a10');
   rect(650,H_-400,90,150,'Silo','#8a8a7a');
   rect(60,60,W_-120,20,'Barrier Fence','#2a1a0a');
   rect(820,H_-260,110,60,'Car','#3a2a1a');
   for(let i=0;i<4;i++) rectSpaced(80+rnd()*(W_-260),100+rnd()*(H_-500),34,50,'Tree','#3a4a1a');
   break;
  case 'train_station':
   rect(W_/2-260,120,520,180,'Terminal','#171810');
   rect(80,H_-260,W_-160,50,'Tracks','#151510');
   for(let i=0;i<3;i++) rect(140+i*260,H_-380,180,80,'Luggage Cart','#1a1a1a');
   for(let i=0;i<2;i++) rect(160+i*380,340,50,18,'Bench','#3a2a1a');
   rect(W_-140,120,10,60,'Lamppost','#2a2a1e');
   break;
  case 'bandit_camp':
   for(let i=0;i<5;i++){
    rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-260),120,90,'Tent','#26271a');
    if(i===0) raw[raw.length-1].burning = true;
   }
   rectSpaced(W_/2-100,H_/2-60,200,120,'Rubble','#141510');
   rect(60,60,W_-120,20,'Barrier Fence','#2a1a0a');
   rect(60,H_-160,W_-120,20,'Barrier Fence','#2a1a0a');
      rect(120,H_-180,110,60,'WreckedCar','#141210');
   rect(W_-260,120,50,50,'Dumpster','#2a4a1a');
break;
 }
 // The survivor always spawns at the exact center of the location — guarantee
 // that point (plus a margin) is never covered by a prop, or they'd be trapped
 // inside a structure the instant they walk in.
 const clearW=200, clearH=200, clearX=W_/2-clearW/2, clearY=H_/2-clearH/2;
 return raw.filter(p=>!p.__road && !rectOverlap(p.x,p.y,p.w,p.h, clearX,clearY,clearW,clearH));
}

/* ================= ZOMBIES / BANDITS ================= */
function weightedPick(pairs){
 const total = pairs.reduce((s,p)=>s+p[1],0);
 let r = Math.random()*total;
 for(const [id,w] of pairs){ if(r<w) return id; r-=w; }
 return pairs[0][0];
}
function pickZombieVariant(loc){
 const pool = [['walker',50]];
 if(loc.danger!=='SAFE') pool.push(['labor',14],['nurse',12],['scavenger',12]);
 if(['MEDIUM','HIGH','VERY HIGH','EXTREME'].includes(loc.danger)) pool.push(['miner',8],['mechanic',8],['baseball',9],['butcher',7],['screamer',6],['dog',7]);
 if(['HIGH','VERY HIGH','EXTREME'].includes(loc.danger)) pool.push(['fireman',6],['police',5],['medic',5]);
 // Tanks used to be an EXTREME-only (military base) encounter. Very High and
 // High danger zones — Quarantine Zone, Airport, Embassy, the Bank, Old Town
 // Ruins — now have a real (smaller) chance to throw one at you too.
 if(loc.danger==='HIGH') pool.push(['tank',0.15]);
 if(loc.danger==='VERY HIGH') pool.push(['soldier',2],['tank',0.25]);
 if(loc.danger==='EXTREME') pool.push(['soldier',4],['tank',0.4]);
 return weightedPick(pool);
}
function pickBanditVariant(loc){
 const pool = [['grunt',40],['hooded',25]];
 if(['MEDIUM','HIGH','VERY HIGH','EXTREME'].includes(loc.danger)) pool.push(['grenadier',12],['light_armor',12]);
 if(['HIGH','VERY HIGH','EXTREME'].includes(loc.danger)) pool.push(['captain',8]);
 if(loc.danger==='EXTREME') pool.push(['heavy_armor',6]);
 return weightedPick(pool);
}
function spawnZombie(loc, forceVariant){
 const vid = forceVariant || pickZombieVariant(loc);
 const variant = ZOMBIE_VARIANTS[vid] || ZOMBIE_VARIANTS.walker;
 const tierHp = 24 + loc.tier*9;
 const hp = variant.hpFlat!==undefined ? variant.hpFlat : Math.round(tierHp*(variant.hpMult||1));
 return {
  kind:'zombie', variant:variant.id, x:rand(60,loc.w-60), y:rand(60,loc.h-60),
  hp, maxHp:hp, dmg:(6+loc.tier*1.5)*(variant.dmgMult||1), speed:rand(0.55,0.85)*(variant.speedMult||1),
  aggro:false, atkCd:0, fireCd:rand(400,1200), chargeCd:rand(3000,5000), throwCd:rand(1500,3000),
  charging:0, screamed:false, r: variant.id==='dog'?11:(variant.id==='tank'?28:14)
 };
}
function spawnBandit(loc, forceVariant){
 const vid = forceVariant || pickBanditVariant(loc);
 const variant = BANDIT_VARIANTS[vid] || BANDIT_VARIANTS.grunt;
 const baseHp=50, baseDmg=12, baseSpeed=1.0;
 const hp = Math.round((baseHp+loc.tier*6)*(variant.hpMult||1));
 return {
  kind:'bandit', banditType:vid, variant:vid, x:rand(60,loc.w-60), y:rand(60,loc.h-60),
  hp, maxHp:hp, dmg:baseDmg*(variant.dmgMult||1), speed:baseSpeed*(variant.speedMult||1),
  aggro:false, atkCd:0, fireCd:rand(300,900), r:15
 };
}

/* Open-point placement: rejection-samples a spot that isn't inside (or hugging)
   any prop, so loot, NPCs, and enemies never spawn unreachable inside a wall.
   Falls back to the map's guaranteed-clear center if it can't find one. */
function randomOpenPoint(props, w, h, margin){
 margin = margin===undefined ? 36 : margin;
 for(let i=0;i<40;i++){
  const x = rand(50,w-50), y = rand(50,h-50);
  let clear = true;
  for(const p of props){ if(rectOverlap(x-margin,y-margin,margin*2,margin*2, p.x,p.y,p.w,p.h)){ clear=false; break; } }
  if(clear) return {x,y};
 }
 // Grid sweep fallback: far more reliable than giving up to a single fixed
 // point, which risked stacking multiple items on the exact same contested
 // spot (the player's own spawn point) in crowded locations.
 for(let gy=80; gy<h-80; gy+=60){
  for(let gx=80; gx<w-80; gx+=60){
   let clear = true;
   for(const p of props){ if(rectOverlap(gx-margin,gy-margin,margin*2,margin*2, p.x,p.y,p.w,p.h)){ clear=false; break; } }
   if(clear) return {x:gx, y:gy};
  }
 }
 return {x:w/2, y:h/2};
}
/* Safety net for anything placed at a fixed/hand-authored coordinate (NPCs) —
   shoves it back out if it happens to land inside a prop. */
function nudgeOutOfProps(ent, props, radius){
 radius = radius||24;
 for(const p of props){
  const cx = clamp(ent.x, p.x, p.x+p.w);
  const cy = clamp(ent.y, p.y, p.y+p.h);
  let dx = ent.x-cx, dy = ent.y-cy;
  const distSq = dx*dx+dy*dy;
  if(distSq < radius*radius){
   let d = Math.sqrt(distSq);
   if(d < 0.0001){
    // Entity center is fully enclosed inside the prop (clamp returned its own
    // coordinates) — dx/dy are both exactly 0, so there's no direction to push
    // along. Push out toward whichever edge of the rect is closest instead,
    // otherwise the entity silently stays stuck inside the building forever.
    const overlapLeft = ent.x-p.x, overlapRight = (p.x+p.w)-ent.x;
    const overlapTop = ent.y-p.y, overlapBottom = (p.y+p.h)-ent.y;
    const min = Math.min(overlapLeft,overlapRight,overlapTop,overlapBottom);
    if(min===overlapLeft) ent.x = p.x - radius - 4;
    else if(min===overlapRight) ent.x = p.x+p.w + radius + 4;
    else if(min===overlapTop) ent.y = p.y - radius - 4;
    else ent.y = p.y+p.h + radius + 4;
   } else {
    const push = (radius-d)+4;
    ent.x += (dx/d)*push; ent.y += (dy/d)*push;
   }
  }
 }
}
/* Finds a point just outside a building's footprint (below/above/right/left of
   it, whichever is clear of other props) so loot tied to a specific building
   — a vault, an armory, a locked office — is always physically reachable.
   Placing it at the building's *center* would put it inside solid geometry
   the player can never walk into, since every prop blocks movement. */
function pointOutsideProp(prop, props, w, h, margin){
 margin = margin===undefined ? 40 : margin;
 const cx = prop.x+prop.w/2, cy = prop.y+prop.h/2;
 const candidates = [
  {x:cx, y:prop.y+prop.h+margin},   // below
  {x:cx, y:prop.y-margin},          // above
  {x:prop.x+prop.w+margin, y:cy},   // right
  {x:prop.x-margin, y:cy}           // left
 ];
 for(const c of candidates){
  if(c.x<40 || c.x>w-40 || c.y<40 || c.y>h-40) continue;
  let clear = true;
  for(const p of props){
   if(p===prop) continue;
   if(rectOverlap(c.x-margin,c.y-margin,margin*2,margin*2, p.x,p.y,p.w,p.h)){ clear=false; break; }
  }
  if(clear) return c;
 }
 return null;
}

/* ================= ENTER LOCATION ================= */
function enterLocation(id){
 const loc = findLocation(id);
 // Promote Dr. Voss from "following" to "settled at camp" the instant camp is
 // reached, before the NPC list below is built — otherwise she'd vanish for
 // this one visit (too late to appear as the static infirmary NPC, but no
 // longer in the following-companion list either) and only reappear on the
 // next trip back to camp.
 if(id==='camp' && S.flags.doctor_following){
  S.flags.doctor_following = false;
  S.flags.doctor_at_camp = true;
  toast('Dr. Voss settles in at the camp infirmary.', 'amber');
 }
 S.currentLocation = id;
 S.inInterior = false;
 S.interiorReturn = null;
 W_exteriorBackup = null;
 const roads = buildRoads(loc);
 const props = buildProps(loc, roads);
 // Once the camp's three siege waves are cleared, it stays cleared for good —
 // don't let the generic per-visit zombie population (zRange) sneak fresh
 // zombies in every time the camp is re-entered from the map.
 const zCount = (id==='camp' && S.flags.camp_cleared) ? 0 : randInt(loc.zRange[0],loc.zRange[1]);
 const zombies = [];
 for(let i=0;i<zCount;i++){
  const z = spawnZombie(loc);
  const pt = randomOpenPoint(props, loc.w, loc.h, 24);
  z.x=pt.x; z.y=pt.y;
  zombies.push(z);
 }
 const bandits = [];
 if(loc.isBanditCamp){
  const n = randInt(7,11);
  for(let i=0;i<n;i++){
   const b = spawnBandit(loc);
   const pt = randomOpenPoint(props, loc.w, loc.h, 24);
   b.x=pt.x; b.y=pt.y;
   bandits.push(b);
  }
 } else if(!loc.noLoot && Math.random()<loc.banditChance*3){
  const n = randInt(1,3);
  for(let i=0;i<n;i++){
   const b = spawnBandit(loc);
   const pt = randomOpenPoint(props, loc.w, loc.h, 24);
   b.x=pt.x; b.y=pt.y;
   bandits.push(b);
  }
 }
 const crates = [];
 if(!loc.noLoot){
  const cCount = randInt(4,8);
  for(let i=0;i<cCount;i++){
   const pt = randomOpenPoint(props, loc.w, loc.h, 40);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'normal'});
  }
  if(loc.special && !S.flags[loc.special] && id!=='bank'){
   let pt;
   if(id==='bank'){
    const vaultProp = props.find(p=>p.label==='Vault');
    pt = vaultProp ? (pointOutsideProp(vaultProp, props, loc.w, loc.h, 40) || randomOpenPoint(props, loc.w, loc.h, 40)) : randomOpenPoint(props, loc.w, loc.h, 40);
   } else if(id==='police_station'){
    const armoryProp = props.find(p=>p.label==='Armory');
    pt = armoryProp ? (pointOutsideProp(armoryProp, props, loc.w, loc.h, 40) || randomOpenPoint(props, loc.w, loc.h, 40)) : randomOpenPoint(props, loc.w, loc.h, 40);
   } else if(id==='military_base'){
    const labProp = props.find(p=>p.label==='Deep Lab Access');
    pt = labProp ? (pointOutsideProp(labProp, props, loc.w, loc.h, 40) || randomOpenPoint(props, loc.w, loc.h, 40)) : randomOpenPoint(props, loc.w, loc.h, 40);
   } else {
    pt = randomOpenPoint(props, loc.w, loc.h, 40);
   }
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'special', flag:loc.special});
  }
  if(loc.keycardDrop && !findInv(S, loc.keycardDrop) && !S.flags['keycard_used_'+loc.keycardDrop]){
   let pt;
   if(id==='police_station'){
    const officeProp = props.find(p=>p.label==='ChiefsOffice');
    pt = officeProp ? (pointOutsideProp(officeProp, props, loc.w, loc.h, 40) || randomOpenPoint(props, loc.w, loc.h, 40)) : randomOpenPoint(props, loc.w, loc.h, 40);
   } else {
    pt = randomOpenPoint(props, loc.w, loc.h, 40);
   }
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'keycard', cardId:loc.keycardDrop});
  }
  const page = JOURNAL_PAGES.find(j=>j.loc===id && !j.special && !S.journalPages[j.id]);
  if(page){
   const pt = randomOpenPoint(props, loc.w, loc.h, 40);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'journal', pageId:page.id});
  }
 }
 let npcs = (NPC_MARKERS[id]||[]).filter(n=>!n.once || !S.flags[n.once])
  .filter(n=> !(id==='camp' && n.id==='camp_leader' && S.flags.camp_cleared))
  .map(n=>Object.assign({},n));
 if(id==='camp' && S.flags.doctor_at_camp){
  npcs.push({id:'doctor', name:'Dr. Voss', x:440, y:350, glyph:'⚕️', color:'#3fa0d8', dialogue:'camp_doctor'});
 }
 if(id==='warehouse' && S.flags.warehouse_choice==='fight'){
  const guardMarkers = npcs.filter(n=>n.isWarehouseGuard);
  npcs = npcs.filter(n=>!n.isWarehouseGuard);
  guardMarkers.forEach(gm=>{
   const b = spawnBandit(loc, Math.random()<0.5?'grunt':'hooded');
   b.x = gm.x; b.y = gm.y;
   bandits.push(b);
  });
 }
 npcs.forEach(n=>nudgeOutOfProps(n, props, 30));
 W = {
  locId:id, w:loc.w, h:loc.h,
  player:{x:loc.w/2, y:loc.h/2},
  zombies, bandits, npcs, crates, props, roads,
  projectiles:[], meleeFx:[], explosionFx:[], critFx:[], companionsEnt:[],
  campSpawnCd: 8000,
  guards: id==='camp' ? [
   {id:'bo', name:'Bo', x:125, y:150, atkCd:0, color:'#8ab82f'},
   {id:'nikita', name:'Nikita', x:loc.w-125, y:150, atkCd:0, color:'#8ab82f'}
  ] : null,
  turrets: id==='military_base' ? [
   {x:loc.w/2-320, y:220, dmg:16, range:420, atkCd:0},
   {x:loc.w/2+320, y:220, dmg:16, range:420, atkCd:0},
   {x:loc.w/2-200, y:loc.h/2+40, dmg:18, range:460, atkCd:0},
   {x:loc.w/2+200, y:loc.h/2+40, dmg:18, range:460, atkCd:0}
  ] : null
 };
 spawnCompanionsInWorld();
 updateHudLocation();
 S.visitedLocations[id] = true;
 if(Object.keys(S.visitedLocations).length >= LOCATIONS.length) unlockAchievement('well_traveled');
 if(id==='military_base' && S.flags.boss_pending && !S.flags.boss_defeated){ spawnBoss(); }
}
/* All 5 companions are always physically present at camp — recruited or not —
   so the player can walk up to any of them and see the recruit dialogue. Only
   recruited companions follow and fight alongside the player elsewhere. */
function spawnCompanionsInWorld(){
 if(!W) return;
 if(W.locId==='camp'){
  W.companionsEnt = COMPANIONS.map((c,i)=>{
   const recruited = S.companions.includes(c.id);
   const resting = recruited && !!S.companionResting[c.id];
   const isStatic = !recruited || resting;
   return {
    id:c.id, name:c.name, color:c.color,
    x: isStatic ? 280+i*70 : W.player.x+30+i*26,
    y: isStatic ? 270 : W.player.y+34,
    hp:400, maxHp:400, weapon:c.weapon, atkCd:0, recruited, isCampStatic:isStatic
   };
  });
  W.companionsEnt.forEach(c=>{ if(c.isCampStatic) nudgeOutOfProps(c,W.props,26); });
 } else {
  W.companionsEnt = COMPANIONS.filter(c=>S.companions.includes(c.id) && !S.companionResting[c.id]).map((c,i)=>({
   id:c.id, name:c.name, color:c.color, x:W.player.x+30+i*26, y:W.player.y+34, hp:400, maxHp:400,
   weapon:c.weapon, atkCd:0, recruited:true, isCampStatic:false
  }));
  if(S.flags.doctor_following){
   W.companionsEnt.push({id:'doctor_temp', name:'Dr. Voss', color:'#3fa0d8', x:W.player.x+30, y:W.player.y+34, hp:200, maxHp:200, weapon:null, atkCd:0, recruited:true, isCampStatic:false});
  }
  // Companions/doctor spawn just offset from the player's entry point — nudge
  // them clear of any prop in case that offset happens to land inside a wall.
  W.companionsEnt.forEach(c=>nudgeOutOfProps(c,W.props,26));
 }
}

/* ================= BOSS ================= */
function wanderStep(ent, dt){
 if(ent.homeX===undefined){ ent.homeX=ent.x; ent.homeY=ent.y; }
 ent._wanderCd = (ent._wanderCd||0) - dt;
 if(ent._wanderCd<=0){
  ent._wanderCd = rand(2500,5500);
  ent._tx = ent.homeX + rand(-55,55);
  ent._ty = ent.homeY + rand(-55,55);
 }
 if(ent._tx!==undefined){
  const d = dist(ent.x,ent.y,ent._tx,ent._ty);
  if(d>4){ const a=angleTo(ent.x,ent.y,ent._tx,ent._ty); ent.x += Math.cos(a)*0.35*(dt/16); ent.y += Math.sin(a)*0.35*(dt/16); }
 }
}
function updateCampAmbience(dt){
 if(!S.flags.camp_cleared) return;
 W.npcs.forEach(n=> wanderStep(n,dt));
 if(W.companionsEnt) W.companionsEnt.forEach(c=>{ if(c.isCampStatic) wanderStep(c,dt); });
}
function updateWanderingNpcs(dt){
 if(!W || !W.npcs || W.isInterior) return;
 W.npcs.forEach(n=>{ if(n.wander) wanderStep(n,dt); });
}
function updateTurrets(dt){
 if(!W || !W.turrets) return;
 W.turrets.forEach(t=>{
  t.atkCd -= dt;
  if(t.atkCd>0) return;
  let target=null, nd=t.range;
  const dp = dist(t.x,t.y,W.player.x,W.player.y);
  if(dp<nd){ target=W.player; nd=dp; }
  if(W.boss){
   const db = dist(t.x,t.y,W.boss.x,W.boss.y);
   if(db<nd){ target=W.boss; nd=db; }
  }
  if(!target) return;
  t.atkCd = 900;
  const a = angleTo(t.x,t.y,target.x,target.y);
  W.projectiles.push({x:t.x,y:t.y, vx:Math.cos(a)*600, vy:Math.sin(a)*600, dmg:t.dmg, life:800, owner:'turret', targetBoss: target===W.boss});
 });
}
/* Barbwire only takes damage while an actual siege wave is in progress, and
   only from zombies that are currently pressed up against it — a hidden
   durability (3 hits) per segment, never surfaced in any UI. Once the siege
   ends, S.flags.camp_cleared stops this from ever running again, and the
   very next enterLocation('camp') rebuilds every prop from scratch anyway —
   so a torn segment is automatically "repaired" for good the moment the
   camp is secured. */
function updateBarbwire(dt){
 if(!(S.campSiege && S.campSiege.active)) return;
 const wires = W.props.filter(p=>p.isBarbwire && p.hp>0);
 if(!wires.length) return;
 let breached = null;
 W.zombies.forEach(z=>{
  for(const w of wires){
   if(w.hp<=0) continue;
   const cx = clamp(z.x, w.x, w.x+w.w), cy = clamp(z.y, w.y, w.y+w.h);
   if(dist(z.x,z.y,cx,cy) < 34 && Math.random() < 0.012){
    w.hp--;
    if(w.hp<=0) breached = w;
   }
  }
 });
 if(breached){
  W.props = W.props.filter(p=>p!==breached);
  toast('The zombies have torn a hole in the wire!', 'bad');
 }
}
function updateGuards(dt){
 if(!W.guards) return;
 W.guards.forEach(g=>{
  const targets = W.zombies;
  if(!targets.length) return;
  let nearest=null, nd=9999;
  targets.forEach(t=>{ const dd=dist(g.x,g.y,t.x,t.y); if(dd<nd){nd=dd;nearest=t;} });
  if(nearest && nd<280){
   g.atkCd -= dt;
   if(g.atkCd<=0){
    g.atkCd = 650;
    const a = angleTo(g.x,g.y,nearest.x,nearest.y);
    W.projectiles.push({x:g.x,y:g.y, vx:Math.cos(a)*560, vy:Math.sin(a)*560, dmg:15, life:700, owner:'companion', color:g.color});
   }
  }
 });
}
function spawnCampWave(waveNum){
 if(!W) return;
 const loc = findLocation('camp');
 for(let i=0;i<10;i++){
  const z = spawnZombie(loc);
  z.x = pick([20, W.w-20]);
  z.y = rand(20, W.h-20);
  W.zombies.push(z);
 }
}
function spawnBoss(){
 W.boss = {kind:'boss', x:W.w/2, y:W.h/2+60, hp:50000, maxHp:50000, dmg:26, speed:0.7, atkCd:0, r:34};
 document.getElementById('bossbar').style.display='block';
 toast('The Harrowed stirs.', 'bad');
}
function onBossDefeated(){
 S.flags.boss_pending = false;
 document.getElementById('bossbar').style.display='none';
 gainXP(300);
 openDialogue('final_choice');
}
function resolveEnding(choice){
 // Killing the Harrowed no longer ends the run on the spot — the player
 // still picks what happens to the RVL-9 samples here (that choice is
 // remembered for the real ending later), grabs whatever the Harrowed had
 // on it, then has to make it back to camp and tell Elias before the county
 // is actually behind them. See tryBoardTruck() for where the game actually
 // ends. ("Revelation" itself already completed back when the bunker door
 // was opened with the Level 1 keycard — see the boss_arena crate handler.)
 S.flags.boss_defeated = true;
 let final = choice;
 if(choice==='good' && (S.karma<10 || S.charisma<10)) final='neutral';
 S.endingChoice = final;
 activateNextQuests();
 addToInventory(S,'ridge_keycard_l2','quest',1);
 toast('You pry a Level 2 Access Keycard from the wreckage.', 'amber');
 toast('New objective: The Way Out — get back to camp.', 'amber');
}
const ENDING_COPY = {
 good:{title:'THE LONG DAWN', body:"The incinerator array roars to life beneath the Ridge, and RVL-9 burns with it — every sample, every note, every chance of this happening again. It costs the lab, and it costs you something too. But when you walk out to the tree line, Harrow County's survivors are still there, waiting, and for the first time in months, nobody is looking over their shoulder. You didn't save everything. You saved enough."},
 bad:{title:'NEW BUYER', body:"The samples go into a case, the case goes into a truck, and somewhere down the line someone with a lot of money stops asking where they came from. Harrow County doesn't get its answers. It gets a payout instead, and a very quiet warning never to ask what RVL-9 was really worth."},
 neutral:{title:'QUIET GROUND', body:"You seal the lab and walk away from it, samples and all, and tell yourself that's the responsible choice. Maybe it is. The Ridge goes quiet again, the county keeps digging out from what's already happened, and nobody ever really finds out what was down there. Some doors are better left shut."},
 death:{title:'DID NOT MAKE IT', body:"Harrow County keeps score whether you're there to see it or not. Your name goes on the fence with the others — one more marker in a county that ran out of room for them a long time ago."}
};
function renderEnding(kind, isDeath){
 const screen = document.getElementById('screen-ending');
 screen.className = 'screen active end-'+(isDeath?'bad':kind);
 const copy = isDeath ? ENDING_COPY.death : (ENDING_COPY[kind]||ENDING_COPY.neutral);
 document.getElementById('end-title').textContent = copy.title;
 document.getElementById('end-body').textContent = copy.body;
 const stats = document.getElementById('end-stats');
 const journalCount = Object.keys(S.journalPages).length;
 const achCount = Object.values(S.achievements).filter(Boolean).length;
 stats.innerHTML = [
  ['Level Reached', S.level], ['Zombies Killed', S.kills], ['Bandits Killed', S.banditKills],
  ['Charisma', S.charisma], ['Karma', (S.karma>=0?'+':'')+S.karma], ['Companions', S.companions.length+'/'+COMPANIONS.length],
  ['Journal Pages', journalCount+'/'+JOURNAL_PAGES.length], ['Achievements', achCount+'/'+ACHIEVEMENTS.length]
 ].map(([label,val])=>`<div><b>${val}</b>${label}</div>`).join('');
 document.getElementById('bossbar').style.display='none';
}

/* ================= DAMAGE / STATUS ================= */
function applyBuffMult(stat, base){
 let mult=1;
 S.buffs.forEach(b=>{ if(b.stat===stat && b.mult) mult*=b.mult; });
 return base*mult;
}
function trophyBonusSum(boostKey){
 let n=0;
 for(const vid in S.trophyClaimed){ if(S.trophyClaimed[vid] && TROPHY_DEFS[vid] && TROPHY_DEFS[vid].boost===boostKey) n++; }
 return n;
}
function claimTrophy(variantId){
 const def = TROPHY_DEFS[variantId]; if(!def) return;
 const kills = S.trophyKills[variantId]||0;
 if(kills < def.threshold){ toast('Not enough kills yet.', 'bad'); return; }
 if(S.trophyClaimed[variantId]){ toast('Already claimed.', 'bad'); return; }
 S.trophyClaimed[variantId] = true;
 const boost = TROPHY_BOOSTS[def.boost];
 if(def.boost==='hp'){ S.maxHp += 15; S.hp += 15; }
 if(def.boost==='carry'){
  const b = S.equipped.backpack ? BACKPACKS[S.equipped.backpack] : null;
  S.carryCap = BACKPACK_BASE_CAPACITY + (b?b.bonus:0) + (S.skills.packmule?15:0) + trophyBonusSum('carry')*15;
 }
 toast('Trophy claimed: '+boost.name+' ('+boost.desc+')', 'amber');
 renderAchModal();
 updateHudDynamic();
}
/* The Harrowed's trophy is a one-off, not a kill-count threshold like every
   other trophy — it unlocks the instant the boss is dead and stacks four
   huge bonuses at once (flat, not the usual per-point trophy multipliers),
   since this is the single biggest, one-time reward in the game. */
function claimHarrowedTrophy(){
 if(!S.flags.boss_defeated){ toast('Not defeated yet.', 'bad'); return; }
 if(S.trophyClaimed.harrowed){ toast('Already claimed.', 'bad'); return; }
 S.trophyClaimed.harrowed = true;
 S.maxHp += 100; S.hp += 100;
 toast('Trophy claimed: The Harrowed — +100 Damage, +50 Defense, +3 Speed, +100 Health.', 'amber');
 renderAchModal();
 updateHudDynamic();
}
function renderTrophiesModal(body){
 body.innerHTML='';
 const harrowedClaimed = !!S.trophyClaimed.harrowed;
 const harrowedReady = S.flags.boss_defeated && !harrowedClaimed;
 const hHead = document.createElement('div'); hHead.className='trophy-group-head'; hHead.textContent='The Harrowed';
 body.appendChild(hHead);
 const hRow = document.createElement('div'); hRow.className='trophy-row'+(harrowedClaimed?' claimed':'')+(harrowedReady?' ready':'');
 hRow.innerHTML = `
  <div class="trophy-ic"><img class="trophy-ic-img" src="${getVariantIconDataUrl('boss','harrowed')}" alt="The Harrowed"></div>
  <div class="trophy-info">
   <div class="trophy-nm">The Harrowed</div>
   <div class="trophy-kc">${S.flags.boss_defeated ? '1 / 1 killed' : '0 / 1 killed'}</div>
   <div class="trophy-bd">💥 Revelation's End — +100 Damage (all weapons), +50 Defense, +3 Speed, +100 Health</div>
  </div>
 `;
 const hBtn = document.createElement('button'); hBtn.className='btn btn-small';
 hBtn.textContent = harrowedClaimed ? 'Claimed' : 'Claim';
 hBtn.disabled = harrowedClaimed || !harrowedReady;
 hBtn.onclick = ()=> claimHarrowedTrophy();
 hRow.appendChild(hBtn);
 body.appendChild(hRow);

 const rows = [
  ...Object.keys(ZOMBIE_VARIANTS).filter(id=>id!=='walker').map(id=>({id, def:ZOMBIE_VARIANTS[id], group:'Zombies'})),
  ...Object.keys(BANDIT_VARIANTS).map(id=>({id, def:BANDIT_VARIANTS[id], group:'Bandits'}))
 ];
 let lastGroup=null;
 rows.forEach(r=>{
  if(r.group!==lastGroup){
   lastGroup=r.group;
   const h = document.createElement('div'); h.className='trophy-group-head'; h.textContent=r.group;
   body.appendChild(h);
  }
  const tdef = TROPHY_DEFS[r.id];
  const kills = S.trophyKills[r.id]||0;
  const claimed = !!S.trophyClaimed[r.id];
  const ready = !claimed && kills>=tdef.threshold;
  const boost = TROPHY_BOOSTS[tdef.boost];
  const row = document.createElement('div'); row.className='trophy-row'+(claimed?' claimed':'')+(ready?' ready':'');
  row.innerHTML = `
   <div class="trophy-ic"><img class="trophy-ic-img" src="${getVariantIconDataUrl(r.group==='Zombies'?'zombie':'bandit', r.id)}" alt="${r.def.name}"></div>
   <div class="trophy-info">
    <div class="trophy-nm">${r.def.name}</div>
    <div class="trophy-kc">${kills} / ${tdef.threshold} killed</div>
    <div class="trophy-bd">${boost.icon} ${boost.name} — ${boost.desc}</div>
   </div>
  `;
  const btn = document.createElement('button'); btn.className='btn btn-small';
  btn.textContent = claimed ? 'Claimed' : 'Claim';
  btn.disabled = claimed || !ready;
  btn.onclick = ()=> claimTrophy(r.id);
  row.appendChild(btn);
  body.appendChild(row);
 });
}
function meleeDamageMult(){
 let m=1;
 if(S.skills.melee_mastery) m*=1.15;
 if(S.role==='Lumberjack') m*=1.20;
 m = applyBuffMult('meleeDmg', m);
 m *= (1 + trophyBonusSum('melee')*0.12);
 return m;
}
function rangedDamageMult(weaponId){
 let m=1;
 if(S.skills.marksman) m*=1.15;
 if(S.skills.heavy_hands && (weaponId==='rpg'||weaponId==='law'||weaponId==='saw')) m*=1.20;
 const w = WEAPONS_RANGED[weaponId];
 if(w && w.slot==='secondary') m = applyBuffMult('apPistolDmg', m);
 if(w && w.slot==='primary') m = applyBuffMult('apRifleDmg', m);
 m *= (1 + trophyBonusSum('ranged')*0.12);
 return m;
}
function armorReduction(){
 const harrowedBonus = (S.trophyClaimed && S.trophyClaimed.harrowed) ? 0.50 : 0;
 if(!S.equipped.armor || S.armorDurability<=0) return Math.min(0.97, trophyBonusSum('armor')*0.10 + harrowedBonus);
 let r = ARMOR[S.equipped.armor].reduction;
 if(S.skills.armorer) r = Math.min(0.95, r+0.05);
 r = Math.min(0.97, r + trophyBonusSum('armor')*0.10 + harrowedBonus);
 return r;
}
function damagePlayer(dmg, kind){
 if(kind==='melee' && S.skills.evasive && Math.random()<0.08){ toast('Dodged!', 'amber'); return; }
 let r = armorReduction();
 let inRoster = COMPANIONS.find(c=>c.id==='rorke' && S.companions.includes('rorke'));
 if(inRoster) dmg *= 0.9;
 dmg *= (1-r);
 S.hp -= dmg;
 if(S.equipped.armor && S.armorDurability>0){
  S.armorDurability -= (S.skills.armorer?1.6:2);
  if(S.armorDurability<=0){ toast(ARMOR[S.equipped.armor].name+' broke!', 'bad'); S.equipped.armor=null; }
 }
 if(kind==='zombie'){
  if(Math.random()<0.28) inflictStatus('bleeding', 15000);
  if(Math.random()<0.14) inflictStatus('infected', 0);
  if(Math.random()<0.08) inflictStatus('sick', 20000);
 } else if(kind==='zombie_ranged'){
  if(Math.random()<0.22) inflictStatus('bleeding', 13000);
 } else if(kind==='melee' || kind==='ranged'){
  if(Math.random()<0.20) inflictStatus('bleeding', 13000);
 } else if(kind==='rock'){
  if(Math.random()<0.30) inflictStatus('bleeding', 16000);
 } else if(kind==='turret'){
  if(Math.random()<0.18) inflictStatus('bleeding', 12000);
 }
 if(S.hp<=0){
  if(!S.secondWindUsed && S.skills.second_wind){ S.secondWindUsed=true; S.hp=1; toast('Second Wind! You barely survive.', 'amber'); }
  else onPlayerDeath();
 } else if(S.hp <= 5){ unlockAchievement('iron_will'); }
}
function inflictStatus(type, ms){
 if(type==='infected' && S.equipped.armor==='cbrn') return; // CBRN suit blocks infection entirely
 if(type==='bleeding') S.status.bleeding = Math.max(S.status.bleeding, ms);
 else if(type==='sick') S.status.sick = Math.max(S.status.sick, ms);
 else if(type==='infected'){
  S.status.infected = 1;
  S.status.infectedSeverity = Math.min(3, S.status.infectedSeverity+1);
 }
}
function cureStatus(key){
 if(key==='bleeding') S.status.bleeding = 0;
 else if(key==='sick') S.status.sick = 0;
 else if(key==='infected'){ S.status.infected=0; S.status.infectedSeverity=0; }
 else if(key==='infected_early'){ if(S.status.infectedSeverity<=1){ S.status.infected=0; S.status.infectedSeverity=0; toast('Antibiotics worked.', 'amber'); } else toast("Too far gone — you need a Serum.", 'bad'); }
}
function onPlayerDeath(){
 S.hp = 0;
 renderEnding('bad', true);
 Game.goto('ending');
}

function damageEntity(ent, dmg, isPlayerSource){
 if(isPlayerSource){
  const critChance = trophyBonusSum('crit')*0.05;
  if(critChance>0 && Math.random()<critChance){
   dmg *= 1.75;
   W.critFx.push({x:ent.x, y:ent.y, life:500, maxLife:500});
  }
 }
 ent.hp -= dmg;
 if(ent.hp<=0) killEntity(ent, isPlayerSource);
}
function killEntity(ent, isPlayerSource){
 if(ent.kind==='zombie'){
  W.zombies = W.zombies.filter(z=>z!==ent);
  if(isPlayerSource){
   S.kills++;
   if(S.currentLocation==='camp') S.campKills++;
   const zv = ZOMBIE_VARIANTS[ent.variant] || ZOMBIE_VARIANTS.walker;
   gainXP(8 + findLocation(S.currentLocation).tier*2 + (zv.threat||1)*2);
   S.trophyKills[ent.variant] = (S.trophyKills[ent.variant]||0)+1;
   if(S.kills===1) unlockAchievement('first_blood');
   if(S.kills>=50) unlockAchievement('exterminator');
   if(S.campKills>=20) unlockAchievement('camp_defender');
   progressQuestKill();
   progressSideKillQuests('zombie');
  }
 } else if(ent.kind==='bandit'){
  W.bandits = W.bandits.filter(b=>b!==ent);
  if(isPlayerSource){
   S.banditKills++;
   const bv = BANDIT_VARIANTS[ent.variant] || BANDIT_VARIANTS.grunt;
   gainXP(10 + (bv.threat||1)*8);
   S.trophyKills[ent.variant] = (S.trophyKills[ent.variant]||0)+1;
   if(S.banditKills>=25) unlockAchievement('bandit_hunter');
   progressSideKillQuests('bandit');
  }
 } else if(ent.kind==='boss'){
  W.boss = null;
  onBossDefeated();
 }
}
function progressQuestKill(){
 // Only kills landed during an actual accepted siege wave should count toward
 // "Camp Fire" — otherwise ambient zombies wandering into camp before the
 // player ever agrees to help Elias (or after the siege is long over) could
 // silently finish the quest without S.flags.camp_cleared ever being set,
 // leaving Elias stuck offering the same "help me clear it out" line forever
 // while the quest log claims the objective is already complete.
 if(S.questsMain.m2 && S.questsMain.m2.status==='active' && S.currentLocation==='camp' && S.campSiege && S.campSiege.active){
  S.questsMain.m2.progress++;
  if(S.questsMain.m2.progress>=MAIN_QUESTS.m2.target){ S.questsMain.m2.status='done'; activateNextQuests(); toast('Objective complete: Camp Fire', 'amber'); }
 }
}

/* ================= XP / LEVEL / SKILLS ================= */
function gainXP(n){
 if(S.role==='Citizen') n = Math.round(n*1.1);
 S.xp += n;
 while(S.xp>=S.xpNext && S.level<MAX_LEVEL){
  S.xp -= S.xpNext; S.level++; S.skillPoints++; S.xpNext = xpToNext(S.level);
  toast('Level up! Now level '+S.level, 'amber');
  if(S.level>=25) unlockAchievement('hardened_survivor');
 }
 updateHudDynamic();
}
function unlockSkill(id){
 let node=null;
 for(const branch in SKILL_TREE){ const f = SKILL_TREE[branch].find(n=>n.id===id); if(f){node=f;break;} }
 if(!node || S.skills[id]) return;
 if(node.req && !S.skills[node.req]){ toast('Requires a prerequisite skill.', 'bad'); return; }
 if(S.skillPoints<node.cost){ toast('Not enough skill points.', 'bad'); return; }
 S.skillPoints -= node.cost; S.skills[id]=true;
 if(id==='thick_skin') S.maxHp += 20;
 if(id==='packmule') S.carryCap += 15;
 toast('Unlocked: '+node.name, 'amber');
 renderSkillsModal(); updateHudDynamic();
}

/* ================= ACHIEVEMENTS ================= */
function unlockAchievement(id){
 if(S.achievements[id]) return;
 S.achievements[id] = true;
 const a = ACHIEVEMENTS.find(x=>x.id===id);
 toast('Achievement: '+(a?a.name:id), 'amber');
}
function checkAchievements(){
 if(carryWeight(S)>=40) unlockAchievement('pack_rat');
 if(S.charisma>=15) unlockAchievement('silver_tongue');
 if(S.karma>=30) unlockAchievement('good_samaritan');
 if(S.karma<=-15) unlockAchievement('hard_case');
 const rangedOwned = new Set();
 Object.values(S.weaponSlots).forEach(w=>{ if(w && WEAPONS_RANGED[w]) rangedOwned.add(w); });
 S.inventory.forEach(i=>{ if(WEAPONS_RANGED[i.id]) rangedOwned.add(i.id); });
 if(rangedOwned.size>=5) unlockAchievement('armory_complete');
 const journalCount = Object.keys(S.journalPages).length;
 if(journalCount>=1) unlockAchievement('first_page');
 if(journalCount>=JOURNAL_PAGES.length) unlockAchievement('complete_journal');
 const sideDone = Object.values(S.questsSide).filter(q=>q.status==='done').length;
 if(sideDone>=10) unlockAchievement('side_hustler');
}

/* ================= QUESTS ================= */
function activateNextQuests(){
 // Walk every main quest each time (not just the first still-locked one) —
 // m5 (Bedside Manner) and m6 (Warehouse Floor) are parallel branches that
 // both only depend on m2 being done, not on each other. Stopping at the
 // first locked quest meant m6 could never unlock while the player simply
 // hadn't talked to Elias about the distress signal yet, even though m6's
 // own prerequisite was already satisfied.
 const order = ['m1','m2','m5','m6','m7','m8','m9'];
 for(const id of order){
  const q = S.questsMain[id];
  if(q.status==='locked'){
   if(id==='m1'){ q.status='active'; }
   else if(id==='m2' && S.questsMain.m1.status==='done'){ q.status='active'; }
   else if(id==='m5' && S.questsMain.m2.status==='done' && S.flags.doctor_quest_given){ q.status='active'; }
   else if(id==='m6' && S.questsMain.m2.status==='done'){ q.status='active'; }
   else if(id==='m7' && S.flags.hospital_choice_done && S.flags.warehouse_choice_done){ q.status='active'; }
   else if(id==='m8' && S.flags.boss_pending){ q.status='active'; }
   else if(id==='m9' && S.questsMain.m8.status==='done'){ q.status='active'; }
  }
 }
 for(const id in S.questsSide){
  if(S.questsSide[id].status==='locked') S.questsSide[id].status='active';
 }
 renderQuestsModal();
}
function completeQuestByFlag(flag){
 for(const id in S.questsMain){ if(MAIN_QUESTS[id].flag===flag && S.questsMain[id].status==='active'){ S.questsMain[id].status='done'; } }
 for(const id in S.questsSide){ if(SIDE_QUESTS[id].flag===flag && S.questsSide[id].status==='active'){ S.questsSide[id].status='done'; } }
 activateNextQuests();
}
function progressLootQuest(){
 if(S.questsMain.m1 && S.questsMain.m1.status==='active'){
  S.questsMain.m1.progress++;
  if(S.questsMain.m1.progress>=MAIN_QUESTS.m1.target){ S.questsMain.m1.status='done'; activateNextQuests(); toast('Objective complete: First Light', 'amber'); }
 }
}

/* ================= LOOT ================= */
/* Shared feedback for ANY keycard/key-gated door in the game: a toast naming
   exactly which item is needed, plus a short inner-monologue dialogue so the
   player isn't left guessing what to look for or where it might be. */
function lockedDoorFeedback(cardId, doorText){
 const card = findKeycardById(cardId);
 const itemName = card ? card.name : 'the right keycard';
 toast(doorText+' Requires: '+itemName+'.', 'bad');
 lockedDoorContext = {doorText, itemName};
 openDialogue('locked_room');
}
const LOOT_TABLE = {
 1:[['ammo_mm9','ammo',6],['bandage','med',3],['jerky','food',3],['bread','food',3],['popcola','drink',3],['knife','weapon_melee',1]],
 2:[['ammo_rifle','ammo',5],['medkit','med',2],['chips','food',3],['protein','food',2],['nukacola','drink',2],['ninemm','weapon_ranged',1]],
 3:[['ammo_shells','ammo',4],['antibiotics','med',1],['rice','food',2],['royal','drink',2],['ak47','weapon_ranged',1],['civilian','armor',1],['revolver','weapon_ranged',1]],
 4:[['ammo_rocket','ammo',2],['medkit','med',2],['megacrusher','drink',2],['fitz','drink',2],['spas12','weapon_ranged',1],['hunter','armor',1],['scar','weapon_ranged',1],['m1garand','weapon_ranged',1]]
};
const SPECIAL_FIND_NAMES = {
 vault_cracked:'the bank vault open', quarantine_files:'the quarantine files', black_box:"the aircraft's black box", diplomatic_pouch:'a sealed diplomatic pouch'
};
let lootPending = null; // {items:[{id,kind,qty,rare}], tokens}
function lootVehicle(p){
 if(p.vehicleLoot.looted) return;
 p.vehicleLoot.looted = true;
 if(!p.vehicleLoot.hasLoot){ toast('Empty. Already picked clean.', 'bad'); return; }
 if(p.vehicleLoot.kind==='ambulance'){
  const pool=['bandage','medkit','antibiotics'];
  const id=pool[Math.floor(Math.random()*pool.length)];
  const qty=randInt(1,3);
  addToInventory(S,id,'med',qty);
  toast('Found '+qty+'x '+itemDisplayName(id)+' in the ambulance.', 'amber');
 } else if(p.vehicleLoot.kind==='police'){
  if(Math.random()<0.3){
   const gunPool=['ninemm','revolver'];
   const id=gunPool[Math.floor(Math.random()*gunPool.length)];
   giveWeaponItem(S,id);
   toast('Found a '+itemDisplayName(id)+' in the trunk.', 'amber');
  } else {
   const pool=['ammo_mm9','ammo_magnum','ammo_shells'];
   const id=pool[Math.floor(Math.random()*pool.length)];
   const qty=randInt(4,10);
   addToInventory(S,id,'ammo',qty);
   toast('Found '+qty+'x '+itemDisplayName(id)+' in the cruiser.', 'amber');
  }
 }
 renderInventoryModal();
}
function lootCrate(crate){
 if(crate.looted) return;
 if(crate.kind==='journal'){
  crate.looted = true;
  const page = findJournalPage(crate.pageId);
  S.journalPages[crate.pageId] = true;
  toast('Journal page found: '+(page?page.title:'???'), 'amber');
  progressJournalQuest();
  checkAchievements();
  return;
 }
 if(crate.kind==='keycard'){
  crate.looted = true;
  const card = findKeycardById(crate.cardId);
  addToInventory(S, crate.cardId, 'quest', 1);
  toast('Found: '+(card?card.name:'a keycard'), 'amber');
  renderInventoryModal();
  return;
 }
 if(crate.kind==='vault_loot'){
  crate.looted = true;
  const bars = randInt(10,25);
  const items = [{id:'gold_bars',kind:'quest',qty:bars}];
  if(Math.random()<0.3){
   const bonusPool = [['ammo_mm9','ammo'],['ammo_rifle','ammo'],['bandage','med']];
   const [bId,bKind] = pick(bonusPool);
   items.push({id:bId, kind:bKind, qty:randInt(3,8)});
  }
  openLootPanel(items, randInt(0,10));
  return;
 }
 if(crate.kind==='fixed_loot'){
  crate.looted = true;
  // Unique, one-time reward crates (the North Ridge L2 vault) — no random
  // rolls, exactly the items assigned when the crate was created.
  openLootPanel(crate.items.map(it=>({...it})), crate.tokens||0);
  return;
 }
 if(crate.kind==='special'){
  const flag = crate.flag;
  if(flag==='armory_unlocked' && !findInv(S,'police_armory_key')){
   lockedDoorFeedback('police_armory_key', "The armory cage is padlocked.");
   return;
  }
  if(flag==='boss_arena' && !findInv(S,'ridge_keycard')){
   lockedDoorFeedback('ridge_keycard', "The bunker door reads LEVEL 1 CLEARANCE REQUIRED.");
   return;
  }
  crate.looted = true;
  if(flag==='boss_arena'){
   removeFromInventory(S,'ridge_keycard',1);
   S.flags['keycard_used_ridge_keycard'] = true;
   S.flags.boss_pending=true;
   S.flags.boss_arena=true;
   activateNextQuests(); // boss_pending just went true — lets m8 leave 'locked'
   if(S.questsMain.m7 && S.questsMain.m7.status==='active'){ S.questsMain.m7.status='done'; toast('Objective complete: North Ridge', 'amber'); }
   if(S.questsMain.m8 && S.questsMain.m8.status==='active'){ S.questsMain.m8.status='done'; toast('Objective complete: Revelation', 'amber'); }
   activateNextQuests();
   openDialogue('boss_intro');
  }
  else if(flag==='armory_unlocked'){
   removeFromInventory(S,'police_armory_key',1);
   S.flags['keycard_used_police_armory_key'] = true;
   S.flags[flag] = true;
   const gunPool = ['ninemm','revolver','ak47','m16','spas12'];
   const throwPool = ['grenade','molotov','pipebomb'];
   const items = [];
   for(let i=0;i<2;i++) items.push({id:gunPool[Math.floor(Math.random()*gunPool.length)], kind:'weapon_ranged', qty:1});
   for(let i=0;i<2;i++) items.push({id:throwPool[Math.floor(Math.random()*throwPool.length)], kind:'weapon_throwable', qty:1});
   items.push({id:'ammo_mm9', kind:'ammo', qty:randInt(10,20)});
   items.push({id:'ammo_rifle', kind:'ammo', qty:randInt(10,20)});
   items.push({id:'ammo_shells', kind:'ammo', qty:randInt(6,12)});
   completeQuestByFlag(flag);
   openLootPanel(items, randInt(10,30));
   return;
  } else {
   S.flags[flag] = true;
   toast('You find '+(SPECIAL_FIND_NAMES[flag]||'something important')+'.', 'amber');
   if(flag==='quarantine_files' && !S.journalPages['j18']){
    S.journalPages['j18'] = true;
    toast('New journal page: "Subject Zero — Containment Failure Report"', 'amber');
   }
   completeQuestByFlag(flag);
  }
  activateNextQuests();
  return;
 }
 crate.looted = true;
 // Loot-at side quests (Overdue Books, Grocery Run, etc.) track crates
 // *found*, not items taken out of them — progressing this here, once per
 // crate, keeps it consistent regardless of whether the player uses "Take
 // All" or takes items one at a time from the loot panel afterward.
 progressLootQuest(); progressLootAtQuests(S.currentLocation);
 const loc = findLocation(S.currentLocation);
 const table = LOOT_TABLE[loc.lootTier] || LOOT_TABLE[1];
 let rolls = randInt(1,2) + (S.skills.scavenger?1:0);
 const lootBoostChance = trophyBonusSum('loot')*0.15;
 if(lootBoostChance>0 && Math.random()<lootBoostChance) rolls++;
 const items = [];
 for(let i=0;i<rolls;i++){
  const entry = pick(table);
  let [id,kind,maxQty] = entry;
  let qty = kind==='ammo' ? randInt(4,12) : randInt(1,maxQty);
  items.push({id,kind,qty});
 }
 if(Math.random()<0.03) items.push({id:'serum',kind:'med',qty:1,rare:true});
 openLootPanel(items, randInt(0,4));
}
function openLootPanel(items, tokens){
 lootPending = {items, tokens};
 Game.showModal('loot');
 const body = document.getElementById('loot-body');
 const takeAllBtn = document.getElementById('loot-takeall');
 if(body) body.innerHTML = '<div class="loot-loading"><div class="loot-spinner"></div><div>Searching...</div></div>';
 if(takeAllBtn) takeAllBtn.style.display='none';
 setTimeout(renderLootPanel, 650);
}
function renderLootPanel(){
 const body = document.getElementById('loot-body');
 const takeAllBtn = document.getElementById('loot-takeall');
 if(!body || !lootPending) return;
 body.innerHTML = '';
 const hasItems = lootPending.items.length>0;
 const hasTokens = lootPending.tokens>0;
 if(takeAllBtn) takeAllBtn.style.display = (hasItems||hasTokens) ? '' : 'none';
 if(!hasItems && !hasTokens){
  body.innerHTML = '<div class="inv-empty">Nothing left in here.</div>';
  return;
 }
 if(hasTokens){
  const row = document.createElement('div'); row.className='loot-row';
  row.innerHTML = `<span class="loot-ic"><span class="icon-emoji">🪙</span></span><span class="loot-nm">Tokens</span><span class="loot-qty">×${lootPending.tokens}</span>`;
  const btn = document.createElement('button'); btn.className='btn btn-small'; btn.textContent='Take';
  btn.onclick = ()=>{ S.tokens += lootPending.tokens; lootPending.tokens = 0; updateHudDynamic(); renderLootPanel(); };
  row.appendChild(btn); body.appendChild(row);
 }
 lootPending.items.forEach((it,idx)=>{
  const isEquippable = it.kind==='armor' || it.kind==='backpack';
  const row = document.createElement('div'); row.className='loot-row'+(it.kind==='armor'?' loot-set':'');
  row.innerHTML = `<span class="loot-ic">${itemIcon(it.id,it.kind)}</span><span class="loot-nm">${itemDisplayName(it.id)}${it.rare?' <b class="loot-rare">RARE</b>':''}${isEquippable?' <span class="loot-hint">(right-click to equip)</span>':''}</span><span class="loot-qty">×${Math.round(it.qty)}</span>`;
  const btn = document.createElement('button'); btn.className='btn btn-small'; btn.textContent='Take';
  btn.onclick = ()=> takeLootItem(idx);
  row.appendChild(btn);
  if(isEquippable) row.oncontextmenu = (e)=>{ e.preventDefault(); showLootCtxMenu(e, idx); };
  body.appendChild(row);
 });
}
function grantPlasmaRifle(){
 // The Plasma Rifle is a permanent reward weapon — it never touches the
 // inventory array at all, so it can't be dropped, sold, or counted toward
 // carry weight, and it locks the rocket slot so RPG/LAW can't bump it out.
 S.weaponSlots.rocket = 'plasma_rifle';
 S.magAmmo.rocket = 0;
 toast('The Plasma Rifle locks into your rocket slot. No ammo required.', 'amber');
 renderWeaponSlots();
}
function takeLootItem(idx){
 if(!lootPending) return;
 const it = lootPending.items[idx]; if(!it) return;
 if(it.id==='plasma_rifle'){
  grantPlasmaRifle();
 } else if(it.kind==='weapon_melee'||it.kind==='weapon_ranged'||it.kind==='weapon_throwable'){
  giveWeaponItem(S, it.id); toast('Took '+findWeaponById(it.id).name, 'amber');
 } else {
  addToInventory(S, it.id, it.kind, it.qty);
  toast('Took '+Math.round(it.qty)+'x '+itemDisplayName(it.id), 'amber');
 }
 lootPending.items.splice(idx,1);
 checkAchievements();
 renderInventoryModal(); renderWeaponSlots();
 renderLootPanel();
}
function takeAllLoot(){
 if(!lootPending) return;
 if(lootPending.tokens>0){ S.tokens += lootPending.tokens; lootPending.tokens = 0; }
 [...lootPending.items].forEach(it=>{
  if(it.id==='plasma_rifle'){ grantPlasmaRifle(); }
  else if(it.kind==='weapon_melee'||it.kind==='weapon_ranged'||it.kind==='weapon_throwable'){ giveWeaponItem(S, it.id); }
  else addToInventory(S, it.id, it.kind, it.qty);
 });
 lootPending.items = [];
 checkAchievements();
 renderInventoryModal(); renderWeaponSlots(); updateHudDynamic();
 toast('Took everything.', 'amber');
 renderLootPanel();
}
function showLootCtxMenu(e, idx){
 closeLootCtxMenu();
 if(!lootPending) return;
 const it = lootPending.items[idx]; if(!it) return;
 const host = document.getElementById('modal-loot');
 const rect = host.getBoundingClientRect();
 const menu = document.createElement('div'); menu.id='loot-ctx-menu'; menu.className='loot-ctx-menu';
 menu.style.left = Math.max(4, e.clientX - rect.left) + 'px';
 menu.style.top = Math.max(4, e.clientY - rect.top) + 'px';
 const btn = document.createElement('button');
 btn.textContent = it.kind==='armor' ? 'Equip Set' : 'Equip Backpack';
 btn.onclick = ()=>{
  addToInventory(S, it.id, it.kind, 1);
  if(it.kind==='armor') equipArmor(S, it.id); else equipBackpack(S, it.id);
  it.qty -= 1;
  if(it.qty<=0) lootPending.items.splice(idx,1);
  closeLootCtxMenu();
  renderInventoryModal(); renderLootPanel();
 };
 menu.appendChild(btn);
 host.appendChild(menu);
 setTimeout(()=> document.addEventListener('click', closeLootCtxMenu, {once:true}), 0);
}
function closeLootCtxMenu(){ const m=document.getElementById('loot-ctx-menu'); if(m) m.remove(); }
/* Right-click drop menu for the inventory grid — drop everything in one
   click, or drop a specific amount (freeing up exactly that much weight). */
function showInvCtxMenu(e, it){
 closeInvCtxMenu();
 const host = document.getElementById('modal-inventory');
 const hostRect = host.getBoundingClientRect();
 const menu = document.createElement('div'); menu.id='inv-ctx-menu'; menu.className='loot-ctx-menu';
 menu.style.left = Math.max(4, e.clientX - hostRect.left) + 'px';
 menu.style.top = Math.max(4, e.clientY - hostRect.top) + 'px';
 const maxQty = Math.round(it.qty*10)/10;
 const dropAllBtn = document.createElement('button');
 dropAllBtn.textContent = 'Drop All ('+maxQty+')';
 dropAllBtn.onclick = ()=>{
  removeFromInventory(S, it.id, it.qty);
  toast('Dropped '+itemDisplayName(it.id)+'.', 'amber');
  closeInvCtxMenu();
  renderInventoryModal();
 };
 const dropSomeBtn = document.createElement('button');
 dropSomeBtn.textContent = 'Drop…';
 dropSomeBtn.onclick = ()=>{
  closeInvCtxMenu();
  const raw = prompt('Drop how many '+itemDisplayName(it.id)+'? (1-'+maxQty+')', String(maxQty));
  if(raw===null) return;
  let amt = parseFloat(raw);
  if(isNaN(amt) || amt<=0){ toast('Nothing dropped.', 'bad'); return; }
  amt = Math.min(amt, maxQty);
  removeFromInventory(S, it.id, amt);
  toast('Dropped '+(Math.round(amt*10)/10)+'x '+itemDisplayName(it.id)+'.', 'amber');
  renderInventoryModal();
 };
 menu.appendChild(dropAllBtn); menu.appendChild(dropSomeBtn);
 host.appendChild(menu);
 setTimeout(()=> document.addEventListener('click', closeInvCtxMenu, {once:true}), 0);
}
function closeInvCtxMenu(){ const m=document.getElementById('inv-ctx-menu'); if(m) m.remove(); }
function progressLootAtQuests(locId){
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id];
  const st = S.questsSide[id];
  if(def.type==='loot_at' && def.locHint===locId && st.status==='active'){
   st.progress++;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); }
   renderQuestsModal();
  }
 }
}
function progressJournalQuest(){
 const count = Object.keys(S.journalPages).length;
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id]; const st = S.questsSide[id];
  if(def.type==='journal_count' && st.status==='active'){
   st.progress = count;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); }
  }
 }
 renderQuestsModal();
}
function progressSideKillQuests(kind){
 let changed=false;
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id]; const st = S.questsSide[id];
  if(st.status!=='active') continue;
  if((def.type==='kill_bandits' && kind==='bandit') || (def.type==='kill_total' && (kind==='bandit'||kind==='zombie'))){
   st.progress++; changed=true;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); checkAchievements(); }
  }
 }
 if(changed) renderQuestsModal();
}
function itemDisplayName(id){
 if(id==='gold_bars') return 'Gold Bars';
 const card = findKeycardById(id); if(card) return card.name;
 const c = findConsumableById(id); if(c) return c.name;
 if(AMMO_TYPES[id.replace('ammo_','')]) return AMMO_TYPES[id.replace('ammo_','')].name;
 const a = ARMOR[id]; if(a) return a.name;
 const b = BACKPACKS[id]; if(b) return b.name;
 const w = findWeaponById(id); if(w) return w.name;
 return id;
}

/* ================= COMBAT: MELEE ================= */
let lastAttackAt = 0;
function playerMelee(){
 const wid = S.weaponSlots.melee || 'fists';
 const w = WEAPONS_MELEE[wid];
 const now = performance.now();
 const cd = w.cooldown * (S.skills.berserker?0.85:1);
 if(now - lastAttackAt < cd) return;
 lastAttackAt = now;
 const staminaCost = w.stamina || 0;
 let fatigued = false;
 if(staminaCost>0){
  if(S.stamina < staminaCost*0.4) fatigued = true;
  S.stamina = Math.max(0, S.stamina - staminaCost);
 }
 const ang = Math.atan2(S.facing.y, S.facing.x);
 W.meleeFx.push({x:W.player.x,y:W.player.y, angle:ang, arcDeg:w.swing.arcDeg, reach:w.swing.reach, life:180, maxLife:180});
 const targets = [...W.zombies, ...W.bandits];
 let hitAny=false;
 targets.forEach(t=>{
  const d = dist(W.player.x,W.player.y,t.x,t.y);
  if(d>w.swing.reach+ (t.r||16)) return;
  const a2 = angleTo(W.player.x,W.player.y,t.x,t.y);
  if(Math.abs(angleDiff(ang,a2)) > (w.swing.arcDeg*Math.PI/180)/2) return;
  if(!w.cleave && hitAny) return;
  let dmg = w.dmg * meleeDamageMult() * (fatigued?0.6:1) + harrowedDamageBonus();
  if(S.skills.executioner && t.hp/t.maxHp < 0.25) dmg *= 1.25;
  damageEntity(t, dmg, true);
  hitAny=true;
 });
 if(W.boss){
  const bd = dist(W.player.x,W.player.y,W.boss.x,W.boss.y);
  if(bd < w.swing.reach + W.boss.r){
   const ba = angleTo(W.player.x,W.player.y,W.boss.x,W.boss.y);
   if(Math.abs(angleDiff(ang,ba)) <= (w.swing.arcDeg*Math.PI/180)/2){
    toast('Melee does nothing against the Harrowed. Use guns or rockets.', 'bad');
   }
  }
 }
}

/* ================= COMBAT: RANGED ================= */
function harrowedDamageBonus(){ return (S.trophyClaimed && S.trophyClaimed.harrowed) ? 100 : 0; }
function playerRanged(){
 const slot = S.activeSlot;
 const wid = S.weaponSlots[slot];
 if(!wid){ toast('Nothing equipped there.', 'bad'); return; }
 const w = WEAPONS_RANGED[wid];
 const now = performance.now();
 if(S.reloadingSlot===slot) return;
 if(!w._lastFire) w._lastFire=0;
 if(now - w._lastFire < w.cooldown) return;
 const needsAmmo = !!w.ammo;
 if(needsAmmo && (S.magAmmo[slot]||0) <= 0){ toast('Out of ammo — press R to reload.', 'bad'); return; }
 w._lastFire = now;
 if(needsAmmo && !(S.skills.ammo_efficiency && Math.random()<0.12)) S.magAmmo[slot]--;
 const apLoaded = needsAmmo && S.magAmmoIsAP && S.magAmmoIsAP[slot];
 let spread = w.spread * (S.skills.steady_aim?0.75:1) * (S.companions.includes('john')?0.92:1) * (1 - Math.min(0.75, trophyBonusSum('accuracy')*0.15));
 const ang = Math.atan2(S.facing.y,S.facing.x) + rand(-spread,spread)*Math.PI/180;
 const dmg = w.dmg*rangedDamageMult(wid)*(apLoaded?AP_DAMAGE_MULT:1) + harrowedDamageBonus();
 W.projectiles.push({
  x:W.player.x, y:W.player.y, vx:Math.cos(ang)*w.pspeed, vy:Math.sin(ang)*w.pspeed,
  dmg, life:w.range/w.pspeed*1000, owner:'player', splash:w.splash||0
 });
 renderAmmoHud();
}
function reloadActive(){
 const slot = S.activeSlot;
 const wid = S.weaponSlots[slot];
 if(!wid || !WEAPONS_RANGED[wid]) return;
 const w = WEAPONS_RANGED[wid];
 if(!w.ammo){ toast('No reload needed.', 'amber'); return; }
 if(S.magAmmo[slot]>=w.mag){ return; }
 S.ammoVariant = S.ammoVariant || {};
 // Reload always pulls whatever variant is currently *selected* for this
 // slot — defaulting to standard rounds. Drag AP rounds onto the equipped
 // weapon to switch the selection; it stays switched until you drag the
 // other variant back on, it's never automatic.
 const wantAP = S.ammoVariant[slot]==='ap' && !!AP_AMMO_FOR[w.ammo];
 const ammoKey = wantAP ? AP_AMMO_FOR[w.ammo] : w.ammo;
 const ammoId = 'ammo_'+ammoKey;
 const avail = findInv(S, ammoId);
 if(!avail || avail.qty<=0){
  toast('No '+AMMO_TYPES[ammoKey].name+' in reserve.'+(wantAP?' Drag standard rounds onto the weapon to switch back.':''), 'bad');
  return;
 }
 S.reloadingSlot = slot;
 const reloadMs = w.reload * (S.skills.quick_hands?0.8:1);
 S.reloadEndsAt = performance.now()+reloadMs;
 toast('Reloading '+AMMO_TYPES[ammoKey].name+'...', 'amber');
 setTimeout(()=>{
  if(S.reloadingSlot!==slot) return;
  const need = w.mag - S.magAmmo[slot];
  const availNow = findInv(S, ammoId);
  const take = Math.min(need, availNow?availNow.qty:0);
  S.magAmmo[slot] += take;
  if(take>0) removeFromInventory(S, ammoId, take);
  S.magAmmoIsAP = S.magAmmoIsAP || {};
  S.magAmmoIsAP[slot] = wantAP;
  S.reloadingSlot = null;
  renderAmmoHud(); renderInventoryModal();
 }, reloadMs);
}
function throwActive(){
 const wid = S.weaponSlots.throwable;
 if(!wid) { toast('No throwable equipped.', 'bad'); return; }
 const inv = findInv(S, wid);
 if(!inv || inv.qty<=0){ toast('Out of '+WEAPONS_THROWABLE[wid].name+'.', 'bad'); return; }
 removeFromInventory(S, wid, 1);
 const w = WEAPONS_THROWABLE[wid];
 const ang = Math.atan2(S.facing.y,S.facing.x);
 W.projectiles.push({x:W.player.x,y:W.player.y, vx:Math.cos(ang)*380, vy:Math.sin(ang)*380, dmg:w.dmg+harrowedDamageBonus(), life:w.fuse||900, owner:'player', splash:w.splash*(S.skills.demolitionist?1.25:1), throwableFx:true});
 renderWeaponSlots();
}

/* ================= UPDATE LOOP ================= */
function update(dt){
 // day/night clock
 S.gameMinutes += dt*(1440/DAY_LENGTH_MS);
 if(S.gameMinutes>=1440){ S.gameMinutes-=1440; S.dayCount++; }

 const sprinting = KEYS['shift'] && S.stamina>0.5;
 const bp = S.equipped.backpack ? BACKPACKS[S.equipped.backpack] : null;
 const backpackSpeedBonus = (bp && bp.speedBonus) || 0;
 const harrowedSpeedBonus = (S.trophyClaimed && S.trophyClaimed.harrowed) ? 3 : 0;
 const spd = (2.6+backpackSpeedBonus+harrowedSpeedBonus) * (sprinting?1.6*(S.skills.sprinter?1.1:1):1) * (1 + trophyBonusSum('speed')*0.10);
 let dx=0,dy=0;
 if(KEYS['w']) dy-=1; if(KEYS['s']) dy+=1; if(KEYS['a']) dx-=1; if(KEYS['d']) dx+=1;
 if(dx||dy){
  const len=Math.hypot(dx,dy); dx/=len; dy/=len;
  S.facing = {x:dx,y:dy};
  let nx = W.player.x+dx*spd*(dt/16), ny = W.player.y+dy*spd*(dt/16);
  W.player.x = clamp(nx,20,W.w-20); W.player.y = clamp(ny,20,W.h-20);
  if(sprinting){ S.stamina = Math.max(0,S.stamina - dt*0.02*(S.skills.light_feet?0.85:1)); }
 }
 resolvePlayerCollisions();
 if(!sprinting || !(dx||dy)){
  S.stamina = Math.min(S.maxStamina, S.stamina + dt*0.012*applyBuffMult('staminaRegen',1)*(S.skills.fleet_footed?1.2:1));
 }

 // hunger/thirst
 const decayMult = S.skills.iron_gut?0.75:1;
 S.hunger = Math.max(0, S.hunger - dt*0.00045*decayMult);
 S.thirst = Math.max(0, S.thirst - dt*0.0006*decayMult);
 if(S.hunger<=0 || S.thirst<=0) S.hp -= dt*0.0015;

 // status ticking
 if(S.status.bleeding>0){ S.status.bleeding -= dt; S.hp -= dt*0.0016; }
 if(S.status.sick>0){ S.status.sick -= dt; }
 if(S.status.infected>0){
  S.status._timer = (S.status._timer||0) + dt;
  const growRate = S.skills.iron_lungs?9000:6300;
  if(S.status._timer>growRate){ S.status._timer=0; S.status.infectedSeverity = Math.min(4,S.status.infectedSeverity+1); }
  S.hp -= dt*0.0006*S.status.infectedSeverity;
 }
 // buffs expiry
 const nowT = performance.now();
 S.buffs = S.buffs.filter(b=> b.expiresAt>nowT );

 if(S.hp<=0){ onPlayerDeath(); return; }

 // camp defense: 3-wave siege, then permanently secured
 if(S.currentLocation==='camp' && !W.isInterior){
  if(S.campSiege && S.campSiege.active){
   if(W.zombies.length===0){
    if(S.campSiege.wave<3){
     S.campSiege.wave++;
     spawnCampWave(S.campSiege.wave);
     toast('Wave '+S.campSiege.wave+' of 3 incoming!', 'bad');
    } else {
     S.campSiege.active = false;
     S.flags.camp_cleared = true;
     // Force "Camp Fire" to complete in perfect lockstep with camp_cleared —
     // never let the two drift out of sync (see progressQuestKill).
     if(S.questsMain.m2 && S.questsMain.m2.status==='active'){
      S.questsMain.m2.progress = MAIN_QUESTS.m2.target;
      S.questsMain.m2.status = 'done';
      activateNextQuests();
      toast('Objective complete: Camp Fire', 'amber');
     }
     toast('The camp is secure. They won\'t breach it again.', 'amber');
     enterLocation('camp');
    }
   }
  } else if(!S.flags.camp_cleared){
   W.campSpawnCd -= dt;
   if(W.campSpawnCd<=0 && W.zombies.length<5){
    W.campSpawnCd = 9000;
    const loc = findLocation('camp');
    const z = spawnZombie(loc); z.x = pick([20,W.w-20]); z.y = rand(20,W.h-20);
    W.zombies.push(z);
   }
  }
  updateBarbwire(dt);
  updateGuards(dt);
  updateCampAmbience(dt);
 }
 updateWanderingNpcs(dt);
 updateTurrets(dt);

 updateEnemies(dt);
 updateCompanionsEnt(dt);
 updateProjectiles(dt);
 W.meleeFx.forEach(f=> f.life-=dt); W.meleeFx = W.meleeFx.filter(f=>f.life>0);
 W.explosionFx.forEach(f=> f.life-=dt); W.explosionFx = W.explosionFx.filter(f=>f.life>0);
 if(W.critFx){ W.critFx.forEach(f=>{ f.life-=dt; f.y-=dt*0.04; }); W.critFx = W.critFx.filter(f=>f.life>0); }

 if(S.reloadingSlot) { /* handled via setTimeout */ }
 updateHudDynamic();
}
/* Push-out collision: the player is treated as a circle and shoved to the nearest
   clear point outside every overlapping prop, every single frame. Unlike a simple
   "block the move" check, this can never leave the survivor permanently frozen —
   even if they somehow end up overlapping geometry (e.g. spawn point, a pushed
   sequence of props), the very next frame resolves them back out. */
const PLAYER_RADIUS = 16;
function resolvePlayerCollisions(){
 for(const p of W.props){
  const cx = clamp(W.player.x, p.x, p.x+p.w);
  const cy = clamp(W.player.y, p.y, p.y+p.h);
  const dx = W.player.x-cx, dy = W.player.y-cy;
  const distSq = dx*dx+dy*dy;
  if(distSq < PLAYER_RADIUS*PLAYER_RADIUS){
   const d = Math.sqrt(distSq);
   if(d < 0.0001){
    // player center is exactly inside/on the rect boundary line — push out along
    // whichever axis has the smaller overlap so there's no divide-by-zero jitter.
    const overlapLeft = W.player.x-p.x, overlapRight = (p.x+p.w)-W.player.x;
    const overlapTop = W.player.y-p.y, overlapBottom = (p.y+p.h)-W.player.y;
    const min = Math.min(overlapLeft,overlapRight,overlapTop,overlapBottom);
    if(min===overlapLeft) W.player.x = p.x - PLAYER_RADIUS;
    else if(min===overlapRight) W.player.x = p.x+p.w + PLAYER_RADIUS;
    else if(min===overlapTop) W.player.y = p.y - PLAYER_RADIUS;
    else W.player.y = p.y+p.h + PLAYER_RADIUS;
   } else {
    const push = (PLAYER_RADIUS-d) + 0.5;
    W.player.x += (dx/d)*push;
    W.player.y += (dy/d)*push;
   }
  }
 }
 W.player.x = clamp(W.player.x, 20, W.w-20);
 W.player.y = clamp(W.player.y, 20, W.h-20);
}
function updateEnemies(dt){
 const aggroRangeBase = 220 * (S.skills.silent_steps?0.75:1);
 W.zombies.forEach(z=>{
  const variant = ZOMBIE_VARIANTS[z.variant] || ZOMBIE_VARIANTS.walker;
  const d = dist(z.x,z.y,W.player.x,W.player.y);
  const aggroRange = variant.id==='dog' ? aggroRangeBase*1.3 : aggroRangeBase;
  if(d<aggroRange) z.aggro=true;
  if(!z.aggro) return;
  const a = angleTo(z.x,z.y,W.player.x,W.player.y);
  if(variant.scream && !z.screamed && d<170){
   z.screamed = true;
   W.zombies.forEach(z2=>{ if(z2!==z && dist(z2.x,z2.y,z.x,z.y)<260) z2.aggro=true; });
  }
  if(variant.charge){
   z.chargeCd -= dt; z.throwCd -= dt;
   if(z.throwCd<=0 && d<420 && d>100){
    z.throwCd = rand(2600,3800);
    W.projectiles.push({x:z.x,y:z.y, vx:Math.cos(a)*300, vy:Math.sin(a)*300, dmg:z.dmg*0.5, life:1600, owner:'enemy', isRock:true});
   }
   if(z.charging>0){
    z.charging -= dt;
    if(z.charging<=0){ z.x += Math.cos(a)*46; z.y += Math.sin(a)*46; }
   } else if(z.chargeCd<=0 && d<320 && d>70){
    z.chargeCd = rand(4500,6500);
    z.charging = 480;
   } else if(d>72){ z.x += Math.cos(a)*z.speed*(dt/16); z.y += Math.sin(a)*z.speed*(dt/16); }
   else { z.atkCd-=dt; if(z.atkCd<=0){ z.atkCd=1100; damagePlayer(z.dmg,'zombie'); } }
   return;
  }
  if(variant.ranged){
   if(d>260){ z.x += Math.cos(a)*z.speed*(dt/16); z.y += Math.sin(a)*z.speed*(dt/16); }
   else if(d<130){ z.x -= Math.cos(a)*z.speed*0.5*(dt/16); z.y -= Math.sin(a)*z.speed*0.5*(dt/16); }
   z.fireCd -= dt;
   if(z.fireCd<=0 && d<320){
    z.fireCd = 1300;
    W.projectiles.push({x:z.x,y:z.y, vx:Math.cos(a)*460, vy:Math.sin(a)*460, dmg:z.dmg, life:900, owner:'enemy', fromZombie:true});
   }
   return;
  }
  if(d>26){ z.x += Math.cos(a)*z.speed*(dt/16); z.y += Math.sin(a)*z.speed*(dt/16); }
  else { z.atkCd-=dt; if(z.atkCd<=0){ z.atkCd=900; damagePlayer(z.dmg,'zombie'); } }
 });
 // Zombies/bandits/the boss chase the player with pure vector math above, which
 // would happily walk them straight through building walls (inside or out) —
 // nudge each one clear of every prop after it moves, same collision rule the
 // player already follows.
 W.zombies.forEach(z=> nudgeOutOfProps(z, W.props, z.r||16));
 W.bandits.forEach(b=>{
  const variant = BANDIT_VARIANTS[b.variant] || BANDIT_VARIANTS.grunt;
  const d = dist(b.x,b.y,W.player.x,W.player.y);
  if(d<300) b.aggro=true;
  if(!b.aggro) return;
  const a = angleTo(b.x,b.y,W.player.x,W.player.y);
  if(variant.throws){
   if(d>260){ b.x += Math.cos(a)*b.speed*(dt/16); b.y += Math.sin(a)*b.speed*(dt/16); }
   b.fireCd -= dt;
   if(b.fireCd<=0 && d<380){
    b.fireCd = 2600;
    W.projectiles.push({x:b.x,y:b.y, vx:Math.cos(a)*260, vy:Math.sin(a)*260, dmg:b.dmg*0.8, life:1400, owner:'enemy', throwableFx:true, splash:70});
   }
  } else if(variant.ranged){
   if(d>220){ b.x += Math.cos(a)*b.speed*(dt/16); b.y += Math.sin(a)*b.speed*(dt/16); }
   else if(d<140){ b.x -= Math.cos(a)*b.speed*0.6*(dt/16); b.y -= Math.sin(a)*b.speed*0.6*(dt/16); }
   b.fireCd -= dt;
   if(b.fireCd<=0 && d<320){
    b.fireCd = 1100;
    W.projectiles.push({x:b.x,y:b.y, vx:Math.cos(a)*520, vy:Math.sin(a)*520, dmg:b.dmg, life:900, owner:'enemy'});
   }
  } else {
   if(d>28){ b.x += Math.cos(a)*b.speed*(dt/16); b.y += Math.sin(a)*b.speed*(dt/16); }
   else { b.atkCd-=dt; if(b.atkCd<=0){ b.atkCd=800; damagePlayer(b.dmg,'melee'); } }
  }
 });
 W.bandits.forEach(b=> nudgeOutOfProps(b, W.props, b.r||15));
 if(W.boss){
  const b=W.boss; const d=dist(b.x,b.y,W.player.x,W.player.y); const a=angleTo(b.x,b.y,W.player.x,W.player.y);
  if(d>50){ b.x+=Math.cos(a)*b.speed*(dt/16); b.y+=Math.sin(a)*b.speed*(dt/16); }
  else { b.atkCd-=dt; if(b.atkCd<=0){ b.atkCd=1000; damagePlayer(b.dmg,'melee'); } }
  nudgeOutOfProps(b, W.props, b.r||34);
  document.getElementById('bossfill').style.width = Math.max(0,(b.hp/b.maxHp*100))+'%';
 }
}
function updateCompanionsEnt(dt){
 if(!W.companionsEnt) return;
 W.companionsEnt.forEach(c=>{
  if(c.isCampStatic) return; // stands at camp for chat/recruit only, no AI
  const d = dist(c.x,c.y,W.player.x,W.player.y);
  if(d>90){ const a=angleTo(c.x,c.y,W.player.x,W.player.y); c.x+=Math.cos(a)*1.6*(dt/16); c.y+=Math.sin(a)*1.6*(dt/16); }
  nudgeOutOfProps(c, W.props, c.r||16);
  const targets=[...W.zombies,...W.bandits, ...(W.boss?[W.boss]:[])];
  if(!targets.length) return;
  let nearest=null,nd=9999;
  targets.forEach(t=>{ const dd=dist(c.x,c.y,t.x,t.y); if(dd<nd){nd=dd;nearest=t;} });
  const w = WEAPONS_RANGED[c.weapon];
  if(nearest && w && nd<w.range){
   c.atkCd -= dt;
   const cd = w.cooldown*3*(S.companions.includes('nikolai')?0.9:1);
   if(c.atkCd<=0){
    c.atkCd=cd;
    const a = angleTo(c.x,c.y,nearest.x,nearest.y);
    W.projectiles.push({
     x:c.x, y:c.y, vx:Math.cos(a)*w.pspeed, vy:Math.sin(a)*w.pspeed,
     dmg:w.dmg*0.5, life:w.range/w.pspeed*1000, owner:'companion', color:c.color
    });
   }
  }
 });
}
function pointInsideProps(x,y,props){
 for(const p of props){ if(x>p.x && x<p.x+p.w && y>p.y && y<p.y+p.h) return true; }
 return false;
}
function updateProjectiles(dt){
 const remain=[];
 W.projectiles.forEach(p=>{
  if(p.ox===undefined){ p.ox=p.x; p.oy=p.y; }
  p.x += p.vx*(dt/1000); p.y += p.vy*(dt/1000); p.life -= dt;
  let hit=false;
  // A wall stops a bullet/thrown object exactly like it stops a person —
  // bandit/zombie/player fire can no longer punch straight through a
  // building to hit something on the other side of it. But some shooters
  // (Bo/Nikita in the watchtowers) stand *inside* solid geometry by design,
  // so a shot is only checked against walls once it's traveled far enough to
  // plausibly have left its own shooter's structure — otherwise every guard
  // shot would be destroyed the instant it spawned.
  const clearedSpawn = dist(p.x,p.y,p.ox,p.oy) > 150;
  if(clearedSpawn && pointInsideProps(p.x,p.y,W.props)){
   hit = true;
   if(p.throwableFx) explode(p.x,p.y,p.splash,p.dmg);
  }
  if(!hit && (p.owner==='player' || p.owner==='companion')){
   const targets=[...W.zombies,...W.bandits, ...(W.boss?[W.boss]:[])];
   for(const t of targets){ if(dist(p.x,p.y,t.x,t.y) < (t.r||16)){ 
     if(p.splash>0){ explode(p.x,p.y,p.splash,p.dmg); } else damageEntity(t,p.dmg,true);
     hit=true; break; } }
  } else if(!hit && p.owner==='turret'){
   if(p.targetBoss){
    if(W.boss && dist(p.x,p.y,W.boss.x,W.boss.y) < W.boss.r){ damageEntity(W.boss, p.dmg, false); hit=true; }
   } else if(dist(p.x,p.y,W.player.x,W.player.y) < 18){ damagePlayer(p.dmg,'turret'); hit=true; }
  } else if(!hit){
   if(dist(p.x,p.y,W.player.x,W.player.y) < 18){ damagePlayer(p.dmg, p.isRock ? 'rock' : (p.fromZombie ? 'zombie_ranged' : 'ranged')); hit=true; }
  }
  if(!hit && p.life>0 && p.x>0 && p.x<W.w && p.y>0 && p.y<W.h) remain.push(p);
  else if(!hit && p.throwableFx && p.life<=0){ explode(p.x,p.y,p.splash,p.dmg); }
 });
 W.projectiles = remain;
}
function explode(x,y,radius,dmg){
 W.explosionFx.push({x,y,radius,life:260,maxLife:260});
 [...W.zombies,...W.bandits, ...(W.boss?[W.boss]:[])].forEach(t=>{
  if(dist(x,y,t.x,t.y)<=radius) damageEntity(t,dmg,true);
 });
 if(dist(x,y,W.player.x,W.player.y)<=radius*0.6) damagePlayer(dmg*0.4,'blast');
}

/* ================= INTERACT ================= */
/* ---------- BUILDING INTERIORS ---------- */
const ENTERABLE_LABELS = new Set(['House','Church','Main Building','Terminal','Camp Hall','Ward','Nurse Station','Kitchen','Tent']);
const INTERIOR_FURNITURE = [
 {x:60, y:60,  w:150, h:70,  label:'Table', fill:'#1a1610'},
 {x:350,y:40,  w:170, h:120, label:'Shelving', fill:'#171810'},
 {x:60, y:290, w:130, h:70,  label:'Table', fill:'#1a1610'},
 {x:360,y:280, w:150, h:60,  label:'Bench', fill:'#3a2a1a'}
];
function doorPointOf(p){ return {x:p.x+p.w/2, y:p.y+p.h}; }
let W_exteriorBackup = null;
function tryBoardTruck(){
 if(!S.flags.harrowed_reported){
  toast("Not yet — we need to deal with the Harrowed and let Elias know first.", 'bad');
  return;
 }
 beginOutro();
}
/* ---------- BANK VAULT (special room, gated on the bank keycard) ---------- */
function tryEnterVault(p){
 if(W.isInterior) return;
 if(!S.flags.vault_unlocked){
  if(!findInv(S,'bank_keycard')){
   lockedDoorFeedback('bank_keycard', "The vault door is sealed tight.");
   return;
  }
  removeFromInventory(S,'bank_keycard',1);
  S.flags['keycard_used_bank_keycard'] = true;
  S.flags.vault_cracked = true;
  S.flags.vault_unlocked = true;
  toast('The vault door grinds open.', 'amber');
  completeQuestByFlag('vault_cracked');
  activateNextQuests();
 }
 enterVaultRoom(p);
}
function enterVaultRoom(p){
 if((W && W.isInterior) || !W) return;
 W_exteriorBackup = W;
 S.inInterior = true;
 S.interiorLabel = 'Vault';
 const dp = doorPointOf(p);
 S.interiorReturn = {x:dp.x, y:dp.y+34};
 const w=560, h=420;
 if(!p.vaultCache){
  // Generated once per bank visit, same rule as regular building interiors —
  // looted deposit boxes stay looted until you leave and come back to the
  // bank from the world map.
  const roomProps = [
   {x:40, y:50,  w:130, h:280, label:'Deposit Boxes', fill:'#171810'},
   {x:390,y:50,  w:130, h:120, label:'Cabinet', fill:'#1a1610'},
   {x:390,y:220, w:130, h:110, label:'Cabinet', fill:'#1a1610'}
  ];
  const doorMarker = {x:w/2-30, y:h-22, w:60, h:22, label:'Door', fill:'#100d08'};
  roomProps.push(doorMarker);
  const crates = [];
  const cCount = randInt(3,5);
  for(let i=0;i<cCount;i++){
   const pt = randomOpenPoint(roomProps, w, h, 30);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'vault_loot'});
  }
  p.vaultCache = {props:roomProps, crates, doorMarker};
 }
 const cache = p.vaultCache;
 W = {
  locId: S.currentLocation, w, h,
  player:{x:w/2, y:h-80},
  zombies:[], bandits:[], npcs:[], crates:cache.crates, props:cache.props, roads:[],
  projectiles:[], meleeFx:[], explosionFx:[], critFx:[], companionsEnt:[],
  campSpawnCd: 999999, isInterior:true, doorMarker:cache.doorMarker
 };
 updateHudLocation();
 toast('Stacks of deposit boxes line the walls. Let\'s see what\'s inside.', 'amber');
}

/* ---------- NORTH RIDGE L2 VAULT (unique end-game reward room) ---------- */
function tryEnterRidgeVault(p){
 if(W.isInterior) return;
 if(!S.flags.ridge_l2_unlocked){
  if(!findInv(S,'ridge_keycard_l2')){
   lockedDoorFeedback('ridge_keycard_l2', "A second door, sealed behind reinforced glass.");
   return;
  }
  removeFromInventory(S,'ridge_keycard_l2',1);
  S.flags['keycard_used_ridge_keycard_l2'] = true;
  S.flags.ridge_l2_unlocked = true;
  toast('The Level 2 seal releases with a hiss.', 'amber');
 }
 enterRidgeVaultRoom(p);
}
function enterRidgeVaultRoom(p){
 if((W && W.isInterior) || !W) return;
 W_exteriorBackup = W;
 S.inInterior = true;
 S.interiorLabel = 'Restricted Storage';
 const dp = doorPointOf(p);
 S.interiorReturn = {x:dp.x, y:dp.y+34};
 const w=560, h=420;
 if(!p.ridgeVaultCache){
  const roomProps = [
   {x:40, y:50,  w:150, h:130, label:'Cabinet', fill:'#1a1d16'},
   {x:40, y:220, w:150, h:150, label:'Shelving', fill:'#171810'},
   {x:380,y:50,  w:140, h:300, label:'Deposit Boxes', fill:'#1a1d16'}
  ];
  const doorMarker = {x:w/2-30, y:h-22, w:60, h:22, label:'Door', fill:'#100d08'};
  roomProps.push(doorMarker);
  // This room only ever exists once per playthrough, so the loot is fixed
  // and split across a few crates rather than randomized like normal loot.
  const lootSets = [
   [{id:'ammo_mm9_ap',kind:'ammo',qty:30},{id:'ammo_rifle_ap',kind:'ammo',qty:30}],
   [{id:'mre',kind:'food',qty:25}],
   [{id:'exo',kind:'backpack',qty:1}],
   [{id:'plasma_rifle',kind:'weapon_ranged',qty:1}]
  ];
  const crates = [];
  lootSets.forEach((items)=>{
   const pt = randomOpenPoint(roomProps.concat(crates.map(c=>({x:c.x-20,y:c.y-20,w:40,h:40}))), w, h, 30);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'fixed_loot', items, tokens:0});
  });
  const tpt = randomOpenPoint(roomProps.concat(crates.map(c=>({x:c.x-20,y:c.y-20,w:40,h:40}))), w, h, 30);
  crates.push({x:tpt.x, y:tpt.y, looted:false, kind:'fixed_loot', items:[], tokens:1000});
  p.ridgeVaultCache = {props:roomProps, crates, doorMarker};
 }
 const cache = p.ridgeVaultCache;
 W = {
  locId: S.currentLocation, w, h,
  player:{x:w/2, y:h-80},
  zombies:[], bandits:[], npcs:[], crates:cache.crates, props:cache.props, roads:[],
  projectiles:[], meleeFx:[], explosionFx:[], critFx:[], companionsEnt:[],
  campSpawnCd: 999999, isInterior:true, doorMarker:cache.doorMarker
 };
 updateHudLocation();
 toast('Sealed storage crates, still cold from climate control. Whatever\'s in here was never meant to leave.', 'amber');
}
function enterBuilding(p){
 if((W && W.isInterior) || !W) return;
 W_exteriorBackup = W;
 S.inInterior = true;
 S.interiorLabel = p.label + (p.label==='House'?' (Interior)':'');
 const dp = doorPointOf(p);
 S.interiorReturn = {x:dp.x, y:dp.y+34};
 const w=560, h=420;
 if(!p.interiorCache){
  // Generate this room once per building, per outdoor visit. The cache lives
  // on the exterior prop object itself, so re-entering the same building
  // later in this same visit shows exactly what was left behind — looted
  // crates stay looted. A fresh room (and a fresh chance at loot) only
  // happens once this location is left and entered again from the map,
  // since that rebuilds the whole props array from scratch.
  const roomProps = INTERIOR_FURNITURE.map(f=>({...f}));
  const doorMarker = {x:w/2-30, y:h-22, w:60, h:22, label:'Door', fill:'#100d08'};
  roomProps.push(doorMarker);
  const crates = [];
  // The camp is home base — Elias's hall and the survivors' tents are lived-in
  // shelter, not loot sites, so they never generate crates regardless of the
  // usual random chance.
  const campBuilding = S.currentLocation==='camp';
  const guaranteedLoot = S.currentLocation==='military_base';
  if(!campBuilding && (guaranteedLoot || Math.random()<0.65)){
   const cCount = guaranteedLoot ? randInt(3,5) : randInt(1,3);
   for(let i=0;i<cCount;i++){
    const pt = randomOpenPoint(roomProps, w, h, 30);
    crates.push({x:pt.x, y:pt.y, looted:false, kind:'normal'});
   }
  }
  p.interiorCache = {props:roomProps, crates, doorMarker};
 }
 const cache = p.interiorCache;
 const interiorNpcs = [];
 if(p.label==='Camp Hall' && S.currentLocation==='camp' && S.flags.camp_cleared){
  interiorNpcs.push({id:'camp_leader', name:'Elias Marsh', x:w/2, y:h/2-20, glyph:'👤', color:'#e8b23d', dialogue:'camp_leader'});
 }
 W = {
  locId: S.currentLocation, w, h,
  player:{x:w/2, y:h-80},
  zombies:[], bandits:[], npcs:interiorNpcs, crates:cache.crates, props:cache.props, roads:[],
  projectiles:[], meleeFx:[], explosionFx:[], critFx:[], companionsEnt:[],
  campSpawnCd: 999999, isInterior:true, doorMarker:cache.doorMarker
 };
 updateHudLocation();
 toast(cache.crates.length ? 'You step inside.' : (S.currentLocation==='camp' ? 'You step inside. Just living quarters — nothing to scavenge here.' : 'You step inside. Looks empty.'), 'amber');
}
function exitBuilding(){
 if(!W || !W.isInterior || !W_exteriorBackup) return;
 W = W_exteriorBackup;
 W_exteriorBackup = null;
 S.inInterior = false;
 if(S.interiorReturn){ W.player.x = S.interiorReturn.x; W.player.y = S.interiorReturn.y; }
 S.interiorReturn = null;
 updateHudLocation();
 toast('You step back outside.', 'amber');
}
function interact(){
 if(!W) return;
 for(const c of W.crates){
  if(!c.looted && dist(c.x,c.y,W.player.x,W.player.y)<46){ lootCrate(c); return; }
 }
 if(W.isInterior){
  if(W.doorMarker && dist(W.player.x, W.player.y, W.doorMarker.x+W.doorMarker.w/2, W.doorMarker.y+W.doorMarker.h/2) < 60){ exitBuilding(); return; }
 } else {
  for(const p of W.props){
   if(ENTERABLE_LABELS.has(p.label)){
    const dp = doorPointOf(p);
    if(dist(W.player.x, W.player.y, dp.x, dp.y) < 55){ enterBuilding(p); return; }
   }
  }
  for(const p of W.props){
   if(p.label==='Vault'){
    const dp = doorPointOf(p);
    if(dist(W.player.x, W.player.y, dp.x, dp.y) < 55){ tryEnterVault(p); return; }
   }
   if(p.label==='L2 Vault'){
    const dp = doorPointOf(p);
    if(dist(W.player.x, W.player.y, dp.x, dp.y) < 55){ tryEnterRidgeVault(p); return; }
   }
   if(p.label==='Big Truck'){
    const cx=p.x+p.w/2, cy=p.y+p.h/2;
    if(dist(W.player.x, W.player.y, cx, cy) < 90){ tryBoardTruck(); return; }
   }
  }
  for(const p of W.props){
   if(p.vehicleLoot && !p.vehicleLoot.looted){
    const cx=p.x+p.w/2, cy=p.y+p.h/2;
    if(dist(W.player.x, W.player.y, cx, cy) < 55){ lootVehicle(p); return; }
   }
  }
  for(const p of W.props){
   if(p.uselessInteract){
    const cx=p.x+p.w/2, cy=p.y+p.h/2;
    if(dist(W.player.x, W.player.y, cx, cy) < 50){ toast("The screen is dark. Whatever this used to do, it doesn't anymore.", 'bad'); return; }
   }
  }
 }
 for(const n of W.npcs){
  if(dist(n.x,n.y,W.player.x,W.player.y)<50){
   if(n.dialogue){ openDialogue(n.dialogue, n); return; }
   if(n.trade){ openDialogue('joe_intro', n); return; }
  }
 }
 if(W.companionsEnt) for(const c of W.companionsEnt){
  if(dist(c.x,c.y,W.player.x,W.player.y)<50){ openDialogue('companion_'+c.id, c); return; }
 }
}

/* ================= DIALOGUE ================= */
function openDialogue(id, npc){
 dlgState = {tree:id, node:'start', npc};
 document.getElementById('dialogue').style.display='block';
 renderDialogueNode();
}
function resolveText(t){ return typeof t==='function' ? t(S) : t; }
function renderDialogueNode(){
 const tree = DIALOGUES[dlgState.tree]; if(!tree) return;
 const node = tree[dlgState.node]; if(!node) return;
 document.getElementById('dlg-who').textContent = resolveText(node.who);
 document.getElementById('dlg-txt').textContent = resolveText(node.text);
 const wrap = document.getElementById('dlg-opts'); wrap.innerHTML='';
 (node.opts||[]).forEach((o,i)=>{
  if(o.showIf && !o.showIf(S)) return;
  const b = document.createElement('button');
  b.className='dlg-opt';
  b.innerHTML = (o.tag?`<span class="tag">${o.tag}</span>`:'') + resolveText(o.label);
  b.onclick = ()=>chooseOption(o);
  wrap.appendChild(b);
 });
}
function chooseOption(o){
 if(o.cha) S.charisma += o.cha;
 if(o.karma) S.karma += o.karma;
 if(o.trust && dlgState.tree.startsWith('companion_')){
  const cid = dlgState.tree.replace('companion_','');
  S.companionTrust[cid] = (S.companionTrust[cid]||0) + o.trust;
  if(Object.values(S.companionTrust).filter(v=>v>=3).length>=S.companions.length && S.companions.length>0){
   /* trust-based flavor only, no hard gate */
  }
 }
 if(o.action){ runDialogueAction(o.action, dlgState.npc); }
 if(o.ending){ resolveEnding(o.ending); document.getElementById('dialogue').style.display='none'; return; }
 if(o.next){ dlgState.node=o.next; renderDialogueNode(); }
 else { document.getElementById('dialogue').style.display='none'; dlgState=null; }
}
function grantRandomSurvivorReward(){
 const roll = Math.random();
 if(roll<0.4){
  const amt = randInt(20,55);
  S.tokens += amt;
  return amt+' Tokens';
 }
 if(roll<0.75){
  const pool = ['bandage','medkit','jerky','bread','popcola','nukacola','protein','mre'];
  const id = pool[Math.floor(Math.random()*pool.length)];
  const qty = randInt(1,3);
  addToInventory(S, id, consumableKind(id), qty);
  return qty+'x '+itemDisplayName(id);
 }
 const pool = ['knife','wrench','bat','ninemm'];
 const id = pool[Math.floor(Math.random()*pool.length)];
 giveWeaponItem(S, id);
 return itemDisplayName(id);
}
function trySurvivorTurnin(npcId){
 const n = SURVIVOR_NPCS.find(x=>x.id===npcId);
 if(!n) return;
 if(S.flags['survivor_done_'+npcId]){ toast('Already helped them out.', 'bad'); return; }
 const have = findInv(S, n.want.id);
 if(!have || have.qty < n.want.qty){ toast(n.lackText || ("You don't have "+n.want.label+" yet."), 'bad'); return; }
 removeFromInventory(S, n.want.id, n.want.qty);
 S.karma += 3;
 const rewardText = grantRandomSurvivorReward();
 S.flags['survivor_done_'+npcId] = true;
 toast(n.name+' thanks you. (+3 Karma, +'+rewardText+')', 'amber');
 progressCommunityAidQuest();
 checkAchievements();
 renderInventoryModal();
 updateHudDynamic();
}
function progressCommunityAidQuest(){
 const count = SURVIVOR_NPCS.filter(n=>S.flags['survivor_done_'+n.id]).length;
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id]; const st = S.questsSide[id];
  if(def.type==='community_aid' && st.status==='active'){
   st.progress = count;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); checkAchievements(); }
  }
 }
 renderQuestsModal();
}
function doctorHeal(){
 if(S.hp>=S.maxHp){ toast("You're already at full health.", 'bad'); return; }
 const missing = Math.round(S.maxHp - S.hp);
 const cost = Math.max(5, Math.round(missing*0.6));
 if(S.tokens<cost){ toast('Not enough tokens. Dr. Voss needs '+cost+'.', 'bad'); return; }
 S.tokens -= cost;
 S.hp = S.maxHp;
 toast('Dr. Voss patches you up fully. (−'+cost+' Tokens)', 'amber');
 updateHudDynamic();
}
function doctorFetchSupplies(){
 const meds = S.inventory.filter(i=>i.kind==='med' && i.id!=='serum');
 if(!meds.length){ toast("You don't have any medicine to give her.", 'bad'); return; }
 let takenAny=false;
 for(let i=0;i<2 && meds.length;i++){
  const idx = Math.floor(Math.random()*meds.length);
  const it = meds[idx];
  const take = Math.min(it.qty, randInt(1, Math.max(1, Math.floor(it.qty/2)||1)));
  removeFromInventory(S,it.id,take);
  takenAny=true;
  meds.splice(idx,1);
 }
 if(takenAny){
  S.karma += 4;
  toast('Dr. Voss thanks you for the medicine. (+4 Karma)', 'amber');
  renderInventoryModal();
 } else {
  toast("You don't have any medicine to give her.", 'bad');
 }
}
function giveSuppliesForPeace(){
 const eligible = S.inventory.filter(i=> i.kind!=='weapon_melee' && i.kind!=='weapon_ranged' && i.kind!=='armor' && i.kind!=='backpack');
 let takenAny = false;
 const rounds = Math.min(2, eligible.length);
 for(let i=0;i<rounds;i++){
  if(!eligible.length) break;
  const idx = Math.floor(Math.random()*eligible.length);
  const it = eligible[idx];
  const take = Math.min(it.qty, randInt(1, Math.max(1, Math.ceil(it.qty/2))));
  removeFromInventory(S, it.id, take);
  takenAny = true;
  eligible.splice(idx,1);
 }
 S.karma += 5;
 S.flags.warehouse_choice = 'peace';
 S.flags.warehouse_choice_done = true;
 toast(takenAny ? "You hand over some supplies. Truce. (+5 Karma)" : "Kade takes the truce even though you've got nothing to give. (+5 Karma)", 'amber');
 completeQuestByFlag('warehouse_choice');
 renderInventoryModal();
}
function runDialogueAction(action, npc){
 if(action.startsWith('recruit_')){ recruitCompanion(action.slice('recruit_'.length)); return; }
 if(action.startsWith('survivor_meet_')){ S.flags['survivor_met_'+action.slice('survivor_meet_'.length)] = true; return; }
 if(action.startsWith('survivor_turnin_')){ trySurvivorTurnin(action.slice('survivor_turnin_'.length)); return; }
 if(action.startsWith('rest_')){
  const cid = action.slice('rest_'.length);
  S.companionResting[cid] = true;
  toast((COMPANIONS.find(c=>c.id===cid)||{}).name+' will rest at camp.', 'amber');
  spawnCompanionsInWorld();
  return;
 }
 if(action.startsWith('follow_')){
  const cid = action.slice('follow_'.length);
  S.companionResting[cid] = false;
  toast((COMPANIONS.find(c=>c.id===cid)||{}).name+' is ready to move out.', 'amber');
  spawnCompanionsInWorld();
  return;
 }
 switch(action){
  case 'open_trade': S.tradeContext='camp'; document.getElementById('dialogue').style.display='none'; Game.showModal('trade'); break;
  case 'exchange_gold': {
   const g = findInv(S,'gold_bars');
   if(!g){ toast("You don't have any gold bars.", 'bad'); break; }
   removeFromInventory(S,'gold_bars',g.qty);
   S.tokens += 100;
   toast('Joe exchanges your gold for 100 tokens.', 'amber');
   renderInventoryModal();
   updateHudDynamic();
   break;
  }
  case 'start_camp_siege':
   // Wipe any zombies that wandered into camp before the player agreed to
   // help — the siege should start from a clean camp, not carry over
   // whatever was already wandering around.
   W.zombies = [];
   S.flags.camp_siege_active = true;
   S.campSiege = {active:true, wave:1};
   spawnCampWave(1);
   toast('Wave 1 of 3 incoming!', 'bad');
   break;
  case 'accept_doctor_quest':
   S.flags.doctor_quest_given = true;
   toast('New objective: Bedside Manner', 'amber');
   activateNextQuests();
   break;
  case 'report_harrowed':
   S.flags.harrowed_reported = true;
   completeQuestByFlag('harrowed_reported');
   toast('The truck is ready when you are.', 'amber');
   break;
  case 'open_trade_blockade': S.tradeContext='blockade'; document.getElementById('dialogue').style.display='none'; Game.showModal('trade'); break;
  case 'open_trade_doctor': S.tradeContext='doctor'; document.getElementById('dialogue').style.display='none'; Game.showModal('trade'); break;
  case 'doctor_heal': doctorHeal(); break;
  case 'doctor_fetch_supplies': doctorFetchSupplies(); break;
  case 'hospital_save':
   S.karma+=8;
   S.flags.hospital_choice='save'; S.flags.hospital_choice_done=true;
   S.flags.doctor_quest_given = true;
   if(findInv(S,'hospital_keycard')){ removeFromInventory(S,'hospital_keycard',1); S.flags['keycard_used_hospital_keycard']=true; }
   S.flags.doctor_following = true;
   toast('Dr. Voss will follow you back to camp.', 'amber');
   completeQuestByFlag('hospital_choice');
   spawnCompanionsInWorld();
   renderInventoryModal();
   break;
  case 'hospital_abandon': S.karma-=8; S.flags.hospital_choice='abandon'; S.flags.hospital_choice_done=true; S.flags.doctor_quest_given=true; toast('You leave him behind.', 'bad'); completeQuestByFlag('hospital_choice'); break;
  case 'warehouse_fight':
   S.flags.warehouse_choice='fight'; S.flags.warehouse_choice_done=true;
   W.bandits.push(spawnBandit(findLocation('warehouse'),'captain'), spawnBandit(findLocation('warehouse'),'grunt'));
   if(S.currentLocation==='warehouse' && W.npcs){
    const onScreenGuards = W.npcs.filter(n=>n.isWarehouseGuard);
    W.npcs = W.npcs.filter(n=>!n.isWarehouseGuard);
    onScreenGuards.forEach(gm=>{
     const b = spawnBandit(findLocation('warehouse'), Math.random()<0.5?'grunt':'hooded');
     b.x = gm.x; b.y = gm.y;
     W.bandits.push(b);
    });
   }
   toast('Kade\'s crew opens fire!', 'bad');
   completeQuestByFlag('warehouse_choice');
   break;
  case 'warehouse_peace': giveSuppliesForPeace(); break;
  case 'warehouse_corrupt': S.karma-=6; S.tokens+=15; S.flags.warehouse_choice='corrupt'; S.flags.warehouse_choice_done=true; toast('Tokens change hands quietly.', 'bad'); completeQuestByFlag('warehouse_choice'); break;
  case 'ruins_expose': S.karma+=5; S.flags.bad_trade='expose'; toast('You call Milo out.', 'amber'); completeQuestByFlag('bad_trade'); break;
  case 'ruins_ignore': S.karma-=3; S.tokens+=10; S.flags.bad_trade='ignore'; toast('You keep quiet.', 'bad'); completeQuestByFlag('bad_trade'); break;
  case 'ghost_easter_egg': addToInventory(S,'pillow','weapon_melee',1); S.flags.ghost_story='found'; toast('You take the pillow.', 'amber'); completeQuestByFlag('ghost_story'); break;
  case 'start_boss': document.getElementById('dialogue').style.display='none'; spawnBoss(); break;
 }
 checkAchievements();
}

/* ================= HUD SYNC ================= */
function updateHudLocation(){
 const loc = findLocation(S.currentLocation);
 document.getElementById('hud-loc').textContent = (W && W.isInterior) ? 'Inside: '+(S.interiorLabel||loc.name) : loc.name;
 document.getElementById('hud-danger').textContent = (W && W.isInterior) ? 'DANGER: NONE' : 'DANGER: '+loc.danger;
 document.getElementById('hud-name').textContent = S.name.toUpperCase();
}
function fmtClock(min){
 const h = Math.floor(min/60)%24, m = Math.floor(min%60);
 return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
}
function updateHudDynamic(){
 if(!S) return;
 document.getElementById('v-hp').style.width = clamp(S.hp/S.maxHp*100,0,100)+'%';
 document.getElementById('v-stam').style.width = clamp(S.stamina/S.maxStamina*100,0,100)+'%';
 document.getElementById('v-hunger').style.width = clamp(S.hunger,0,100)+'%';
 document.getElementById('v-thirst').style.width = clamp(S.thirst,0,100)+'%';
 document.getElementById('hud-lvl').textContent = S.level+(S.level>=MAX_LEVEL?' (MAX)':'');
 document.getElementById('hud-xp').style.width = clamp(S.xp/S.xpNext*100,0,100)+'%';
 const xpText = document.getElementById('hud-xp-text');
 if(xpText) xpText.textContent = S.level>=MAX_LEVEL ? 'MAX LEVEL' : (Math.floor(S.xp)+' / '+S.xpNext+' XP');
 document.getElementById('hud-cha').textContent = S.charisma;
 const karEl = document.getElementById('hud-kar');
 karEl.textContent = (S.karma>=0?'+':'')+S.karma;
 karEl.style.color = S.karma>0?'var(--toxin)':(S.karma<0?'var(--blood-bright)':'var(--bone)');
 document.getElementById('hud-tok').textContent = S.tokens;
 document.getElementById('hud-kills').textContent = S.kills+S.banditKills;
 const spRow = document.getElementById('hud-sp-row');
 if(spRow){ spRow.style.display = S.skillPoints>0 ? 'flex' : 'none'; document.getElementById('hud-sp').textContent = S.skillPoints; }
 document.getElementById('hud-clock').textContent = 'DAY '+S.dayCount+' · '+fmtClock(S.gameMinutes);
 renderStatusIcons();
 renderAmmoHud();
}
function renderStatusIcons(){
 const active=[];
 if(S.status.bleeding>0) active.push('bleeding');
 if(S.status.infected>0) active.push('infected');
 if(S.status.sick>0) active.push('sick');
 if(S.hunger<=0) active.push('hungry');
 if(S.thirst<=0) active.push('dehydrated');
 const wrap = document.getElementById('status-icons');
 if(wrap){
  wrap.innerHTML='';
  active.forEach(k=>{
   const d=document.createElement('div'); d.className='status-icon'; d.title=STATUS_INFO[k].name+': '+STATUS_INFO[k].desc;
   d.textContent = STATUS_INFO[k].icon; wrap.appendChild(d);
  });
 }
 const panel = document.getElementById('ailments-panel');
 const body = document.getElementById('ailments-body');
 if(panel && body){
  if(active.length===0){ panel.classList.remove('show'); }
  else {
   panel.classList.add('show');
   body.innerHTML='';
   active.forEach(k=>{
    const row = document.createElement('div'); row.className='ailment-row';
    row.innerHTML = `<span class="ic">${STATUS_INFO[k].icon}</span><span class="txt"><b>${STATUS_INFO[k].name}</b><span>${STATUS_INFO[k].desc}</span></span>`;
    body.appendChild(row);
   });
  }
 }
}
function renderWeaponSlots(){
 const wrap = document.getElementById('weaponSlots'); wrap.innerHTML='';
 const order=[['melee','1'],['secondary','2'],['primary','3'],['rocket','4'],['throwable','5']];
 order.forEach(([slot,num])=>{
  const wid = S.weaponSlots[slot];
  const d = document.createElement('div');
  d.className='slot'+(S.activeSlot===slot?' active':'');
  d.onclick=()=>{ S.activeSlot=slot; renderWeaponSlots(); };
  const w = wid?findWeaponById(wid):null;
  d.innerHTML = `<span class="num">${num}</span>${w?`<span>${iconHtml(w.icon,w.img,16)}</span><span class="nm">${w.name}</span>`:`<span class="nm">—</span>`}`;
  wrap.appendChild(d);
 });
 renderAmmoHud();
}
function renderAmmoHud(){
 const wrap = document.getElementById('ammo-hud'); if(!wrap) return;
 wrap.innerHTML='';
 ['secondary','primary','rocket'].forEach(slot=>{
  const wid = S.weaponSlots[slot]; if(!wid) return;
  const w = WEAPONS_RANGED[wid];
  const row = document.createElement('div');
  if(!w.ammo){
   row.className='ammo-row';
   row.innerHTML = `<span>${iconHtml(w.icon,w.img,16)} ${w.name}</span><b>∞</b>`;
   wrap.appendChild(row);
   return;
  }
  const apKey = AP_AMMO_FOR[w.ammo];
  const selected = (S.ammoVariant && S.ammoVariant[slot]==='ap' && apKey) ? 'ap' : 'normal';
  const chambered = (S.magAmmoIsAP && S.magAmmoIsAP[slot]) ? 'ap' : 'normal';
  const ammoKey = selected==='ap' ? apKey : w.ammo;
  const reserve = findInv(S,'ammo_'+ammoKey); const rq = reserve?reserve.qty:0;
  const low = (S.magAmmo[slot]||0)<=0;
  row.className='ammo-row'+(low?' low':'');
  // Variant indicator: which rounds are actually chambered right now takes
  // priority visually (that's what your next shot uses); if you've dragged
  // a different variant on but haven't reloaded yet, show that as "next".
  let variantTag = '';
  if(apKey){
   const chamberedTag = chambered==='ap' ? `<span class="ammo-variant ap">AP</span>` : `<span class="ammo-variant std">STD</span>`;
   const pendingTag = (selected!==chambered) ? `<span class="ammo-variant pending">${selected==='ap'?'AP':'STD'} next</span>` : '';
   variantTag = chamberedTag + pendingTag;
  }
  row.innerHTML = `<span>${iconHtml(w.icon,w.img,16)} ${w.name} ${variantTag}</span><b>${S.magAmmo[slot]||0} / ${rq}</b>${low?'<span class="reload-hint">[R] RELOAD</span>':''}`;
  wrap.appendChild(row);
 });
 const twid = S.weaponSlots.throwable;
 const trow = document.getElementById('throwable-hud');
 if(trow){
  if(twid){ const inv=findInv(S,twid); trow.innerHTML = `${WEAPONS_THROWABLE[twid].icon} ${WEAPONS_THROWABLE[twid].name} × ${inv?inv.qty:0}`; }
  else trow.innerHTML = '';
 }
}

/* ================= RENDER ================= */
function facingAngle(){ return Math.atan2(S.facing.y,S.facing.x); }

/* ---- small drawing helpers shared by structures + character tokens ---- */
function roundRectPath(x,y,w,h,r){
 r = Math.min(r, Math.abs(w)/2, Math.abs(h)/2);
 activeCtx.moveTo(x+r,y);
 activeCtx.arcTo(x+w,y,x+w,y+h,r);
 activeCtx.arcTo(x+w,y+h,x,y+h,r);
 activeCtx.arcTo(x,y+h,x,y,r);
 activeCtx.arcTo(x,y,x+w,y,r);
 activeCtx.closePath();
}
function roundRect(x,y,w,h,r){ activeCtx.beginPath(); roundRectPath(x,y,w,h,r); }
function shadeColor(hex, percent){
 if(!hex || hex[0]!=='#') return hex;
 const num = parseInt(hex.slice(1),16);
 let r=(num>>16)+percent, g=((num>>8)&0xff)+percent, b=(num&0xff)+percent;
 r=clamp(r,0,255); g=clamp(g,0,255); b=clamp(b,0,255);
 return '#'+((1<<24)+(Math.round(r)<<16)+(Math.round(g)<<8)+Math.round(b)).toString(16).slice(1);
}
function labelTag(p){
 // Building/furniture name tags intentionally disabled — the player reads the
 // shape of a room, not a text tag floating over it. Map/location names
 // (rendered in the travel UI, not on the canvas) are unaffected.
}

/* ---- character token: small human silhouette (legs, torso, head) instead of a plain circle ---- */
const WEAPON_IMG_CACHE = {};
function weaponImg(w){
 if(!w || !w.img) return null;
 if(!WEAPON_IMG_CACHE[w.img]){ const im=new Image(); im.src=w.img; WEAPON_IMG_CACHE[w.img]=im; }
 return WEAPON_IMG_CACHE[w.img];
}
/* Draws the given weapon's art in the local (already-translated) character
   space, pointing along `angle`. Returns false (and draws nothing) if the
   image isn't loaded yet, so callers can fall back to a simple stroke. */
function drawHeldWeapon(w, angle, size){
 const img = weaponImg(w);
 if(!img || !img.complete || !img.naturalWidth) return false;
 size = size||26;
 const asp = img.naturalHeight/img.naturalWidth;
 ctx.save();
 ctx.rotate(angle);
 ctx.translate(4,0);
 ctx.drawImage(img, 0, -size*asp/2, size, size*asp);
 ctx.restore();
 return true;
}
const BANDIT_RENDER_COLOR = {grunt:'#a4341f', hooded:'#241a12', grenadier:'#4a5a2a', light_armor:'#3a4a2a', captain:'#8a6a24', heavy_armor:'#2a3540'};
const BANDIT_BANDANA_COLOR = {grunt:'#1a1a1a', hooded:'#100d08', grenadier:'#556b2f', light_armor:'#3a4a1a', captain:'#e8b23d', heavy_armor:'#3fa0d8'};

/* ---- humanoid character model ----
   A complete simple body — two legs, two arms, torso, head — instead of a
   floating emoji standing in for the whole character. Every faction below
   builds on this same skeleton but with its own colors/posture/face, so
   Survivors, Companions, NPCs, Zombies and Bandits each read as a distinct
   kind of figure at a glance without needing an icon glued on top. */
function drawHumanoid(x,y,r,cfg){
 activeCtx.save(); activeCtx.translate(x,y);
 const hunch = (cfg.hunch||0) * r*0.3;
 // ground shadow
 activeCtx.beginPath(); activeCtx.ellipse(0,r*0.85,r*0.9,r*0.32,0,0,Math.PI*2); activeCtx.fillStyle='rgba(0,0,0,.35)'; activeCtx.fill();
 const armColor = cfg.armColor || shadeColor(cfg.bodyColor,-10);
 // back arm (behind torso)
 activeCtx.fillStyle = shadeColor(armColor,-12);
 activeCtx.fillRect(-r*0.82, -r*0.02+hunch, r*0.24, r*0.58);
 // legs
 activeCtx.fillStyle = cfg.legColor || 'rgba(10,10,8,.55)';
 activeCtx.fillRect(-r*0.36, r*0.15, r*0.3, r*0.72);
 activeCtx.fillRect(r*0.06, r*0.15, r*0.3, r*0.72);
 // backpack, worn behind the torso so it peeks out past the shoulder
 if(cfg.backpack){
  activeCtx.fillStyle = cfg.backpackColor || shadeColor(cfg.bodyColor,-35);
  roundRect(-r*0.52, -r*0.28+hunch, r*0.32, r*0.6, r*0.12); activeCtx.fill();
 }
 // torso
 roundRect(-r*0.62, -r*0.35+hunch, r*1.24, r*0.95, r*0.32);
 activeCtx.fillStyle = cfg.bodyColor; activeCtx.fill();
 activeCtx.lineWidth=1.5; activeCtx.strokeStyle='rgba(0,0,0,.45)'; activeCtx.stroke();
 // front arm
 activeCtx.fillStyle = armColor;
 activeCtx.fillRect(r*0.54, r*0.02+hunch, r*0.24, r*0.56);
 // head
 const headR = cfg.headR || r*0.48;
 const headY = -r*0.78 + hunch*1.5;
 activeCtx.beginPath(); activeCtx.arc(0, headY, headR, 0, Math.PI*2);
 activeCtx.fillStyle = cfg.headColor || shadeColor(cfg.bodyColor,-20); activeCtx.fill();
 activeCtx.lineWidth=1.2; activeCtx.strokeStyle='rgba(0,0,0,.45)'; activeCtx.stroke();
 if(cfg.face) cfg.face(headY, headR);
 if(cfg.facing){ const a=Math.atan2(cfg.facing.y,cfg.facing.x); activeCtx.beginPath(); activeCtx.moveTo(Math.cos(a)*r*0.3,Math.sin(a)*r*0.3); activeCtx.lineTo(Math.cos(a)*r*1.5,Math.sin(a)*r*1.5); activeCtx.strokeStyle='rgba(220,214,189,.9)'; activeCtx.lineWidth=3; activeCtx.stroke(); }
 if(cfg.extra) cfg.extra(headY, headR);
 activeCtx.restore();
}
/* Backwards-compatible alias — some older call sites still use the plain
   token shape (no face/backpack detail needed there). */
function drawCharToken(x,y,r,color,facing,extra){
 drawHumanoid(x,y,r,{bodyColor:color, facing, extra});
}
function faceDots(color){
 return (headY)=>{
  activeCtx.fillStyle = color || 'rgba(10,10,8,.85)';
  activeCtx.beginPath(); activeCtx.arc(-2.6,headY-1,1.3,0,Math.PI*2); activeCtx.arc(2.6,headY-1,1.3,0,Math.PI*2); activeCtx.fill();
 };
}
function faceZombie(){
 return (headY,headR)=>{
  activeCtx.fillStyle = '#c94a2e';
  activeCtx.beginPath(); activeCtx.arc(-headR*0.35,headY-headR*0.1,headR*0.18,0,Math.PI*2); activeCtx.arc(headR*0.35,headY-headR*0.1,headR*0.18,0,Math.PI*2); activeCtx.fill();
  activeCtx.strokeStyle='rgba(0,0,0,.6)'; activeCtx.lineWidth=1.4;
  activeCtx.beginPath(); activeCtx.moveTo(-headR*0.3,headY+headR*0.4); activeCtx.lineTo(headR*0.3,headY+headR*0.55); activeCtx.stroke();
 };
}
function faceScreamer(){
 return (headY,headR)=>{
  activeCtx.fillStyle = '#c94a2e';
  activeCtx.beginPath(); activeCtx.arc(-headR*0.32,headY-headR*0.15,headR*0.16,0,Math.PI*2); activeCtx.arc(headR*0.32,headY-headR*0.15,headR*0.16,0,Math.PI*2); activeCtx.fill();
  activeCtx.fillStyle='#0b0c08';
  activeCtx.beginPath(); activeCtx.ellipse(0,headY+headR*0.42,headR*0.32,headR*0.4,0,0,Math.PI*2); activeCtx.fill();
 };
}
function faceBandana(bandanaColor){
 return (headY,headR)=>{
  activeCtx.fillStyle = bandanaColor;
  activeCtx.fillRect(-headR*1.05, headY-headR*0.05, headR*2.1, headR*0.62);
  activeCtx.fillStyle='#0b0c08';
  activeCtx.beginPath(); activeCtx.arc(-headR*0.32,headY-headR*0.15,1.3,0,Math.PI*2); activeCtx.arc(headR*0.32,headY-headR*0.15,1.3,0,Math.PI*2); activeCtx.fill();
 };
}
function faceVisor(){
 return (headY,headR)=>{
  activeCtx.fillStyle='#151510'; activeCtx.fillRect(-headR, headY-headR*0.15, headR*2, headR*0.5);
 };
}
/* ---- Survivor (the player) ---- */
function drawSurvivorModel(x,y,r,color,facing,weaponDraw){
 drawHumanoid(x,y,r,{
  bodyColor:color, headColor:'#caa477', legColor:'#2a2b1e',
  backpack:true, backpackColor:shadeColor(color,-35),
  facing, face:faceDots('#241d14'),
  extra:()=>{ if(weaponDraw) weaponDraw(); }
 });
}
/* ---- Companions (recruited squadmates) ---- */
function drawCompanionModel(x,y,r,color,weaponDraw){
 drawHumanoid(x,y,r,{
  bodyColor:color, headColor:'#b98f63', legColor:'#22231a',
  face:faceDots('#20180f'),
  extra:(headY,headR)=>{
   // colored headband — reads as "one of your people" at a glance, distinct
   // from the player's backpack silhouette
   activeCtx.fillStyle = shadeColor(color,25);
   activeCtx.fillRect(-headR, headY-headR*0.78, headR*2, headR*0.32);
   if(weaponDraw) weaponDraw();
  }
 });
}
/* ---- Camp/world NPCs (non-combatant) ---- */
function drawNpcModel(x,y,r,color){
 drawHumanoid(x,y,r,{
  bodyColor:color, headColor:'#c9a37a', legColor:shadeColor(color,-40),
  face:faceDots('#221a10')
 });
}
/* ---- Watchtower guards ---- */
function drawGuardModel(x,y,r,color,weaponDraw){
 drawHumanoid(x,y,r,{
  bodyColor:color, headColor:'#3a3a30', headR:r*0.46, legColor:'#1a1a14',
  face:faceVisor(),
  extra:()=>{ if(weaponDraw) weaponDraw(); }
 });
}
/* ---- Zombies ----
   Every variant gets its own silhouette cue (headwear, vest, apron, etc.) on
   top of the shared skeleton, so the specific kind of zombie is readable at
   a glance instead of every walker looking the same. */
const ZOMBIE_VISUAL = {
 walker:    {},
 labor:     {helmet:'hardhat', helmetColor:'#e8b23d', vest:'#c1541c'},
 nurse:     {cap:'nurse', bodyTint:'#5a6a6a'},
 scavenger: {backpack:true},
 miner:     {helmet:'hardhat', helmetColor:'#7a7a20', lamp:true},
 mechanic:  {vest:'#2f4a7a', overalls:true},
 baseball:  {cap:'ballcap', capColor:'#8a2a1a'},
 butcher:   {apron:true},
 screamer:  {gaunt:true},
 dog:       {quadruped:true},
 fireman:   {helmet:'fire', helmetColor:'#8a2a1a', stripe:true},
 police:    {cap:'police', capColor:'#1c2028'},
 medic:     {cross:true, bodyTint:'#8a8570'},
 soldier:   {helmet:'army', helmetColor:'#3a4a20', camo:true},
 tank:      {armor:true}
};
function drawZombieModel(x,y,r,variantId,charging){
 const vis = ZOMBIE_VISUAL[variantId] || {};
 if(vis.quadruped){ drawZombieDog(x,y,r); return; }
 const isTank = variantId==='tank';
 const bodyColor = isTank ? '#5a2015' : (vis.bodyTint || '#42522a');
 drawHumanoid(x,y,r,{
  bodyColor, headColor:shadeColor(bodyColor,-15),
  legColor:shadeColor(bodyColor,-25), armColor:shadeColor(bodyColor,-6),
  hunch: isTank?0.15:0.35, headR: isTank? r*0.5 : r*0.42,
  face: vis.gaunt ? faceScreamer() : faceZombie(),
  extra:(headY,headR)=>{
   if(vis.backpack){ activeCtx.fillStyle=shadeColor(bodyColor,-35); roundRect(-r*0.52,-r*0.1,r*0.3,r*0.5,r*0.1); activeCtx.fill(); }
   if(vis.vest){ activeCtx.fillStyle=vis.vest; activeCtx.fillRect(-r*0.5,-r*0.08,r*1.0,r*0.34); }
   if(vis.overalls){ activeCtx.fillStyle='rgba(20,20,16,.4)'; activeCtx.fillRect(-r*0.5,r*0.05,r*0.2,r*0.5); activeCtx.fillRect(r*0.3,r*0.05,r*0.2,r*0.5); }
   if(vis.apron){ activeCtx.fillStyle='rgba(196,190,168,.85)'; activeCtx.fillRect(-r*0.42,-r*0.12,r*0.84,r*0.68); activeCtx.strokeStyle='rgba(196,74,46,.7)'; activeCtx.lineWidth=1.3; activeCtx.beginPath(); activeCtx.moveTo(-r*0.25,r*0.05); activeCtx.lineTo(r*0.1,r*0.45); activeCtx.moveTo(r*0.2,-r*0.05); activeCtx.lineTo(r*0.02,r*0.3); activeCtx.stroke(); }
   if(vis.cross){ activeCtx.fillStyle='#c94a2e'; activeCtx.fillRect(-r*0.06,-r*0.05,r*0.12,r*0.34); activeCtx.fillRect(-r*0.18,r*0.06,r*0.36,r*0.12); }
   if(vis.camo){ activeCtx.fillStyle='rgba(20,30,10,.4)'; activeCtx.beginPath(); activeCtx.arc(-r*0.2,r*0.05,r*0.15,0,Math.PI*2); activeCtx.arc(r*0.15,r*0.22,r*0.12,0,Math.PI*2); activeCtx.fill(); }
   if(vis.stripe){ activeCtx.fillStyle='rgba(232,178,61,.85)'; activeCtx.fillRect(-r*0.5,r*0.18,r*1.0,r*0.1); }
   if(vis.helmet==='hardhat'){ activeCtx.fillStyle=vis.helmetColor; activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.3,headR*0.98,Math.PI,0); activeCtx.fill(); if(vis.lamp){ activeCtx.fillStyle='#e8b23d'; activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.55,headR*0.16,0,Math.PI*2); activeCtx.fill(); } }
   if(vis.helmet==='fire'){ activeCtx.fillStyle=vis.helmetColor; activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.25,headR*1.02,Math.PI,0); activeCtx.fill(); activeCtx.fillRect(-headR*1.15,headY-headR*0.3,headR*2.3,headR*0.2); }
   if(vis.helmet==='army'){ activeCtx.fillStyle=vis.helmetColor; activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.22,headR*0.95,Math.PI,0); activeCtx.fill(); }
   if(vis.cap==='nurse'){ activeCtx.fillStyle='#e9e5d6'; activeCtx.fillRect(-headR*0.65,headY-headR*1.1,headR*1.3,headR*0.36); activeCtx.fillStyle='#c94a2e'; activeCtx.fillRect(-headR*0.1,headY-headR*1.0,headR*0.2,headR*0.18); }
   if(vis.cap==='ballcap'){ activeCtx.fillStyle=vis.capColor; activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.15,headR*0.98,Math.PI*1.05,Math.PI*1.95); activeCtx.fill(); activeCtx.fillRect(-headR*0.05,headY-headR*0.85,headR*1.05,headR*0.2); }
   if(vis.cap==='police'){ activeCtx.fillStyle=vis.capColor; activeCtx.fillRect(-headR,headY-headR*1.05,headR*2,headR*0.46); activeCtx.fillStyle='#e8b23d'; activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.85,headR*0.13,0,Math.PI*2); activeCtx.fill(); }
   if(isTank && vis.armor){ activeCtx.strokeStyle='rgba(90,60,40,.7)'; activeCtx.lineWidth=3; activeCtx.strokeRect(-r*0.5,-r*0.2,r*1.0,r*0.7); }
   if(isTank && charging>0){ activeCtx.strokeStyle='rgba(232,178,61,.8)'; activeCtx.lineWidth=3; activeCtx.beginPath(); activeCtx.arc(0,0,r+10,0,Math.PI*2); activeCtx.stroke(); }
  }
 });
}
/* Zombie Dog — the one variant that doesn't fit the humanoid skeleton at
   all, so it gets its own compact quadruped silhouette. */
function drawZombieDog(x,y,r){
 activeCtx.save(); activeCtx.translate(x,y);
 activeCtx.beginPath(); activeCtx.ellipse(0,r*0.6,r*0.85,r*0.26,0,0,Math.PI*2); activeCtx.fillStyle='rgba(0,0,0,.35)'; activeCtx.fill();
 const bodyColor='#3a4a22';
 activeCtx.fillStyle=shadeColor(bodyColor,-25);
 activeCtx.fillRect(-r*0.55,r*0.05,r*0.16,r*0.48);
 activeCtx.fillRect(-r*0.18,r*0.1,r*0.16,r*0.48);
 activeCtx.fillRect(r*0.12,r*0.1,r*0.16,r*0.48);
 activeCtx.fillRect(r*0.45,r*0.05,r*0.16,r*0.48);
 activeCtx.strokeStyle=shadeColor(bodyColor,-10); activeCtx.lineWidth=Math.max(2,r*0.12);
 activeCtx.beginPath(); activeCtx.moveTo(-r*0.65,-r*0.1); activeCtx.lineTo(-r*0.9,-r*0.32); activeCtx.stroke();
 activeCtx.beginPath(); activeCtx.ellipse(0,-r*0.1,r*0.72,r*0.36,0,0,Math.PI*2); activeCtx.fillStyle=bodyColor; activeCtx.fill();
 activeCtx.lineWidth=1.2; activeCtx.strokeStyle='rgba(0,0,0,.45)'; activeCtx.stroke();
 activeCtx.beginPath(); activeCtx.arc(r*0.7,-r*0.16,r*0.3,0,Math.PI*2); activeCtx.fillStyle=shadeColor(bodyColor,-15); activeCtx.fill(); activeCtx.stroke();
 activeCtx.fillStyle=shadeColor(bodyColor,-20); activeCtx.fillRect(r*0.9,-r*0.18,r*0.22,r*0.16);
 activeCtx.fillStyle='#c94a2e'; activeCtx.beginPath(); activeCtx.arc(r*0.78,-r*0.24,r*0.06,0,Math.PI*2); activeCtx.fill();
 activeCtx.restore();
}
/* ---- Bandits ----
   Cosmetic armor tier + weapon type already existed in the data; now each
   one shows up as a visually distinct load-out instead of the same body
   with a different bandana color. */
const BANDIT_VISUAL = {
 grunt:       {},
 hooded:      {hood:true},
 grenadier:   {pouches:true},
 light_armor: {plates:'light'},
 captain:     {epaulettes:true, cap:true},
 heavy_armor: {plates:'heavy', visor:true}
};
function drawBanditModel(x,y,r,variantId,weaponDraw){
 const bodyColor = BANDIT_RENDER_COLOR[variantId] || '#a4341f';
 const bandanaColor = BANDIT_BANDANA_COLOR[variantId] || '#1a1a1a';
 const vis = BANDIT_VISUAL[variantId] || {};
 drawHumanoid(x,y,r,{
  bodyColor, headColor:'#a9835c', legColor:'#171712',
  face: vis.visor ? faceVisor() : faceBandana(bandanaColor),
  extra:(headY,headR)=>{
   if(vis.hood){ activeCtx.fillStyle=shadeColor(bodyColor,-45); activeCtx.beginPath(); activeCtx.arc(0,headY-headR*0.05,headR*1.18,Math.PI*0.9,Math.PI*2.1); activeCtx.fill(); }
   if(vis.pouches){ activeCtx.fillStyle='#2a2a1e'; activeCtx.fillRect(-r*0.4,-r*0.05,r*0.22,r*0.3); activeCtx.fillRect(r*0.18,-r*0.05,r*0.22,r*0.3); }
   if(vis.plates==='light'){ activeCtx.fillStyle='rgba(150,150,140,.5)'; activeCtx.fillRect(-r*0.5,-r*0.25,r*1.0,r*0.3); }
   if(vis.plates==='heavy'){
    activeCtx.fillStyle='rgba(120,120,120,.75)';
    activeCtx.fillRect(-r*0.58,-r*0.32,r*1.16,r*0.85);
    activeCtx.strokeStyle='rgba(0,0,0,.5)'; activeCtx.strokeRect(-r*0.58,-r*0.32,r*1.16,r*0.85);
    activeCtx.fillRect(-r*0.9,-r*0.05,r*0.3,r*0.3); activeCtx.fillRect(r*0.6,-r*0.05,r*0.3,r*0.3);
   }
   if(vis.epaulettes){ activeCtx.fillStyle='#e8b23d'; activeCtx.fillRect(-r*0.72,-r*0.15,r*0.24,r*0.14); activeCtx.fillRect(r*0.48,-r*0.15,r*0.24,r*0.14); }
   if(vis.cap){ activeCtx.fillStyle='#3a2a10'; activeCtx.fillRect(-headR,headY-headR*1.0,headR*2,headR*0.38); }
   if(weaponDraw) weaponDraw();
  }
 });
}
/* ---- Boss (The Harrowed) ---- */
function drawBossModel(x,y,r){
 drawHumanoid(x,y,r,{
  bodyColor:'#4a1810', headColor:'#2a0e08', legColor:'#1a0a06', armColor:'#3a140c',
  hunch:0.3, headR:r*0.55,
  face:(headY,headR)=>{
   activeCtx.fillStyle='#e8b23d';
   activeCtx.beginPath(); activeCtx.arc(-headR*0.4,headY-headR*0.1,headR*0.22,0,Math.PI*2); activeCtx.arc(headR*0.4,headY-headR*0.1,headR*0.22,0,Math.PI*2); activeCtx.fill();
  },
  extra:()=>{
   activeCtx.strokeStyle='rgba(196,74,46,.5)'; activeCtx.lineWidth=2;
   activeCtx.beginPath(); activeCtx.arc(0,0,r+6,0,Math.PI*2); activeCtx.stroke();
  }
 });
}
/* ---- Small offscreen snapshot for the Trophies list ----
   Renders the exact same model used in the world onto a tiny cached canvas,
   so a trophy's icon matches its variant instead of a generic emoji. */
const CHAR_ICON_CACHE = {};
function getVariantIconDataUrl(kind, variantId){
 const key = kind+':'+variantId;
 if(CHAR_ICON_CACHE[key]) return CHAR_ICON_CACHE[key];
 const size = 48;
 const off = document.createElement('canvas'); off.width = size; off.height = size;
 const octx = off.getContext('2d');
 const prev = activeCtx;
 activeCtx = octx;
 try{
  const r = size*0.32;
  if(kind==='zombie') drawZombieModel(size/2, size*0.62, r, variantId, 0);
  else if(kind==='bandit') drawBanditModel(size/2, size*0.62, r, variantId, null);
  else if(kind==='boss') drawBossModel(size/2, size*0.62, r);
 } finally {
  activeCtx = prev;
 }
 const url = off.toDataURL('image/png');
 CHAR_ICON_CACHE[key] = url;
 return url;
}


/* ---- structures: each prop kit label gets a distinct silhouette instead of a flat rectangle ---- */
function drawStructure(p){
 ctx.save();
 switch(p.label){
  case 'House': drawHouse(p,false); break;
  case 'Main Building': drawHouse(p,true); break;
  case 'Camp Hall': drawHall(p,'#1c1d13','#2a2b1c'); break;
  case 'Ward': drawHall(p,'#151710','#232418'); break;
  case 'Nurse Station': drawHall(p,'#1c1d13','#2a2b1c'); break;
  case 'Terminal': drawHall(p,'#171810','#2a2a1a'); break;
  case 'Teller Row': drawHall(p,'#171810','#2a2a1a'); break;
  case 'Kitchen': drawHall(p,'#20160e','#2e2013'); break;
  case 'Tent': drawTent(p); break;
  case 'Shelving': case 'Shelf': case 'Aisle': drawShelfBlock(p); break;
  case 'Rubble': drawRubble(p); break;
  case 'Headstone': drawHeadstone(p); break;
  case 'Bus': drawBus(p); break;
  case 'Vault': drawVault(p); break;
  case 'L2 Vault': drawVault(p); break;
  case 'Car': drawCar(p); break;
  case 'Barrier Fence': case 'Perimeter Fence': drawFence(p); break;
 case 'Barbwire': drawBarbwire(p); break;
  case 'Container': drawContainer(p); break;
  case 'Crane Base': drawCrane(p); break;
  case 'Luggage Cart': drawCart(p); break;
  case 'Runway Edge': drawRunway(p); break;
  case 'Plane': drawPlane(p); break;
  case 'Big Truck': drawBigTruck(p); break;
  case 'Flagpole': drawFlagpole(p); break;
  case 'Table': drawTable(p); break;
  case 'Bunker': drawBunker(p); break;
  case 'Deep Lab Access': drawLabDoor(p); break;
  case 'GasPump': drawGasPump(p); break;
  case 'Church': drawChurch(p); break;
  case 'Silo': drawSilo(p); break;
  case 'Barn': drawBarn(p); break;
  case 'Tracks': drawTracks(p); break;
  case 'Watchtower': drawWatchtower(p); break;
  case 'Antenna': drawAntenna(p); break;
  case 'Bench': drawBench(p); break;
  case 'Tree': drawTree(p); break;
  case 'Lamppost': drawLamppost(p); break;
  case 'Dumpster': drawDumpster(p); break;
  case 'Mailbox': drawMailbox(p); break;
  case 'VendingMachine': drawVendingMachine(p); break;
  case 'FireHydrant': drawFireHydrant(p); break;
  case 'TrafficCone': drawTrafficCone(p); break;
  case 'Bush': drawBush(p); break;
  case 'WreckedCar': drawWreckedCar(p); break;
  case 'CrashedHelicopter': drawCrashedHelicopter(p); break;
  case 'Barrel': drawBarrel(p); break;
  case 'Ambulance': drawAmbulance(p); break;
  case 'PoliceCar': drawPoliceCar(p); break;
  case 'RedCross': drawRedCross(p); break;
  case 'Laboratory': drawLaboratory(p); break;
  case 'DollarSign': drawDollarSign(p); break;
  case 'Cubicle': drawCubicle(p); break;
  case 'ATM': drawATM(p); break;
  case 'ChiefsOffice': drawChiefsOffice(p); break;
  case 'Armory': drawArmory(p); break;
  case 'JailCell': drawJailCell(p); break;
  case 'Door': drawDoorMarker(p); break;
  default: drawGenericBlock(p);
 }
 // Any prop — building, wreck, tent, whatever — can be tagged `.burning`
 // for a flickering fire/smoke overlay, independent of its base shape.
 if(p.burning) drawBurningOverlay(p);
 ctx.restore();
}
/* Flickering fire + rising smoke, layered on top of an already-drawn prop.
   Reused for burning buildings, torched vehicles, smoldering rubble — set
   `.burning = true` on any raw prop entry to apply it. */
function drawBurningOverlay(p){
 const {x,y,w,h}=p;
 const t = performance.now();
 for(let i=0;i<3;i++){
  const sx = x + w*(0.22+i*0.28);
  const rise = (t/34 + i*90) % 160;
  const alpha = Math.max(0, 0.3 - rise/480);
  if(alpha<=0) continue;
  ctx.beginPath(); ctx.arc(sx + Math.sin(t/480+i)*6, y-rise*0.65, 9+rise*0.09, 0, Math.PI*2);
  ctx.fillStyle = `rgba(55,52,48,${alpha})`; ctx.fill();
 }
 const flames = Math.max(2, Math.round(w/90));
 for(let i=0;i<flames;i++){
  const fx = x + w*((i+0.5)/flames);
  const flick = 0.7+Math.sin(t/110+i*1.7)*0.3;
  ctx.beginPath(); ctx.moveTo(fx,y); ctx.quadraticCurveTo(fx-7*flick,y-15*flick,fx,y-26*flick); ctx.quadraticCurveTo(fx+7*flick,y-15*flick,fx,y);
  ctx.fillStyle = `rgba(232,140,40,${0.75*flick})`; ctx.fill();
  ctx.beginPath(); ctx.moveTo(fx,y-2); ctx.quadraticCurveTo(fx-3.5*flick,y-11*flick,fx,y-18*flick); ctx.quadraticCurveTo(fx+3.5*flick,y-11*flick,fx,y-2);
  ctx.fillStyle = `rgba(255,210,80,${0.85*flick})`; ctx.fill();
 }
 ctx.fillStyle = `rgba(196,74,46,${0.07+Math.sin(t/220)*0.03})`;
 ctx.fillRect(x,y,w,h);
}
function drawPlane(p){
 const {x,y,w,h}=p;
 ctx.fillStyle = p.fill||'#b9b9ae';
 roundRect(x, y+h*0.38, w, h*0.28, h*0.14); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
 // wings
 ctx.fillStyle = '#9d9d92';
 ctx.beginPath(); ctx.moveTo(x+w*0.38,y+h*0.5); ctx.lineTo(x+w*0.12,y+h*0.02); ctx.lineTo(x+w*0.52,y+h*0.42); ctx.closePath(); ctx.fill();
 ctx.beginPath(); ctx.moveTo(x+w*0.38,y+h*0.56); ctx.lineTo(x+w*0.12,y+h*0.98); ctx.lineTo(x+w*0.52,y+h*0.64); ctx.closePath(); ctx.fill();
 // tail fin
 ctx.fillStyle='#8a8a7e';
 ctx.beginPath(); ctx.moveTo(x+w*0.93,y+h*0.4); ctx.lineTo(x+w*1.0,y+h*0.04); ctx.lineTo(x+w*0.98,y+h*0.52); ctx.closePath(); ctx.fill();
 // nose cone
 ctx.fillStyle=p.fill||'#b9b9ae';
 ctx.beginPath(); ctx.ellipse(x,y+h*0.52,w*0.02,h*0.14,0,0,Math.PI*2); ctx.fill();
 // windows
 ctx.fillStyle='rgba(40,60,70,.7)';
 for(let i=0;i<Math.floor(w/40);i++) ctx.fillRect(x+w*0.15+i*36, y+h*0.44, 10, 8);
 // fuselage stripe
 ctx.strokeStyle='#c94a2e'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x+w*0.06,y+h*0.52); ctx.lineTo(x+w*0.9,y+h*0.52); ctx.stroke();
 if(p.crashed){
  ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.lineWidth=1.5;
  ctx.beginPath(); ctx.moveTo(x+w*0.25,y+h*0.4); ctx.lineTo(x+w*0.55,y+h*0.75); ctx.stroke();
  ctx.fillStyle='rgba(40,40,35,.5)';
  for(let i=0;i<8;i++) ctx.fillRect(x+rand(0,w),y+rand(h*0.3,h*0.8),3,3);
 }
}
function drawBigTruck(p){
 const {x,y,w,h}=p;
 // cargo box (rear, larger portion)
 ctx.fillStyle = p.fill||'#2a3a2a';
 ctx.fillRect(x+w*0.32, y, w*0.68, h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x+w*0.32,y,w*0.68,h);
 ctx.strokeStyle='rgba(0,0,0,.25)'; ctx.lineWidth=1;
 for(let i=1;i<5;i++){ const lx=x+w*0.32+(w*0.68)*(i/5); ctx.beginPath(); ctx.moveTo(lx,y); ctx.lineTo(lx,y+h); ctx.stroke(); }
 // cab (front)
 ctx.fillStyle = shadeColor(p.fill||'#2a3a2a', -15);
 ctx.fillRect(x, y+h*0.15, w*0.32, h*0.85);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y+h*0.15,w*0.32,h*0.85);
 ctx.fillStyle='rgba(60,80,90,.7)';
 ctx.fillRect(x+w*0.04,y+h*0.22,w*0.22,h*0.28);
 ctx.fillStyle='#e8d9a0'; ctx.beginPath(); ctx.arc(x+w*0.03,y+h*0.75,4,0,Math.PI*2); ctx.fill();
 ctx.fillStyle='#100d08';
 [0.14,0.42,0.62,0.86].forEach(fx=>{ ctx.beginPath(); ctx.arc(x+w*fx, y+h, 9, 0, Math.PI*2); ctx.fill(); });
}
function drawGenericBlock(p){
 ctx.fillStyle = p.fill||'#171810'; ctx.fillRect(p.x,p.y,p.w,p.h);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.lineWidth=1; ctx.strokeRect(p.x,p.y,p.w,p.h);
 labelTag(p);
}
function drawHouse(p, big){
 const {x,y,w,h}=p;
 if(p.variant==='flat' && !big){ drawHall(p, p.fill||'#1c1a14', '#2a2015'); return; }
 const roofH = h*0.32, wallH = h-roofH, wallY = y+roofH;
 ctx.fillStyle = p.fill||'#1c1a14';
 ctx.fillRect(x, wallY, w, wallH);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.lineWidth=1; ctx.strokeRect(x,wallY,w,wallH);
 ctx.beginPath();
 ctx.moveTo(x-6, wallY+3);
 ctx.lineTo(x+w/2, y);
 ctx.lineTo(x+w+6, wallY+3);
 ctx.closePath();
 ctx.fillStyle='#2a2015'; ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 const doorW = Math.min(22, w*0.16), doorH = Math.min(30, wallH*0.6);
 ctx.fillStyle='#100d08';
 ctx.fillRect(x+w/2-doorW/2, wallY+wallH-doorH, doorW, doorH);
 const cols = Math.max(2, Math.floor(w/60));
 for(let c=0;c<cols;c++){
  const wx = x+16+c*((w-32)/(cols-1||1));
  if(Math.abs(wx-(x+w/2))<doorW) continue;
  ctx.fillStyle='#0c1219'; ctx.fillRect(wx-6, wallY+10, 12, 12);
  ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(wx-6,wallY+10,12,12);
 }
 if(big){ ctx.fillStyle='#0c1219'; ctx.fillRect(x+w/2-6, wallY+wallH-doorH-24, 12,12); }
 labelTag(p);
}
function drawHall(p, wallColor, roofColor){
 const {x,y,w,h}=p;
 ctx.fillStyle = wallColor; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle = roofColor; ctx.fillRect(x-4,y-10,w+8,12);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.strokeRect(x-4,y-10,w+8,12);
 ctx.fillStyle='#0c0f0a'; ctx.fillRect(x+w/2-14,y+h-30,28,30);
 const cols = Math.max(2,Math.floor(w/70));
 for(let c=0;c<cols;c++){
  const wx = x+16+c*((w-32)/(cols-1||1));
  ctx.fillStyle='#0c1014'; ctx.fillRect(wx-8,y+12,16,16);
  ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(wx-8,y+12,16,16);
 }
 labelTag(p);
}
function drawTent(p){
 const {x,y,w,h}=p;
 ctx.fillStyle = p.fill||'#26271a';
 ctx.beginPath(); ctx.moveTo(x,y+h); ctx.lineTo(x+w/2,y); ctx.lineTo(x+w,y+h); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.lineWidth=1.5; ctx.stroke();
 ctx.beginPath(); ctx.moveTo(x+w/2,y); ctx.lineTo(x+w/2,y+h); ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.stroke();
 ctx.fillStyle='rgba(0,0,0,.5)';
 ctx.beginPath(); ctx.moveTo(x+w/2-8,y+h); ctx.lineTo(x+w/2,y+h-16); ctx.lineTo(x+w/2+8,y+h); ctx.closePath(); ctx.fill();
 labelTag(p);
}
function drawShelfBlock(p){
 const {x,y,w,h}=p;
 ctx.fillStyle = p.fill||'#171810'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 const rows = Math.max(2, Math.round(h/22));
 for(let r=1;r<rows;r++){
  const ry = y+(h/rows)*r;
  ctx.strokeStyle='rgba(0,0,0,.45)'; ctx.beginPath(); ctx.moveTo(x+3,ry); ctx.lineTo(x+w-3,ry); ctx.stroke();
 }
 for(let r=0;r<rows;r++){
  const ry = y+(h/rows)*r+4;
  const rowH = Math.max(6,(h/rows)-10);
  for(let c=0;c<Math.floor(w/26);c++){
   if((r+c)%3===0) continue;
   ctx.fillStyle = (r+c)%2===0?'rgba(232,178,61,.28)':'rgba(220,214,189,.18)';
   ctx.fillRect(x+6+c*26, ry, 14, rowH);
  }
 }
 labelTag(p);
}
function drawRubble(p){
 const {x,y,w,h}=p;
 const rnd = seededRand(Math.round(x*7+y*13)+1);
 ctx.fillStyle='rgba(0,0,0,.18)';
 ctx.beginPath(); ctx.ellipse(x+w/2,y+h+4,w*0.42,9,0,0,Math.PI*2); ctx.fill();
 const chunks = 5+Math.floor(rnd()*4);
 for(let i=0;i<chunks;i++){
  const cw=14+rnd()*(w*0.35), ch=10+rnd()*(h*0.3);
  const cx = x+rnd()*Math.max(1,w-cw), cy = y+rnd()*Math.max(1,h-ch);
  ctx.save(); ctx.translate(cx+cw/2,cy+ch/2); ctx.rotate((rnd()-0.5)*0.6);
  ctx.fillStyle='#141510'; ctx.fillRect(-cw/2,-ch/2,cw,ch);
  ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(-cw/2,-ch/2,cw,ch);
  ctx.restore();
 }
 labelTag(p);
}
function drawHeadstone(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#22241a';
 ctx.beginPath();
 ctx.moveTo(x,y+h); ctx.lineTo(x,y+h*0.35);
 ctx.arc(x+w/2,y+h*0.35,w/2,Math.PI,0);
 ctx.lineTo(x+w,y+h); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.moveTo(x+w/2,y+h*0.25); ctx.lineTo(x+w/2,y+h*0.7);
 ctx.moveTo(x+w*0.3,y+h*0.45); ctx.lineTo(x+w*0.7,y+h*0.45); ctx.stroke();
}
function drawBus(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#20261a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='rgba(0,0,0,.2)'; ctx.fillRect(x,y,w,6);
 ctx.fillStyle='#0c1014';
 for(let c=0;c<Math.floor(w/34);c++) ctx.fillRect(x+8+c*34,y+8,22,h*0.4);
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.arc(x+16,y+h,10,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(x+w-16,y+h,10,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawVault(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#221a12'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.4)'; ctx.lineWidth=2; ctx.strokeRect(x,y,w,h);
 const cx=x+w/2, cy=y+h/2, r=Math.min(w,h)/2-10;
 ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.strokeStyle='#8a6a24'; ctx.lineWidth=4; ctx.stroke();
 ctx.beginPath(); ctx.arc(cx,cy,r*0.4,0,Math.PI*2); ctx.fillStyle='#3a2c14'; ctx.fill(); ctx.stroke();
 for(let i=0;i<6;i++){
  const a=i*Math.PI/3;
  ctx.beginPath(); ctx.moveTo(cx+Math.cos(a)*r*0.4,cy+Math.sin(a)*r*0.4); ctx.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);
  ctx.strokeStyle='rgba(138,106,36,.6)'; ctx.lineWidth=2; ctx.stroke();
 }
 labelTag(p);
}
function drawCar(p){
 const {x,y,w,h}=p;
 if(p.variant==='truck'){
  ctx.fillStyle=p.fill||'#20261a';
  roundRect(x,y+h*0.3,w*0.6,h*0.5,4); ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
  ctx.fillStyle=shadeColor(p.fill||'#20261a',-16);
  roundRect(x+w*0.6,y+h*0.05,w*0.4,h*0.75,6); ctx.fill(); ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,.35)';
  roundRect(x+w*0.67,y+h*0.12,w*0.24,h*0.32,3); ctx.fill();
 } else if(p.variant==='van'){
  ctx.fillStyle=p.fill||'#2a3540';
  roundRect(x,y,w*0.92,h*0.75,5); ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,.3)';
  roundRect(x+w*0.06,y+h*0.08,w*0.22,h*0.3,3); ctx.fill();
  ctx.strokeStyle='rgba(232,178,61,.15)'; ctx.lineWidth=1;
  ctx.beginPath(); ctx.moveTo(x+w*0.34,y+4); ctx.lineTo(x+w*0.34,y+h*0.75-4); ctx.stroke();
 } else {
  ctx.fillStyle=p.fill||'#171d20';
  roundRect(x,y+h*0.25,w,h*0.6,6); ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,.35)';
  roundRect(x+w*0.2,y,w*0.6,h*0.4,4); ctx.fill();
 }
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.arc(x+w*0.22,y+h*0.85,9,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(x+w*0.78,y+h*0.85,9,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawFireHydrant(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#c94a2e';
 roundRect(x+w*0.2,y+h*0.2,w*0.6,h*0.7,4); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.stroke();
 ctx.fillStyle=shadeColor(p.fill||'#c94a2e',-15);
 ctx.beginPath(); ctx.arc(x+w/2,y+h*0.18,w*0.32,0,Math.PI*2); ctx.fill();
 ctx.fillStyle='#8a1a1a';
 ctx.fillRect(x,y+h*0.42,w*0.2,h*0.16);
 ctx.fillRect(x+w*0.8,y+h*0.42,w*0.2,h*0.16);
}
function drawTrafficCone(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#c1541c';
 ctx.beginPath(); ctx.moveTo(x+w/2,y); ctx.lineTo(x+w,y+h*0.85); ctx.lineTo(x,y+h*0.85); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.stroke();
 ctx.fillStyle='#dcd6bd';
 ctx.fillRect(x+w*0.18,y+h*0.5,w*0.64,h*0.14);
 ctx.fillStyle='#1a1a1a'; ctx.fillRect(x-3,y+h*0.85,w+6,h*0.12);
}
function drawBush(p){
 const {x,y,w,h}=p;
 const cx=x+w/2, cy=y+h/2;
 ctx.fillStyle=p.fill||'#2f4018';
 ctx.beginPath(); ctx.arc(cx,cy,w/2,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(cx-w*0.22,cy+h*0.1,w*0.36,0,Math.PI*2); ctx.fillStyle=shadeColor(p.fill||'#2f4018',10); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.25)'; ctx.beginPath(); ctx.arc(cx,cy,w/2,0,Math.PI*2); ctx.stroke();
}
function drawWreckedCar(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#141210';
 roundRect(x,y+h*0.25,w,h*0.6,6); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.stroke();
 ctx.fillStyle='rgba(20,15,10,.9)';
 roundRect(x+w*0.15,y-2,w*0.55,h*0.42,3); ctx.fill();
 ctx.strokeStyle='#c94a2e'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.moveTo(x+w*0.1,y+h*0.3); ctx.lineTo(x+w*0.5,y+h*0.65); ctx.moveTo(x+w*0.6,y+h*0.2); ctx.lineTo(x+w*0.3,y+h*0.7); ctx.stroke();
 ctx.fillStyle='rgba(40,40,35,.5)';
 for(let i=0;i<6;i++) ctx.fillRect(x+rand(0,w),y+rand(0,h*0.5),3,3);
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.ellipse(x+w*0.22,y+h*0.85,8,5,0,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.ellipse(x+w*0.78,y+h*0.85,7,4,0.3,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawCrashedHelicopter(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#1a1d16';
 roundRect(x+w*0.1,y+h*0.25,w*0.7,h*0.45,10); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.stroke();
 ctx.beginPath(); ctx.moveTo(x+w*0.75,y+h*0.4); ctx.lineTo(x+w,y+h*0.5); ctx.lineTo(x+w*0.75,y+h*0.58); ctx.closePath();
 ctx.fillStyle='#141712'; ctx.fill();
 ctx.strokeStyle='#c94a2e'; ctx.lineWidth=1.5;
 ctx.save(); ctx.translate(x+w*0.35,y+h*0.15); ctx.rotate(-0.35);
 ctx.beginPath(); ctx.moveTo(-w*0.42,0); ctx.lineTo(w*0.42,0); ctx.stroke();
 ctx.beginPath(); ctx.moveTo(0,-14); ctx.lineTo(0,14); ctx.stroke();
 ctx.restore();
 ctx.fillStyle='rgba(0,0,0,.35)';
 ctx.beginPath(); ctx.arc(x+w*0.25,y+h*0.4,10,0,Math.PI*2); ctx.fill();
 ctx.fillStyle='rgba(80,80,70,.4)';
 for(let i=0;i<8;i++) ctx.fillRect(x+rand(0,w),y+rand(h*0.5,h),4,4);
 labelTag(p);
}
function drawFence(p){
 const {x,y,w,h}=p;
 ctx.strokeStyle='#3a2010'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x,y+h/2); ctx.lineTo(x+w,y+h/2); ctx.stroke();
 const posts = Math.max(2, Math.floor(w/40));
 for(let i=0;i<=posts;i++){
  const px = x+(w/posts)*i;
  ctx.fillStyle='#2a1a0a'; ctx.fillRect(px-2,y,4,h);
 }
 ctx.strokeStyle='rgba(138,106,36,.4)'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.moveTo(x,y+h*0.25); ctx.lineTo(x+w,y+h*0.25); ctx.moveTo(x,y+h*0.75); ctx.lineTo(x+w,y+h*0.75); ctx.stroke();
}
/* Decorative perimeter barbwire — reads as "this line is sealed off" without
   needing a text label. Works along either a wide (horizontal run) or tall
   (vertical run) prop rectangle. */
function drawBarbwire(p){
 const {x,y,w,h}=p;
 const horizontal = w>=h;
 ctx.strokeStyle='#4a4a40'; ctx.lineWidth=2;
 if(horizontal){
  const midY = y+h/2;
  ctx.beginPath(); ctx.moveTo(x,midY); ctx.lineTo(x+w,midY); ctx.stroke();
  const posts = Math.max(2, Math.floor(w/60));
  ctx.fillStyle='#2e2e28';
  for(let i=0;i<=posts;i++){ const px = x+(w/posts)*i; ctx.fillRect(px-2,y,4,h); }
  ctx.strokeStyle='#8a8a78'; ctx.lineWidth=1;
  ctx.beginPath();
  for(let sx=x; sx<x+w; sx+=12){ ctx.moveTo(sx, midY-6); ctx.lineTo(sx+6, midY); ctx.lineTo(sx, midY+6); }
  ctx.stroke();
 } else {
  const midX = x+w/2;
  ctx.beginPath(); ctx.moveTo(midX,y); ctx.lineTo(midX,y+h); ctx.stroke();
  const posts = Math.max(2, Math.floor(h/60));
  ctx.fillStyle='#2e2e28';
  for(let i=0;i<=posts;i++){ const py = y+(h/posts)*i; ctx.fillRect(x,py-2,w,4); }
  ctx.strokeStyle='#8a8a78'; ctx.lineWidth=1;
  ctx.beginPath();
  for(let sy=y; sy<y+h; sy+=12){ ctx.moveTo(midX-6, sy); ctx.lineTo(midX, sy+6); ctx.lineTo(midX+6, sy); }
  ctx.stroke();
 }
}
function drawContainer(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#151d1f'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.lineWidth=1;
 for(let cx=x+8; cx<x+w-4; cx+=10){ ctx.beginPath(); ctx.moveTo(cx,y+4); ctx.lineTo(cx,y+h-4); ctx.stroke(); }
 ctx.strokeStyle='rgba(232,178,61,.35)'; ctx.lineWidth=2; ctx.strokeRect(x+w-26,y+4,20,h-8);
 labelTag(p);
}
function drawCrane(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#20201a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#2a2a1e';
 ctx.fillRect(x+w/2-6,y-140,12,140+h*0.2);
 ctx.fillRect(x+w/2-6,y-140,120,8);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x+w/2-6,y-140,120,8);
 labelTag(p);
}
function drawCart(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#1a1a1a'; ctx.fillRect(x,y,w,h*0.6);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.strokeRect(x,y,w,h*0.6);
 ctx.fillStyle='#0a0a0a';
 for(let i=0;i<4;i++){ ctx.beginPath(); ctx.arc(x+8+i*(w-16)/3, y+h*0.6+6,5,0,Math.PI*2); ctx.fill(); }
 labelTag(p);
}
function drawRunway(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#101210'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(220,214,189,.5)'; ctx.lineWidth=3;
 for(let ry=y+10; ry<y+h; ry+=36){ ctx.beginPath(); ctx.moveTo(x+w/2-4,ry); ctx.lineTo(x+w/2-4,ry+18); ctx.stroke(); }
 labelTag(p);
}
function drawFlagpole(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#3a3a2a'; ctx.fillRect(x,y,w,h);
 ctx.fillStyle='#8ab82f';
 ctx.beginPath(); ctx.moveTo(x+w,y+4); ctx.lineTo(x+w+30,y+14); ctx.lineTo(x+w,y+24); ctx.closePath(); ctx.fill();
}
function drawTable(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#1a1610';
 roundRect(x,y,w,h,4); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.stroke();
 ctx.fillStyle='#141210';
 ctx.fillRect(x-8,y+h/2-6,8,12); ctx.fillRect(x+w,y+h/2-6,8,12);
}
function drawBunker(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#14150f'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(85,107,47,.4)'; ctx.lineWidth=2; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#2a2818';
 for(let c=0;c<Math.floor(w/26);c++){ ctx.beginPath(); ctx.ellipse(x+13+c*26,y+h-6,12,7,0,0,Math.PI*2); ctx.fill(); }
 ctx.fillStyle='#0a0a08';
 for(let c=0;c<Math.floor(w/70);c++) ctx.fillRect(x+20+c*70,y+16,26,8);
 labelTag(p);
}
function drawLabDoor(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#241a0a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='#c94a2e'; ctx.lineWidth=2; ctx.setLineDash([6,4]); ctx.strokeRect(x+4,y+4,w-8,h-8); ctx.setLineDash([]);
}
function drawGasPump(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#2a2a1e'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#c94a2e'; ctx.fillRect(x+4,y+4,w-8,10);
 ctx.fillStyle='#0c0f0a'; ctx.fillRect(x+w*0.25,y+h*0.3,w*0.5,h*0.35);
 ctx.strokeStyle='#8a6a24'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x+w,y+h*0.4); ctx.lineTo(x+w+18,y+h*0.7); ctx.stroke();
 labelTag(p);
}
function drawChurch(p){
 const {x,y,w,h}=p;
 const wallH=h*0.68, roofH=h*0.32, wallY=y+h-wallH;
 ctx.fillStyle=p.fill||'#241a12'; ctx.fillRect(x,wallY,w,wallH);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.strokeRect(x,wallY,w,wallH);
 ctx.beginPath(); ctx.moveTo(x-6,wallY+4); ctx.lineTo(x+w/2,wallY-roofH); ctx.lineTo(x+w+6,wallY+4); ctx.closePath();
 ctx.fillStyle='#2e2015'; ctx.fill(); ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 const stX=x+w/2-16, stY=y-70, stW=32, stH=90;
 ctx.fillStyle='#2e2015'; ctx.fillRect(stX,stY,stW,stH);
 ctx.beginPath(); ctx.moveTo(stX-4,stY+4); ctx.lineTo(stX+stW/2,stY-40); ctx.lineTo(stX+stW+4,stY+4); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='#dcd6bd'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(stX+stW/2,stY-40); ctx.lineTo(stX+stW/2,stY-70); ctx.moveTo(stX+stW/2-10,stY-58); ctx.lineTo(stX+stW/2+10,stY-58); ctx.stroke();
 ctx.fillStyle='#100d08'; ctx.fillRect(x+w/2-16,wallY+wallH-40,32,40);
 ctx.fillStyle='#0c1219';
 ctx.beginPath(); ctx.arc(x+w/2,wallY+30,16,Math.PI,0); ctx.fill();
 labelTag(p);
}
function drawSilo(p){
 const {x,y,w,h}=p;
 const col = p.fill||'#8a8a7a';
 roundRect(x,y+10,w,h-10,w/2); ctx.fillStyle=col; ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.stroke();
 ctx.beginPath(); ctx.ellipse(x+w/2,y+10,w/2,10,0,0,Math.PI*2); ctx.fillStyle=shadeColor(col,20); ctx.fill(); ctx.stroke();
 ctx.strokeStyle='rgba(0,0,0,.25)'; ctx.lineWidth=1;
 for(let ry=y+30; ry<y+h; ry+=22){ ctx.beginPath(); ctx.moveTo(x+4,ry); ctx.lineTo(x+w-4,ry); ctx.stroke(); }
 labelTag(p);
}
function drawBarn(p){
 const {x,y,w,h}=p;
 const wallH=h*0.65, roofH=h*0.4, wallY=y+h-wallH;
 ctx.fillStyle=p.fill||'#5a1a10'; ctx.fillRect(x,wallY,w,wallH);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.strokeRect(x,wallY,w,wallH);
 ctx.beginPath();
 ctx.moveTo(x-8,wallY+6);
 ctx.lineTo(x+w*0.15,wallY-roofH*0.6);
 ctx.lineTo(x+w/2,wallY-roofH);
 ctx.lineTo(x+w*0.85,wallY-roofH*0.6);
 ctx.lineTo(x+w+8,wallY+6);
 ctx.closePath();
 ctx.fillStyle='#2e2015'; ctx.fill(); ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 ctx.fillStyle='#dcd6bd';
 ctx.fillRect(x+w/2-18,wallY+10,36,36);
 ctx.strokeStyle='#5a1a10'; ctx.lineWidth=2;
 ctx.beginPath(); ctx.moveTo(x+w/2-18,wallY+10); ctx.lineTo(x+w/2+18,wallY+46); ctx.moveTo(x+w/2+18,wallY+10); ctx.lineTo(x+w/2-18,wallY+46); ctx.stroke();
 ctx.fillStyle='#1a0a06'; ctx.fillRect(x+w/2-24,wallY+wallH-50,48,50);
 labelTag(p);
}
function drawTracks(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#1c1a14'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#3a2a1a';
 for(let cx=x+10; cx<x+w-10; cx+=26) ctx.fillRect(cx,y+4,8,h-8);
 ctx.strokeStyle='#8a8a7a'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x+6,y+h*0.3); ctx.lineTo(x+w-6,y+h*0.3); ctx.moveTo(x+6,y+h*0.7); ctx.lineTo(x+w-6,y+h*0.7); ctx.stroke();
}
function drawWatchtower(p){
 const {x,y,w,h}=p;
 ctx.strokeStyle='#2a2a1e'; ctx.lineWidth=4;
 ctx.beginPath();
 ctx.moveTo(x+6,y+h); ctx.lineTo(x+w*0.3,y+20);
 ctx.moveTo(x+w-6,y+h); ctx.lineTo(x+w*0.7,y+20);
 ctx.stroke();
 ctx.lineWidth=2; ctx.strokeStyle='rgba(232,178,61,.25)';
 for(let ry=y+h*0.3; ry<y+h; ry+=h*0.22){
  ctx.beginPath(); ctx.moveTo(x+8,ry); ctx.lineTo(x+w-8,ry-14); ctx.stroke();
 }
 ctx.fillStyle='#20201a'; ctx.fillRect(x-6,y,w+12,22);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x-6,y,w+12,22);
 ctx.beginPath(); ctx.moveTo(x-10,y); ctx.lineTo(x+w/2,y-26); ctx.lineTo(x+w+10,y); ctx.closePath();
 ctx.fillStyle='#2e2015'; ctx.fill();
 labelTag(p);
}
function drawAntenna(p){
 const {x,y,w,h}=p;
 const cx=x+w/2;
 ctx.strokeStyle='#3a3a2a'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(cx,y); ctx.lineTo(cx,y+h); ctx.stroke();
 ctx.lineWidth=1.5; ctx.strokeStyle='rgba(232,178,61,.3)';
 for(let ry=y+20; ry<y+h; ry+=36){
  ctx.beginPath(); ctx.moveTo(cx-16,ry+18); ctx.lineTo(cx,ry); ctx.lineTo(cx+16,ry+18); ctx.stroke();
 }
 ctx.beginPath(); ctx.arc(cx,y-6,5,0,Math.PI*2); ctx.fillStyle='#c94a2e'; ctx.fill();
 labelTag(p);
}
function drawBench(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#3a2a1a';
 ctx.fillRect(x,y,w,h*0.28);
 ctx.fillRect(x,y+h*0.5,w,h*0.28);
 ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(x,y,w,h*0.28); ctx.strokeRect(x,y+h*0.5,w,h*0.28);
 ctx.fillStyle='#1a1a1a';
 ctx.fillRect(x+4,y+h*0.78,5,h*0.22);
 ctx.fillRect(x+w-9,y+h*0.78,5,h*0.22);
}
function drawTree(p){
 const {x,y,w,h}=p;
 const cx=x+w/2;
 ctx.fillStyle='#2a1a10';
 ctx.fillRect(cx-w*0.08,y+h*0.55,w*0.16,h*0.45);
 ctx.fillStyle=p.fill||'#3a4a1a';
 ctx.beginPath(); ctx.arc(cx,y+h*0.4,w*0.5,0,Math.PI*2); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.stroke();
 ctx.beginPath(); ctx.arc(cx-w*0.2,y+h*0.25,w*0.32,0,Math.PI*2); ctx.fillStyle=shadeColor(p.fill||'#3a4a1a',10); ctx.fill();
}
function drawLamppost(p){
 const {x,y,w,h}=p;
 const cx=x+w/2;
 ctx.strokeStyle='#2a2a1e'; ctx.lineWidth=4;
 ctx.beginPath(); ctx.moveTo(cx,y+h); ctx.lineTo(cx,y+h*0.15); ctx.stroke();
 ctx.beginPath(); ctx.arc(cx,y+h*0.1,7,0,Math.PI*2); ctx.fillStyle='#e8b23d'; ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.35)'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.arc(cx,y+h*0.1,16,0,Math.PI*2); ctx.stroke();
}
function drawDumpster(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#2a4a1a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle=shadeColor(p.fill||'#2a4a1a',-15); ctx.fillRect(x-2,y-6,w+4,10);
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.lineWidth=1;
 for(let i=1;i<3;i++){ const lx=x+w*i/3; ctx.beginPath(); ctx.moveTo(lx,y+8); ctx.lineTo(lx,y+h-4); ctx.stroke(); }
 labelTag(p);
}
function drawMailbox(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#3a2a1a'; ctx.fillRect(x+w/2-2,y+h*0.3,4,h*0.7);
 ctx.fillStyle=p.fill||'#556b2f';
 roundRect(x,y,w,h*0.4,4); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.stroke();
}
function drawVendingMachine(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#8a1a2a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#0c1219'; ctx.fillRect(x+4,y+6,w-8,h*0.55);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.lineWidth=1;
 for(let i=1;i<3;i++){ const lx=x+4+(w-8)*i/3; ctx.beginPath(); ctx.moveTo(lx,y+6); ctx.lineTo(lx,y+6+h*0.55); ctx.stroke(); }
 ctx.fillStyle='#1a1a1a'; ctx.fillRect(x+4,y+h*0.68,w-8,h*0.24);
 labelTag(p);
}
function drawDoorMarker(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#100d08'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='#e8b23d'; ctx.lineWidth=2; ctx.setLineDash([6,4]); ctx.strokeRect(x-2,y-2,w+4,h+4); ctx.setLineDash([]);
 ctx.fillStyle='#e8b23d'; ctx.font='bold 9px monospace'; ctx.textAlign='center';
 ctx.fillText('EXIT', x+w/2, y-6);
 ctx.textAlign='left';
}
const GROUND_COLORS = {grass:'#182410', stone:'#201f1e', dirt:'#221c14'};
function drawGroundTexture(loc){
 const rnd = seededRand(loc.id.length*211 + loc.w*3 + loc.h);
 const biome = loc.ground;
 if(biome==='grass'){
  ctx.fillStyle='rgba(60,90,38,.4)';
  for(let i=0;i<110;i++){ ctx.fillRect(rnd()*loc.w, rnd()*loc.h, 3, 7); }
  ctx.fillStyle='rgba(16,28,12,.4)';
  for(let i=0;i<60;i++){ ctx.fillRect(rnd()*loc.w, rnd()*loc.h, 4, 4); }
 } else if(biome==='stone'){
  ctx.strokeStyle='rgba(0,0,0,.2)'; ctx.lineWidth=1;
  for(let x=0;x<loc.w;x+=72){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,loc.h); ctx.stroke(); }
  for(let y=0;y<loc.h;y+=72){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(loc.w,y); ctx.stroke(); }
  ctx.fillStyle='rgba(0,0,0,.12)';
  for(let i=0;i<40;i++){ ctx.fillRect(rnd()*loc.w, rnd()*loc.h, 10, 2); }
 } else if(biome==='dirt'){
  ctx.fillStyle='rgba(0,0,0,.18)';
  for(let i=0;i<55;i++){ const x=rnd()*loc.w, y=rnd()*loc.h; ctx.beginPath(); ctx.arc(x,y,rnd()*4+2,0,Math.PI*2); ctx.fill(); }
  ctx.fillStyle='rgba(120,100,70,.15)';
  for(let i=0;i<35;i++){ ctx.fillRect(rnd()*loc.w, rnd()*loc.h, 5, 3); }
 }
}
const FOUNDATION_LABELS = new Set(['House','Church','Main Building','Terminal','Camp Hall','Ward','Nurse Station','Kitchen','Bunker','Barn','Silo','Vault','Laboratory']);
function drawFoundationPads(){
 W.props.forEach(p=>{
  if(!FOUNDATION_LABELS.has(p.label)) return;
  const pad=16;
  ctx.fillStyle='rgba(58,56,50,.55)';
  ctx.fillRect(p.x-pad, p.y-pad*0.4, p.w+pad*2, p.h+pad*1.6);
  ctx.strokeStyle='rgba(0,0,0,.25)'; ctx.lineWidth=1;
  ctx.strokeRect(p.x-pad, p.y-pad*0.4, p.w+pad*2, p.h+pad*1.6);
 });
}
function drawBarrel(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#3a2a1a';
 roundRect(x,y+h*0.15,w,h*0.85,4); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.moveTo(x,y+h*0.4); ctx.lineTo(x+w,y+h*0.4); ctx.moveTo(x,y+h*0.7); ctx.lineTo(x+w,y+h*0.7); ctx.stroke();
 const flicker = 0.7+Math.sin(performance.now()/120 + x)*0.3;
 ctx.beginPath(); ctx.arc(x+w/2,y+h*0.15,10*flicker,0,Math.PI*2);
 ctx.fillStyle=`rgba(232,140,40,${0.7*flicker})`; ctx.fill();
 ctx.beginPath(); ctx.arc(x+w/2,y+h*0.1,5*flicker,0,Math.PI*2);
 ctx.fillStyle=`rgba(255,210,80,${0.8*flicker})`; ctx.fill();
}
function drawAmbulance(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#d8d8d0';
 roundRect(x,y+h*0.15,w,h*0.7,4); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.stroke();
 ctx.fillStyle='#c94a2e';
 ctx.fillRect(x+w*0.15,y+h*0.35,w*0.16,h*0.06);
 ctx.fillRect(x+w*0.20,y+h*0.28,w*0.06,h*0.2);
 ctx.fillStyle='rgba(0,0,0,.3)';
 roundRect(x+w*0.55,y+h*0.05,w*0.4,h*0.35,3); ctx.fill();
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.arc(x+w*0.22,y+h*0.9,9,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(x+w*0.78,y+h*0.9,9,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawPoliceCar(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#12151a';
 roundRect(x,y+h*0.25,w,h*0.6,6); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
 ctx.fillStyle='#dcd6bd';
 ctx.fillRect(x+w*0.1,y+h*0.42,w*0.8,h*0.16);
 ctx.fillStyle='rgba(0,0,0,.35)';
 roundRect(x+w*0.2,y,w*0.6,h*0.4,4); ctx.fill();
 ctx.fillStyle='#3fa0d8'; ctx.fillRect(x+w*0.35,y-8,w*0.12,8);
 ctx.fillStyle='#c94a2e'; ctx.fillRect(x+w*0.53,y-8,w*0.12,8);
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.arc(x+w*0.22,y+h*0.85,9,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(x+w*0.78,y+h*0.85,9,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawRedCross(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#f4f0e8';
 roundRect(x,y,w,h,4); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.stroke();
 ctx.fillStyle='#c94a2e';
 ctx.fillRect(x+w*0.38,y+h*0.12,w*0.24,h*0.76);
 ctx.fillRect(x+w*0.12,y+h*0.38,w*0.76,h*0.24);
}
function drawLaboratory(p){
 drawHall(p, p.fill||'#0f1c1c', '#1c2e2e');
}
function drawDollarSign(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#1c2a14';
 roundRect(x,y,w,h,4); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.4)'; ctx.lineWidth=2; ctx.stroke();
 ctx.fillStyle='#8ab82f'; ctx.font='bold 20px monospace'; ctx.textAlign='center';
 ctx.fillText('$', x+w/2, y+h*0.72);
 ctx.textAlign='left';
}
function drawCubicle(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#2a2a20';
 ctx.fillRect(x,y,w,4); ctx.fillRect(x,y,4,h); ctx.fillRect(x+w-4,y,4,h);
 ctx.fillStyle='#1a1610';
 ctx.fillRect(x+10,y+h-20,w-20,20);
 ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(x,y,w,h);
 labelTag(p);
}
function drawATM(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#1a1a1a';
 roundRect(x,y,w,h,4); ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
 ctx.fillStyle='#0c1219';
 ctx.fillRect(x+w*0.15,y+h*0.15,w*0.7,h*0.4);
 ctx.fillStyle='#3a3a2a';
 ctx.fillRect(x+w*0.25,y+h*0.62,w*0.5,h*0.12);
}
function drawChiefsOffice(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#1c1a14'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#1a1610'; ctx.fillRect(x+w*0.15,y+h*0.4,w*0.5,h*0.35);
}
function drawArmory(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#171810'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='#c94a2e'; ctx.lineWidth=2; ctx.strokeRect(x+3,y+3,w-6,h-6);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.lineWidth=2;
 for(let bx=x+10; bx<x+w-10; bx+=14){ ctx.beginPath(); ctx.moveTo(bx,y+4); ctx.lineTo(bx,y+h-4); ctx.stroke(); }
}
function drawJailCell(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#141210'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.strokeStyle='#2a2a24'; ctx.lineWidth=3;
 for(let bx=x+6; bx<x+w-4; bx+=10){ ctx.beginPath(); ctx.moveTo(bx,y+2); ctx.lineTo(bx,y+h-2); ctx.stroke(); }
}
function drawRoad(r){
 ctx.fillStyle='#1c1c1a'; ctx.fillRect(r.x,r.y,r.w,r.h);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.lineWidth=1; ctx.strokeRect(r.x,r.y,r.w,r.h);
 ctx.strokeStyle='rgba(220,214,189,.3)'; ctx.lineWidth=2; ctx.setLineDash([16,12]);
 ctx.beginPath();
 if(r.w>=r.h){ const cy=r.y+r.h/2; ctx.moveTo(r.x+6,cy); ctx.lineTo(r.x+r.w-6,cy); }
 else { const cx=r.x+r.w/2; ctx.moveTo(cx,r.y+6); ctx.lineTo(cx,r.y+r.h-6); }
 ctx.stroke(); ctx.setLineDash([]);
}
function render(){
 if(!document.getElementById('screen-game').classList.contains('active') || !W){ return; }
 ctx.clearRect(0,0,canvas.width,canvas.height);
 const camX = canvas.width/2 - W.player.x, camY = canvas.height/2 - W.player.y;
 ctx.save(); ctx.translate(camX,camY);

 // ground
 if(W.isInterior){
  ctx.fillStyle = '#181410'; ctx.fillRect(-40,-40,W.w+80,W.h+80);
 } else {
  const loc = findLocation(S.currentLocation);
  ctx.fillStyle = GROUND_COLORS[loc.ground] || '#0d0e09';
  ctx.fillRect(-40,-40,W.w+80,W.h+80);
  drawGroundTexture(loc);
 }
 ctx.strokeStyle='rgba(232,178,61,.15)'; ctx.lineWidth=2; ctx.strokeRect(0,0,W.w,W.h);

 // stone foundation pads under buildings, so structures look grounded even on grass/dirt
 if(!W.isInterior) drawFoundationPads();

 // roads (drawn first so buildings and props sit on top)
 if(W.roads) W.roads.forEach(r=> drawRoad(r));

 W.props.forEach(p=> drawStructure(p));

 W.crates.forEach(c=>{
  if(c.looted) return;
  ctx.font='22px sans-serif'; ctx.fillText(c.kind==='special'?'🗝️':(c.kind==='journal'?'📖':(c.kind==='keycard'?'🪪':'📦')), c.x-11, c.y+8);
 });

 W.npcs.forEach(n=>{
  drawNpcModel(n.x,n.y,15,n.color||'#8b8770');
  ctx.fillStyle='#dcd6bd'; ctx.font='9px monospace'; ctx.fillText(n.name||'', n.x-14,n.y-20);
 });

 if(W.guards) W.guards.forEach(g=>{
  drawGuardModel(g.x,g.y,14,g.color||'#8ab82f', ()=>{
   ctx.strokeStyle='#1a1a1a'; ctx.lineWidth=2.5; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(16,0); ctx.stroke();
  });
  ctx.fillStyle='#dcd6bd'; ctx.font='9px monospace'; ctx.fillText(g.name, g.x-12,g.y-20);
 });

 if(W.turrets) W.turrets.forEach(t=>{
  ctx.save(); ctx.translate(t.x,t.y);
  ctx.beginPath(); ctx.ellipse(0,10,20,8,0,0,Math.PI*2); ctx.fillStyle='rgba(0,0,0,.35)'; ctx.fill();
  ctx.fillStyle='#2a2a1e'; ctx.beginPath(); ctx.arc(0,0,16,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='#c94a2e'; ctx.lineWidth=2; ctx.stroke();
  let a = 0;
  const dp = dist(t.x,t.y,W.player.x,W.player.y);
  if(W.boss && dist(t.x,t.y,W.boss.x,W.boss.y) < dp) a = angleTo(t.x,t.y,W.boss.x,W.boss.y);
  else a = angleTo(t.x,t.y,W.player.x,W.player.y);
  ctx.rotate(a);
  ctx.fillStyle='#1a1a1a'; ctx.fillRect(0,-4,26,8);
  ctx.restore();
 });

 if(W.companionsEnt) W.companionsEnt.forEach(c=>{
  ctx.globalAlpha = c.recruited?1:0.55;
  drawCompanionModel(c.x,c.y,15,c.color, ()=>{
   const w = WEAPONS_RANGED[c.weapon];
   if(w){ const drew = drawHeldWeapon(w,0,22); if(!drew){ ctx.strokeStyle='#1a1a1a'; ctx.lineWidth=2.5; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(16,0); ctx.stroke(); } }
  });
  ctx.globalAlpha = 1;
  if(!c.recruited){ ctx.font='12px sans-serif'; ctx.fillText('🔒', c.x+6,c.y-10); }
  ctx.fillStyle= c.recruited?'#dcd6bd':'#8b8770'; ctx.font='9px monospace'; ctx.fillText(c.name, c.x-14,c.y-20);
 });

 W.zombies.forEach(z=>{
  const zv = ZOMBIE_VARIANTS[z.variant] || ZOMBIE_VARIANTS.walker;
  const isTank = zv.id==='tank';
  drawZombieModel(z.x,z.y,z.r,z.variant,z.charging);
  if(zv.ranged && !isTank && zv.weapon){
   const w = findWeaponById(zv.weapon);
   if(w){ ctx.font='12px sans-serif'; ctx.fillText(w.icon, z.x+z.r*0.4, z.y-z.r*0.6); }
  }
  if(isTank && zv.throws && z.throwCd<450){ ctx.font='16px sans-serif'; ctx.fillText('🪨', z.x+z.r*0.5, z.y-z.r*0.9); }
  drawHpBar(z.x,z.y-z.r-8,z.hp,z.maxHp);
 });
 W.bandits.forEach(b=>{
  const bv = BANDIT_VARIANTS[b.variant] || BANDIT_VARIANTS.grunt;
  const bw = findWeaponById(bv.weapon);
  drawBanditModel(b.x,b.y,b.r,b.variant, ()=>{
   const drew = bw ? drawHeldWeapon(bw,0,22) : false;
   if(!drew){
    if(bw){ ctx.font='13px sans-serif'; ctx.fillText(bw.icon, b.r*0.3, b.r*0.15); }
    else { ctx.strokeStyle='#1a1a1a'; ctx.lineWidth=2.5; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(16,0); ctx.stroke(); }
   }
  });
  drawHpBar(b.x,b.y-b.r-8,b.hp,b.maxHp);
 });
 if(W.boss){
  drawBossModel(W.boss.x,W.boss.y,W.boss.r);
 }

 // player
 drawSurvivorModel(W.player.x,W.player.y,16,S.color||'#e8b23d', S.facing, ()=>{
  const wid = S.weaponSlots[S.activeSlot];
  const w = wid?findWeaponById(wid):null;
  const cat = wid?weaponCategory(wid):null;
  if(cat){
   const a=facingAngle();
   const drew = w ? drawHeldWeapon(w,a,28) : false;
   if(!drew){ ctx.strokeStyle='#1a1a1a'; ctx.lineWidth=3; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(Math.cos(a)*20,Math.sin(a)*20); ctx.stroke(); }
  }
 });

 // melee swing fx
 W.meleeFx.forEach(f=>{
  const t = f.life/f.maxLife;
  ctx.save(); ctx.translate(W.player.x,W.player.y);
  ctx.beginPath(); ctx.moveTo(0,0);
  const half = f.arcDeg*Math.PI/180/2;
  ctx.arc(0,0,f.reach, f.angle-half, f.angle+half);
  ctx.closePath();
  ctx.fillStyle = `rgba(232,178,61,${0.35*t})`;
  ctx.fill();
  ctx.restore();
 });

 if(W.critFx) W.critFx.forEach(f=>{
  const t = f.life/f.maxLife;
  ctx.globalAlpha = t;
  ctx.fillStyle = '#e8b23d'; ctx.font='bold 14px monospace'; ctx.textAlign='center';
  ctx.fillText('CRIT!', f.x, f.y-20);
  ctx.textAlign='left'; ctx.globalAlpha = 1;
 });

 // projectiles
 W.projectiles.forEach(p=>{
  ctx.strokeStyle = p.owner==='player' ? '#e8b23d' : (p.owner==='companion' ? (p.color||'#3fa0d8') : '#c94a2e');
  ctx.lineWidth=3;
  ctx.beginPath(); ctx.moveTo(p.x,p.y); ctx.lineTo(p.x-p.vx*0.02,p.y-p.vy*0.02); ctx.stroke();
 });
 W.explosionFx.forEach(f=>{
  const t=f.life/f.maxLife;
  ctx.beginPath(); ctx.arc(f.x,f.y,f.radius*(1-t*0.3),0,Math.PI*2);
  ctx.fillStyle=`rgba(196,74,30,${0.4*t})`; ctx.fill();
 });

 ctx.restore();

 drawFog(camX,camY);

 // interact prompt
 const promptEl = document.getElementById('prompt');
 let near=null;
 if(W.crates.some(c=>!c.looted && dist(c.x,c.y,W.player.x,W.player.y)<46)) near='Press E to loot';
 if(!near && W.isInterior){
  if(W.doorMarker && dist(W.player.x, W.player.y, W.doorMarker.x+W.doorMarker.w/2, W.doorMarker.y+W.doorMarker.h/2) < 60) near='Press E to go outside';
 } else if(!near){
  for(const p of W.props){
   if(ENTERABLE_LABELS.has(p.label)){
    const dp = doorPointOf(p);
    if(dist(W.player.x, W.player.y, dp.x, dp.y) < 55){ near='Press E to go inside'; break; }
   }
  }
  if(!near){
   for(const p of W.props){
    if(p.label==='Vault'){
     const dp = doorPointOf(p);
     if(dist(W.player.x, W.player.y, dp.x, dp.y) < 55){ near = S.flags.vault_unlocked ? 'Press E to enter the vault' : 'Press E to try the vault door'; break; }
    }
    if(p.label==='L2 Vault'){
     const dp = doorPointOf(p);
     if(dist(W.player.x, W.player.y, dp.x, dp.y) < 55){ near = S.flags.ridge_l2_unlocked ? 'Press E to enter the vault' : 'Press E to try the vault door'; break; }
    }
    if(p.label==='Big Truck'){
     const cx=p.x+p.w/2, cy=p.y+p.h/2;
     if(dist(W.player.x, W.player.y, cx, cy) < 90){ near = S.flags.harrowed_reported ? 'Press E to leave Harrow County' : 'Press E to check the truck'; break; }
    }
   }
  }
 }
 if(!near && !W.isInterior && W.props.some(p=>p.vehicleLoot && !p.vehicleLoot.looted && dist(W.player.x,W.player.y,p.x+p.w/2,p.y+p.h/2)<55)) near='Press E to search vehicle';
 else if(!near && !W.isInterior && W.props.some(p=>p.uselessInteract && dist(W.player.x,W.player.y,p.x+p.w/2,p.y+p.h/2)<50)) near='Press E to interact';
 else if(!near && W.npcs.some(n=>dist(n.x,n.y,W.player.x,W.player.y)<50)) near='Press E to talk';
 else if(!near && W.companionsEnt && W.companionsEnt.some(c=>dist(c.x,c.y,W.player.x,W.player.y)<50)) near='Press E to talk';
 if(near){ promptEl.style.display='block'; promptEl.textContent=near; } else promptEl.style.display='none';
}
function drawHpBar(x,y,hp,maxHp){
 if(hp>=maxHp) return; // stay clean at full health, only show once they've been hit
 const w=30,h=4;
 ctx.fillStyle='rgba(0,0,0,.55)'; ctx.fillRect(x-w/2,y,w,h);
 const pct = Math.max(0,hp/maxHp);
 ctx.fillStyle = pct>0.5 ? '#8ab82f' : (pct>0.25 ? '#e8b23d' : '#c94a2e');
 ctx.fillRect(x-w/2,y,w*pct,h);
}
function darknessLevel(min){
 const dawnStart=300,dawnEnd=380,duskStart=1070,duskEnd=1180;
 if(min>=dawnEnd && min<=duskStart) return 0;
 if(min<dawnStart || min>duskEnd) return 0.80;
 if(min>=dawnStart && min<dawnEnd) return 0.80*(1-(min-dawnStart)/(dawnEnd-dawnStart));
 if(min>duskStart && min<=duskEnd) return 0.80*((min-duskStart)/(duskEnd-duskStart));
 return 0.3;
}
function drawFog(camX,camY){
 fogCtx.clearRect(0,0,fogCanvas.width,fogCanvas.height);
 if(W && W.isInterior) return;
 const dark = darknessLevel(S.gameMinutes);
 if(dark>0.01){
  fogCtx.fillStyle = `rgba(2,3,1,${dark})`;
  fogCtx.fillRect(0,0,fogCanvas.width,fogCanvas.height);
  if(S.flashlight){
   const px = W.player.x+camX, py = W.player.y+camY;
   const a = facingAngle();
   fogCtx.save();
   fogCtx.globalCompositeOperation='destination-out';
   const grad = fogCtx.createRadialGradient(px,py,10,px,py,260);
   grad.addColorStop(0,'rgba(255,255,255,1)');
   grad.addColorStop(1,'rgba(255,255,255,0)');
   fogCtx.fillStyle=grad;
   fogCtx.beginPath(); fogCtx.moveTo(px,py);
   fogCtx.arc(px,py,260, a-0.5, a+0.5);
   fogCtx.closePath(); fogCtx.fill();
   fogCtx.restore();
  }
 }
 ctx.drawImage(fogCanvas,0,0);
}

/* ================= MODALS: INVENTORY ================= */
let draggedItemId = null;
const WEAPON_SLOT_LABELS = {melee:'Melee', secondary:'Secondary', primary:'Primary', rocket:'Rocket', throwable:'Throwable'};
function canEquipToSlot(id, slotName){
 const cat = weaponCategory(id);
 if(!cat) return false;
 if(slotName==='melee') return cat==='melee';
 if(slotName==='throwable') return cat==='throwable';
 if(cat!=='ranged') return false;
 return WEAPONS_RANGED[id].slot===slotName;
}
/* Returns 'normal'|'ap' if dropping this ammo item onto this weapon slot is
   a valid variant-selection action (a matching ranged weapon must already
   be equipped there), otherwise null. Secondary = pistols, Primary = rifles
   — the weapon has to be equipped in its proper slot before its ammo
   variant can be switched, exactly like loading a real magazine. */
function ammoVariantForDrop(id, slotName){
 if(slotName!=='secondary' && slotName!=='primary') return null;
 if(!id.startsWith('ammo_')) return null;
 const wid = S.weaponSlots[slotName];
 if(!wid) return null;
 const w = WEAPONS_RANGED[wid];
 if(!w || !w.ammo) return null;
 if(id === 'ammo_'+w.ammo) return 'normal';
 const apKey = AP_AMMO_FOR[w.ammo];
 if(apKey && id === 'ammo_'+apKey) return 'ap';
 return null;
}
function renderInventoryModal(){
 const grid = document.getElementById('inv-grid'); grid.innerHTML='';
 if(S.inventory.length===0) grid.innerHTML = '<div class="inv-empty">Nothing here yet. Go loot something.</div>';
 S.inventory.forEach(it=>{
  const cell = document.createElement('div'); cell.className='inv-cell'; cell.draggable=true;
  cell.ondragstart=(e)=>{ draggedItemId=it.id; e.dataTransfer.setData('text/plain', it.id); };
  cell.ondragend=()=>{ draggedItemId=null; document.querySelectorAll('.eq-slot').forEach(s=>s.classList.remove('drag-over-ok','drag-over-bad')); };
  const icon = itemIcon(it.id,it.kind);
  cell.innerHTML = `<span class="qty">x${Math.round(it.qty*10)/10}</span><div class="ic">${icon}</div><div class="nm">${itemDisplayName(it.id)}</div>`;
  cell.onclick = ()=> useOrEquipItem(it);
  cell.oncontextmenu = (e)=>{ e.preventDefault(); showInvCtxMenu(e, it); };
  grid.appendChild(cell);
 });
 document.getElementById('carry-fill').style.width = clamp(carryWeight(S)/S.carryCap*100,0,100)+'%';
 document.getElementById('carry-txt').textContent = carryWeight(S)+' / '+S.carryCap;

 // paper doll — armor & backpack
 const armorSlot = document.getElementById('eq-armor-slot');
 const bpSlot = document.getElementById('eq-backpack-slot');
 armorSlot.innerHTML = S.equipped.armor ? `<div class="eq-item"><div class="ic">${ARMOR[S.equipped.armor].icon}</div><div class="nm">${ARMOR[S.equipped.armor].name}</div><div class="dur-track"><div class="dur-fill" style="width:${clamp(S.armorDurability/ARMOR[S.equipped.armor].durability*100,0,100)}%"></div></div></div>` : `<div class="eq-empty">Armor<br>slot</div>`;
 armorSlot.onclick = ()=> unequipArmor(S);
 armorSlot.ondragover = (e)=>{ e.preventDefault(); armorSlot.classList.toggle('drag-over-ok', !!ARMOR[draggedItemId]); armorSlot.classList.toggle('drag-over-bad', !!draggedItemId && !ARMOR[draggedItemId]); };
 armorSlot.ondragleave = ()=> armorSlot.classList.remove('drag-over-ok','drag-over-bad');
 armorSlot.ondrop = (e)=>{ e.preventDefault(); armorSlot.classList.remove('drag-over-ok','drag-over-bad'); const id=e.dataTransfer.getData('text/plain'); if(ARMOR[id]) equipArmor(S,id); else toast("That doesn't go in the armor slot.", 'bad'); };
 bpSlot.innerHTML = S.equipped.backpack ? `<div class="eq-item"><div class="ic">${BACKPACKS[S.equipped.backpack].icon}</div><div class="nm">${BACKPACKS[S.equipped.backpack].name}</div></div>` : `<div class="eq-empty">Backpack<br>slot</div>`;
 bpSlot.onclick = ()=> unequipBackpack(S);
 bpSlot.ondragover = (e)=>{ e.preventDefault(); bpSlot.classList.toggle('drag-over-ok', !!BACKPACKS[draggedItemId]); bpSlot.classList.toggle('drag-over-bad', !!draggedItemId && !BACKPACKS[draggedItemId]); };
 bpSlot.ondragleave = ()=> bpSlot.classList.remove('drag-over-ok','drag-over-bad');
 bpSlot.ondrop = (e)=>{ e.preventDefault(); bpSlot.classList.remove('drag-over-ok','drag-over-bad'); const id=e.dataTransfer.getData('text/plain'); if(BACKPACKS[id]) equipBackpack(S,id); else toast("That doesn't go in the backpack slot.", 'bad'); };

 // weapon slots — melee / secondary / primary / rocket / throwable
 ['melee','secondary','primary','rocket','throwable'].forEach(slotName=>{
  const el = document.getElementById('eq-'+slotName+'-slot');
  const wid = S.weaponSlots[slotName];
  const w = wid ? findWeaponById(wid) : null;
  el.innerHTML = w ? `<div class="eq-item"><div class="ic">${iconHtml(w.icon,w.img,18)}</div><div class="nm">${w.name}</div></div>` : `<div class="eq-empty">${WEAPON_SLOT_LABELS[slotName]}<br>slot</div>`;
  el.onclick = ()=>{
   if(slotName==='melee'){
    if(wid && wid!=='fists'){ addToInventory(S, wid, 'weapon_melee', 1); S.weaponSlots.melee='fists'; renderWeaponSlots(); renderInventoryModal(); toast('Put away.', 'amber'); }
   } else if(slotName==='throwable'){
    if(wid){ S.weaponSlots.throwable=null; renderWeaponSlots(); renderInventoryModal(); toast('Unequipped.', 'amber'); }
   } else {
    if(wid==='plasma_rifle'){ toast("The Plasma Rifle won't come off — it's welded into the mount.", 'bad'); return; }
    if(wid){ addToInventory(S, wid, 'weapon_ranged', 1); S.weaponSlots[slotName]=null; S.ammoVariant=S.ammoVariant||{}; S.ammoVariant[slotName]='normal'; renderWeaponSlots(); renderInventoryModal(); toast('Unequipped.', 'amber'); }
   }
  };
  el.ondragover = (e)=>{
   e.preventDefault();
   const weaponOk = !!draggedItemId && canEquipToSlot(draggedItemId, slotName);
   const ammoVariant = draggedItemId ? ammoVariantForDrop(draggedItemId, slotName) : null;
   const ok = weaponOk || !!ammoVariant;
   el.classList.toggle('drag-over-ok', ok);
   el.classList.toggle('drag-over-bad', !!draggedItemId && !ok);
  };
  el.ondragleave = ()=> el.classList.remove('drag-over-ok','drag-over-bad');
  el.ondrop = (e)=>{
   e.preventDefault();
   el.classList.remove('drag-over-ok','drag-over-bad');
   const id = e.dataTransfer.getData('text/plain');
   if(!id) return;
   const ammoVariant = ammoVariantForDrop(id, slotName);
   if(ammoVariant){
    S.ammoVariant = S.ammoVariant || {};
    if(S.ammoVariant[slotName]===ammoVariant){ toast((ammoVariant==='ap'?'AP rounds':'Standard rounds')+' already selected.', 'amber'); return; }
    S.ammoVariant[slotName] = ammoVariant;
    toast((ammoVariant==='ap'?'AP rounds':'Standard rounds')+' selected — reload to chamber them.', 'amber');
    renderAmmoHud();
    return;
   }
   if(!canEquipToSlot(id, slotName)){ toast("That doesn't go in the "+WEAPON_SLOT_LABELS[slotName]+' slot.', 'bad'); return; }
   if(slotName==='throwable'){ S.weaponSlots.throwable = id; renderWeaponSlots(); renderInventoryModal(); }
   else equipWeaponFromInventory(S, id);
  };
 });
}
function iconHtml(icon, img, sizePx){
 sizePx = sizePx||20;
 if(img) return `<img src="${img}" class="icon-img" style="width:${sizePx}px;height:${sizePx}px" alt="">`;
 return `<span class="icon-emoji">${icon||'❔'}</span>`;
}
function itemIcon(id,kind){
 if(id==='gold_bars') return iconHtml('🥇');
 const card = findKeycardById(id); if(card) return iconHtml(card.icon);
 const c = findConsumableById(id); if(c) return iconHtml(c.icon);
 if(id.startsWith('ammo_')) return iconHtml(AMMO_TYPES[id.replace('ammo_','')].icon);
 if(ARMOR[id]) return iconHtml(ARMOR[id].icon);
 if(BACKPACKS[id]) return iconHtml(BACKPACKS[id].icon);
 const w = findWeaponById(id); if(w) return iconHtml(w.icon, w.img);
 return iconHtml('❔');
}
function useOrEquipItem(it){
 if(ARMOR[it.id]){ equipArmor(S,it.id); return; }
 if(BACKPACKS[it.id]){ equipBackpack(S,it.id); return; }
 if(it.kind==='weapon_melee' || it.kind==='weapon_ranged' || it.kind==='weapon_throwable'){
  toast('Drag it to its weapon slot to equip it.', 'bad');
  return;
 }
 const c = findConsumableById(it.id);
 if(c){
  useConsumable(it.id, c);
  renderInventoryModal();
 }
}
function useConsumable(id, c){
 let restoreMult = S.skills.fast_metabolism ? 1.2 : 1;
 if(c.hunger) S.hunger = Math.min(100, S.hunger + c.hunger*restoreMult);
 if(c.thirst) S.thirst = Math.min(100, S.thirst + c.thirst*restoreMult);
 if(c.heal){ let h=c.heal*(S.skills.field_medic?1.2:1); S.hp = Math.min(S.maxHp, S.hp+h); }
 if(c.cure) cureStatus(c.cure);
 if(c.buff){ S.buffs.push({stat:c.buff.stat, mult:c.buff.mult, add:c.buff.add, expiresAt:performance.now()+c.buff.ms}); }
 removeFromInventory(S, id, 1);
 toast('Used '+c.name+'.', 'amber');
 updateHudDynamic();
}
function autoUseBest(){
 if(S.hp<S.maxHp*0.5){
  const heals = ['serum','medkit','antibiotics','bandage'].map(id=>({id,c:MEDS[id]})).filter(x=>findInv(S,x.id));
  if(heals.length){ useConsumable(heals[0].id, heals[0].c); renderInventoryModal(); return; }
 }
 if(S.hunger<30){ const f=Object.keys(FOODS).map(id=>({id,c:FOODS[id]})).find(x=>findInv(S,x.id)); if(f){useConsumable(f.id,f.c);renderInventoryModal();return;} }
 if(S.thirst<30){ const d=Object.keys(DRINKS).map(id=>({id,c:DRINKS[id]})).find(x=>findInv(S,x.id)); if(d){useConsumable(d.id,d.c);renderInventoryModal();return;} }
 toast('Nothing useful to use right now.', 'bad');
}

/* ================= MODALS: MAP / QUESTS / SKILLS / ACH / TRADE ================= */
function renderMapModal(){
 const grid = document.getElementById('map-grid'); grid.innerHTML='';
 LOCATIONS.forEach(loc=>{
  if(loc.locked==='both_choices' && !(S.flags.hospital_choice_done && S.flags.warehouse_choice_done)) return;
  const div = document.createElement('div'); div.className='maploc'+(S.currentLocation===loc.id?' cur':'');
  div.innerHTML = `<div class="nm">${loc.name}</div><div class="dg">DANGER: ${loc.danger}</div><div class="visited">${loc.id==='camp'?'NO LOOT · DEFEND':(loc.noLoot?'SAFE ZONE · TRADE':'Tap to travel')}</div>`;
  div.onclick = ()=>{ if(S.currentLocation!==loc.id){ enterLocation(loc.id); Game.closeModal(); } };
  grid.appendChild(div);
 });
}
let questTabState='main';
function renderQuestsModal(){
 document.querySelectorAll('#modal-quests .tab').forEach(t=>t.classList.toggle('active', t.dataset.qt===questTabState));
 const body = document.getElementById('quest-body'); body.innerHTML='';
 const src = questTabState==='main'?MAIN_QUESTS:SIDE_QUESTS;
 const state = questTabState==='main'?S.questsMain:S.questsSide;
 Object.keys(src).forEach(id=>{
  const q = src[id]; const st = state[id];
  if(st.status==='locked') return;
  const row = document.createElement('div'); row.className='qrow'+(questTabState==='side'?' side':'')+(st.status==='done'?' done':'');
  let objText = (q.type==='loot' || q.type==='kill_at_camp' || q.type==='loot_at' || q.type==='journal_count' || q.type==='kill_bandits' || q.type==='kill_total' || q.type==='community_aid') ? `${Math.min(st.progress,q.target)}/${q.target}` : (st.status==='done'?'Complete':'In progress');
  row.innerHTML = `<div class="qt">${q.title}</div><div class="qd">${q.desc}</div><div class="qobj">${objText}</div>`;
  body.appendChild(row);
 });
}
let skillTabState='survivor';
function renderSkillsModal(){
 document.getElementById('skillpoints').textContent = S.skillPoints;
 const tabs = document.getElementById('stree-tabs'); tabs.innerHTML='';
 Object.keys(SKILL_TREE).forEach(branch=>{
  const t = document.createElement('div'); t.className='stree-branch tab'+(skillTabState===branch?' active':'');
  t.textContent = branch; t.onclick=()=>{ skillTabState=branch; renderSkillsModal(); };
  tabs.appendChild(t);
 });
 const body = document.getElementById('stree-body'); body.innerHTML='';
 SKILL_TREE[skillTabState].forEach(node=>{
  const owned = !!S.skills[node.id];
  const lockedReq = node.req && !S.skills[node.req];
  const div = document.createElement('div'); div.className='snode'+(owned?' owned':'');
  div.innerHTML = `<div class="n"><b>${node.name}</b> (${node.cost}pt)<div class="d">${node.desc}${lockedReq?' — requires '+SKILL_TREE[skillTabState].find(n=>n.id===node.req).name:''}</div></div>`;
  const btn = document.createElement('button');
  btn.textContent = owned?'Owned':'Unlock';
  btn.disabled = owned || lockedReq || S.skillPoints<node.cost;
  btn.onclick = ()=>unlockSkill(node.id);
  div.appendChild(btn);
  body.appendChild(div);
 });
}
let achTabState='ach';
function renderAchModal(){
 document.querySelectorAll('#modal-achievements .tab').forEach(t=>t.classList.toggle('active', t.dataset.at===achTabState));
 const body = document.getElementById('ach-body'); body.innerHTML='';
 if(achTabState==='ach'){
  const g = document.createElement('div'); g.className='ach-grid';
  ACHIEVEMENTS.forEach(a=>{
   const got = S.achievements[a.id];
   const d = document.createElement('div'); d.className='ach'+(got?' got':'');
   d.innerHTML = `<div class="ic">${got?a.icon:'🔒'}</div><div><div class="nm">${a.name}</div><div class="ds">${got?a.desc:'???'}</div>${got?'<div class="bn">Unlocked</div>':''}</div>`;
   g.appendChild(d);
  });
  body.appendChild(g);
 } else if(achTabState==='journal'){
  const pages = JOURNAL_PAGES.filter(j=>S.journalPages[j.id]);
  if(pages.length===0){
   body.innerHTML = '<div class="inv-empty">No journal pages found yet. Look for a 📖 icon while exploring.</div>';
  } else {
   const list = document.createElement('div'); list.className='journal-list';
   pages.forEach(p=>{
    const loc = findLocation(p.loc);
    const d = document.createElement('details'); d.className='journal-entry';
    d.innerHTML = `<summary>📖 <span class="jtitle">${p.title}</span><span class="jloc">${loc?loc.name:''}</span></summary><p>${p.text}</p>`;
    list.appendChild(d);
   });
   body.appendChild(list);
   const remaining = JOURNAL_PAGES.length - pages.length;
   const foot = document.createElement('div'); foot.className='inv-empty';
   foot.textContent = remaining>0 ? (pages.length+' / '+JOURNAL_PAGES.length+' pages found — '+remaining+' still out there.') : 'All '+JOURNAL_PAGES.length+' pages recovered.';
   body.appendChild(foot);
  }
 } else {
  renderTrophiesModal(body);
 }
}
function renderTradeModal(){
 document.getElementById('trade-tokens').textContent = S.tokens;
 const buy = document.getElementById('trade-buy'); buy.innerHTML='';
 const sell = document.getElementById('trade-sell'); sell.innerHTML='';
 const ctx = S.tradeContext || 'camp';
 const titleEl = document.getElementById('trade-title');
 if(titleEl) titleEl.textContent = ctx==='blockade' ? 'Blockade Armory' : (ctx==='doctor' ? "Dr. Voss's Medicine" : "Joe's Stock");
 const ammoList = [
  {id:'ammo_mm9',   name:AMMO_TYPES.mm9.name,   icon:AMMO_TYPES.mm9.icon,   price:1, isAmmo:true, kind:'ammo'},
  {id:'ammo_magnum',name:AMMO_TYPES.magnum.name,icon:AMMO_TYPES.magnum.icon,price:3, isAmmo:true, kind:'ammo'},
  {id:'ammo_rifle', name:AMMO_TYPES.rifle.name, icon:AMMO_TYPES.rifle.icon, price:1, isAmmo:true, kind:'ammo'},
  {id:'ammo_shells',name:AMMO_TYPES.shells.name,icon:AMMO_TYPES.shells.icon,price:2, isAmmo:true, kind:'ammo'},
  {id:'ammo_rocket',name:AMMO_TYPES.rocket.name,icon:AMMO_TYPES.rocket.icon,price:8, isAmmo:true, kind:'ammo'}
 ];
 let buyList;
 if(ctx==='blockade'){
  // Guns and ammo only — including the Blockade-exclusive hardware, but
  // never the Plasma Rifle: that's a one-time Harrowed-loot reward, not
  // something anyone should be able to just buy.
  buyList = [
   ...Object.values(WEAPONS_RANGED).filter(w=>!w.reward),
   ...ammoList,
   ...Object.values(BUFF_ITEMS)
  ];
 } else if(ctx==='doctor'){
  // Medicine only, at a markup over Joe's prices — she's the specialist
  buyList = Object.values(MEDS).filter(m=>!m.rare).map(m=>({...m, price:Math.max(m.price+1, Math.round(m.price*1.6))}));
 } else {
  buyList = [
   ...Object.values(WEAPONS_MELEE).filter(w=>w.price>0),
   ...Object.values(WEAPONS_RANGED).filter(w=>w.exclusive!=='blockade' && !w.reward),
   ...Object.values(WEAPONS_THROWABLE),
   ...Object.values(ARMOR), ...Object.values(BACKPACKS).filter(b=>!b.reward),
   ...Object.values(DRINKS), ...Object.values(FOODS), ...Object.values(MEDS).filter(m=>!m.rare),
   ...ammoList
  ];
 }
 buyList.forEach(item=>{
  const row = document.createElement('div'); row.className='trow';
  row.innerHTML = `<span>${iconHtml(item.icon, item.img)} ${item.name}</span><span class="price">${item.price}t</span>`;
  const btn = document.createElement('button'); btn.textContent='Buy';
  btn.onclick = ()=>{
   if(S.tokens<item.price){ toast('Not enough tokens.', 'bad'); return; }
   const kind = item.isAmmo?'ammo': (ARMOR[item.id]?'armor':(BACKPACKS[item.id]?'backpack':(WEAPONS_MELEE[item.id]?'weapon_melee':(WEAPONS_RANGED[item.id]?'weapon_ranged':(WEAPONS_THROWABLE[item.id]?'weapon_throwable':consumableKind(item.id))))));
   const qty = item.isAmmo?10:1;
   let ok;
   if(kind==='weapon_melee'||kind==='weapon_ranged'||kind==='weapon_throwable'){ giveWeaponItem(S,item.id); ok=true; }
   else ok = addToInventory(S,item.id,kind,qty);
   if(ok){ S.tokens-=item.price; toast('Bought '+item.name+'.', 'amber'); renderTradeModal(); renderInventoryModal(); renderWeaponSlots(); checkAchievements(); }
  };
  row.appendChild(btn); buy.appendChild(row);
 });
 S.inventory.forEach(it=>{
  if(it.kind==='quest') return;
  const val = itemSellValue(it.id, it.kind);
  const row = document.createElement('div'); row.className='trow';
  row.innerHTML = `<span>${itemIcon(it.id,it.kind)} ${itemDisplayName(it.id)} ×${Math.round(it.qty)}</span><span class="price">${val}t</span>`;
  const actions = document.createElement('div'); actions.className='trow-actions';
  const btn = document.createElement('button'); btn.textContent='Sell';
  btn.onclick = ()=>{ removeFromInventory(S,it.id,1); S.tokens+=val; toast('Sold '+itemDisplayName(it.id)+'.', 'amber'); renderTradeModal(); renderInventoryModal(); };
  actions.appendChild(btn);
  if(Math.round(it.qty)>1){
   const allBtn = document.createElement('button'); allBtn.textContent='Sell All';
   allBtn.onclick = ()=>{
    const qty = Math.round(it.qty);
    const total = val*qty;
    removeFromInventory(S,it.id,qty);
    S.tokens += total;
    toast('Sold '+qty+'x '+itemDisplayName(it.id)+' for '+total+'t.', 'amber');
    renderTradeModal(); renderInventoryModal();
   };
   actions.appendChild(allBtn);
  }
  row.appendChild(actions); sell.appendChild(row);
 });
}
function itemBasePrice(id, kind){
 if(kind==='weapon_melee' || kind==='weapon_ranged' || kind==='weapon_throwable'){
  const w = findWeaponById(id); return w ? w.price : 0;
 }
 if(kind==='armor'){ return ARMOR[id] ? ARMOR[id].price : 0; }
 if(kind==='backpack'){ return BACKPACKS[id] ? BACKPACKS[id].price : 0; }
 if(kind==='ammo'){
  const t = id.replace('ammo_','');
  return {mm9:1, magnum:3, rifle:1, shells:2, rocket:8}[t] || 1;
 }
 const cons = findConsumableById(id);
 if(cons) return cons.price!==undefined ? cons.price : 3;
 return 2;
}
function itemSellValue(id, kind){
 return Math.max(1, Math.round(itemBasePrice(id,kind) * 0.45));
}

/* ================= TOAST ================= */
function toast(msg, kind){
 const stack = document.getElementById('toasts'); if(!stack) return;
 const t = document.createElement('div'); t.className='toast'+(kind?' '+kind:'');
 t.textContent = msg; stack.appendChild(t);
 setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),300); }, 2600);
}

/* ================= LOOP ================= */
function loop(t){
 if(!lastT) lastT=t;
 const dt = Math.min(50, t-lastT); lastT=t;
 if(S && !document.getElementById('screen-ending').classList.contains('active') &&
    document.getElementById('screen-game').classList.contains('active') &&
    !document.getElementById('modal-bg').classList.contains('open') && !dialogueOpen() && W){
  update(dt);
 }
 render();
 RAF = requestAnimationFrame(loop);
}
function dialogueOpen(){ return document.getElementById('dialogue').style.display==='block'; }

/* ================= INPUT ================= */
const KONAMI = ['arrowup','arrowup','arrowdown','arrowdown','arrowleft','arrowright','arrowleft','arrowright','b','a'];
let konamiBuf = [];
window.addEventListener('keydown', (e)=>{
 const k = e.key.toLowerCase();
 KEYS[k]=true;
 konamiBuf.push(k); konamiBuf = konamiBuf.slice(-10);
 if(konamiBuf.join(',')===KONAMI.join(',') && S && !S.konami){
  S.konami=true; addToInventory(S,'pillow','weapon_melee',1);
  toast('??? A pillow appears in your inventory.', 'amber'); checkAchievements(); unlockAchievement('old_habits');
 }
 if(!document.getElementById('screen-game').classList.contains('active')) return;
 if(dialogueOpen() || document.getElementById('modal-bg').classList.contains('open')){
  if(k==='escape'){ if(document.getElementById('modal-bg').classList.contains('open')) Game.closeModal(); }
  return;
 }
 if(k==='e') interact();
 if(k===' '){ e.preventDefault(); const cat = weaponCategory(S.weaponSlots[S.activeSlot]); if(cat==='melee') playerMelee(); else if(cat==='ranged') playerRanged(); else if(cat==='throwable') throwActive(); }
 if(k==='r') reloadActive();
 if(k==='f'){ S.flashlight=!S.flashlight; }
 if(k==='k') autoUseBest();
 if(['1','2','3','4','5'].includes(k)){ const map={1:'melee',2:'secondary',3:'primary',4:'rocket',5:'throwable'}; S.activeSlot=map[k]; renderWeaponSlots(); }
 if(k==='i') Game.toggleModal('inventory');
 if(k==='m') Game.toggleModal('map');
 if(k==='o') Game.toggleQuestsTab('main');
 if(k==='q') Game.toggleQuestsTab('side');
 if(k==='p') Game.toggleAchTab('ach');
 if(k==='j') Game.toggleAchTab('journal');
 if(k==='t') Game.toggleAchTab('trophies');
 if(k==='l') Game.toggleModal('skills');
 if(k==='escape') Game.toggleModal('pause');
});
window.addEventListener('keyup', (e)=>{ KEYS[e.key.toLowerCase()]=false; });

/* ================= UI RENDERERS: character/companion select ================= */
function renderRoster(){
 const roster = document.getElementById('roster'); roster.innerHTML='';
 SURVIVORS.forEach(sv=>{
  const card = document.createElement('div'); card.className='card'+(selectedSurvivor===sv.id?' picked':'');
  card.innerHTML = `<div class="avatar" style="background:${sv.color}">${buildFaceSVG(sv)}<span class="glyph">${classIcon(sv.role)}</span></div>
   <div class="card-name">${sv.name}</div><div class="card-role">${sv.role}</div>
   <div class="card-stats">END ${sv.END} · AGI ${sv.AGI} · STR ${sv.STR}<br>PER ${sv.PER} · STA ${sv.STA}</div>`;
  card.onclick = ()=>{ selectedSurvivor=sv.id; renderRoster(); renderCharDetail(sv); document.getElementById('btn-char-confirm').disabled=false; };
  roster.appendChild(card);
 });
}
function classIcon(role){
 return {Doctor:'⚕️',Engineer:'🔧',Teen:'🎧',Lumberjack:'🪓',Army:'🎖️',Police:'👮',Firefighter:'🚒',Citizen:'🙂',Builder:'👷',Hacker:'💻'}[role]||'❔';
}
function buildFaceSVG(sv){
 return `<svg width="40" height="40" viewBox="0 0 40 40" style="position:absolute">
  <circle cx="20" cy="18" r="12" fill="${sv.skin}"/>
  <path d="M8 14 Q20 2 32 14 L32 10 Q20 6 8 10 Z" fill="${sv.hair}"/>
  <circle cx="15" cy="18" r="1.6" fill="#1a1a1a"/><circle cx="25" cy="18" r="1.6" fill="#1a1a1a"/>
  <path d="M14 24 Q20 28 26 24" stroke="#1a1a1a" stroke-width="1.4" fill="none"/>
 </svg>`;
}
function renderCharDetail(sv){
 const d = document.getElementById('char-detail');
 const startW = findWeaponById(sv.startWeapon);
 d.innerHTML = `<div class="detail-name">${sv.name}</div><div class="detail-role">${sv.role}</div>
  <div class="detail-perk">${sv.perk}</div>
  ${statBars(sv)}
  <div style="margin-top:14px;font-size:12px;color:var(--bone-dim)">Starts equipped with: ${startW?startW.name:'Fists'}</div>`;
}
function statBars(sv){
 return ['END','AGI','STR','PER','STA'].map(k=>`
  <div class="statbar-row"><span>${k}</span><div class="statbar-track"><div class="statbar-fill" style="width:${sv[k]*10}%"></div></div><span>${sv[k]}</span></div>
 `).join('');
}

/* ================= SAVE / CONTINUE =================
   Saved to localStorage on the player's own machine — this is a real standalone
   game file running from disk in the player's own browser, not a sandboxed
   artifact, so localStorage is the right tool here. Only ever saved while the
   survivor is alive; dying does not write a save. */
const SAVE_KEY = 'dh_revelation_save_v1';
function saveGame(){
 try{
  const copy = JSON.parse(JSON.stringify(S));
  copy.reloadingSlot = null;   // a pending reload's setTimeout can't survive a reload
  copy.buffs = [];             // buff expiry timestamps are meaningless across sessions
  localStorage.setItem(SAVE_KEY, JSON.stringify(copy));
  return true;
 } catch(e){ console.error('Save failed', e); return false; }
}
function loadGame(){
 try{
  const raw = localStorage.getItem(SAVE_KEY);
  if(!raw) return null;
  return JSON.parse(raw);
 } catch(e){ console.error('Load failed', e); return null; }
}
function hasSave(){ try{ return !!localStorage.getItem(SAVE_KEY); } catch(e){ return false; } }
function updateContinueButton(){
 const btn = document.getElementById('btn-continue');
 if(btn) btn.disabled = !hasSave();
}

/* ================= INTRO CUTSCENE ================= */
/* ~30 seconds of scene-setting lore (RVL-9's origin) shown once before a new
   run starts. Purely presentational — doesn't touch S/W or any save data. */
const INTRO_LINES = [
 "Three years ago, Revelation Biotech announced RVL-9 — a compound that could regenerate dead and dying tissue on command.",
 "They called it the cure for everything. Burn victims. Organ failure. Old age itself.",
 "They never mentioned what regeneration looks like in tissue that has no reason left to stop.",
 "Buried under the Ridge Facility, containment held for exactly as long as the funding did.",
 "Three days before anyone official said a word, RVL-9 stopped being contained.",
 "Now Harrow County belongs to whatever it leaves standing — and you don't remember how you survived the first night."
];
const INTRO_LINE_MS = 4600;
let introTimer = null, introIndex = 0, introSkipped = false;
function playIntroLine(){
 if(introSkipped) return;
 const el = document.getElementById('intro-line');
 const fill = document.getElementById('intro-progress-fill');
 if(introIndex >= INTRO_LINES.length){ Game.startGame(); return; }
 el.classList.remove('show');
 introTimer = setTimeout(()=>{
  if(introSkipped) return;
  el.textContent = INTRO_LINES[introIndex];
  el.classList.add('show');
  fill.style.width = Math.round(((introIndex+1)/INTRO_LINES.length)*100)+'%';
  introIndex++;
  introTimer = setTimeout(playIntroLine, INTRO_LINE_MS);
 }, introIndex===0 ? 200 : 700);
}

/* ================= OUTRO CUTSCENE (escaping Harrow County) ================= */
/* Reuses the same #screen-intro shell as the opening cutscene — they never
   run in the same session at the same time — so the escape gets its own
   short, choice-flavored send-off instead of jumping straight to the static
   end screen. Triggered by tryBoardTruck() once the escape is unlocked. */
const ENDING_LINES = {
 good: [
  "The Level 2 keycard still smells like burnt plastic when you hand it to Elias.",
  "\"It's done,\" you tell him. \"The Harrowed's dead. The samples are ash.\"",
  "He doesn't smile, exactly. But something in his shoulders finally lets go.",
  "The truck's engine turns over on the third try. Nobody complains about the noise.",
  "Harrow County shrinks in the mirror, and for once, nothing follows."
 ],
 bad: [
  "The Level 2 keycard still smells like burnt plastic when you hand it to Elias.",
  "\"It's done,\" you tell him. \"The Harrowed's dead.\" You don't mention the case in the truck bed.",
  "He doesn't ask where the samples went. Maybe he already knows better than to.",
  "The truck's engine turns over on the third try. Someone's waiting on the other end of a call you already made.",
  "Harrow County shrinks in the mirror — paid for, if not forgiven."
 ],
 neutral: [
  "The Level 2 keycard still smells like burnt plastic when you hand it to Elias.",
  "\"It's done,\" you tell him. \"The lab's sealed. Whatever's left down there is staying down there.\"",
  "He nods slowly, like a man deciding not to ask the follow-up question.",
  "The truck's engine turns over on the third try. Nobody's celebrating, but nobody's running either.",
  "Harrow County shrinks in the mirror, quiet in a way it hasn't been in months."
 ]
};
const ENDING_LINE_MS = 4600;
let outroTimer = null, outroIndex = 0, outroSkipped = false;
function playOutroLine(){
 if(outroSkipped) return;
 const lines = ENDING_LINES[S.endingChoice] || ENDING_LINES.neutral;
 const el = document.getElementById('intro-line');
 const fill = document.getElementById('intro-progress-fill');
 if(outroIndex >= lines.length){ Game.goto('ending'); renderEnding(S.endingChoice, false); return; }
 el.classList.remove('show');
 outroTimer = setTimeout(()=>{
  if(outroSkipped) return;
  el.textContent = lines[outroIndex];
  el.classList.add('show');
  fill.style.width = Math.round(((outroIndex+1)/lines.length)*100)+'%';
  outroIndex++;
  outroTimer = setTimeout(playOutroLine, ENDING_LINE_MS);
 }, outroIndex===0 ? 200 : 700);
}
function beginOutro(){
 outroSkipped = false;
 outroIndex = 0;
 document.getElementById('intro-line').textContent = '';
 document.getElementById('intro-line').classList.remove('show');
 document.getElementById('intro-progress-fill').style.width = '0%';
 document.getElementById('intro-eyebrow').textContent = 'Leaving Harrow County';
 document.querySelector('.intro-skip').onclick = ()=> Game.skipOutro();
 Game.goto('intro');
 playOutroLine();
}

/* ================= GAME PUBLIC API ================= */
const Game = {
 goto(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById('screen-'+id).classList.add('active');
  if(id==='game'){ document.getElementById('screen-game').style.display='block'; renderWeaponSlots(); }
 },
 beginIntro(){
  introSkipped = false;
  introIndex = 0;
  document.getElementById('intro-line').textContent = '';
  document.getElementById('intro-line').classList.remove('show');
  document.getElementById('intro-progress-fill').style.width = '0%';
  document.getElementById('intro-eyebrow').textContent = 'Classified — Revelation Biotech Internal Archive';
  document.querySelector('.intro-skip').onclick = ()=> Game.skipIntro();
  Game.goto('intro');
  playIntroLine();
 },
 skipIntro(){
  introSkipped = true;
  if(introTimer){ clearTimeout(introTimer); introTimer = null; }
  Game.startGame();
 },
 skipOutro(){
  outroSkipped = true;
  if(outroTimer){ clearTimeout(outroTimer); outroTimer = null; }
  Game.goto('ending');
  renderEnding(S.endingChoice, false);
 },
 startGame(){
  S = newState(selectedSurvivor);
  Game.goto('game');
  activateNextQuests();
  enterLocation('suburbs');
  renderWeaponSlots();
  updateHudDynamic();
  if(!RAF) RAF = requestAnimationFrame(loop);
 },
 continueGame(){
  if(S){ Game.goto('game'); return; }
  const loaded = loadGame();
  if(!loaded){ toast('No saved game found.', 'bad'); return; }
  S = loaded;
  Game.goto('game');
  enterLocation(S.currentLocation || 'suburbs');
  renderWeaponSlots();
  updateHudDynamic();
  if(!RAF) RAF = requestAnimationFrame(loop);
 },
 quitToTitle(){
  if(S && S.hp>0){ saveGame(); }
  RAF && cancelAnimationFrame(RAF); RAF=null; lastT=0; S=null; W=null;
  document.getElementById('bossbar').style.display='none';
  document.getElementById('modal-bg').classList.remove('open');
  document.getElementById('flashOverlay').style.display='none';
  Game.goto('title');
  updateContinueButton();
 },
 toggleModal(name){
  const el = document.getElementById('modal-'+name);
  const bg = document.getElementById('modal-bg');
  if(bg.classList.contains('open') && el.style.display==='flex'){ Game.closeModal(); return; }
  Game.showModal(name);
 },
 toggleQuestsTab(tab){
  const el = document.getElementById('modal-quests');
  const bg = document.getElementById('modal-bg');
  if(bg.classList.contains('open') && el.style.display==='flex' && questTabState===tab){ Game.closeModal(); return; }
  questTabState = tab;
  Game.showModal('quests');
 },
 toggleAchTab(tab){
  const el = document.getElementById('modal-achievements');
  const bg = document.getElementById('modal-bg');
  if(bg.classList.contains('open') && el.style.display==='flex' && achTabState===tab){ Game.closeModal(); return; }
  achTabState = tab;
  Game.showModal('achievements');
 },
 showModal(name){
  document.querySelectorAll('.modal').forEach(m=>m.style.display='none');
  const el = document.getElementById('modal-'+name); if(!el) return;
  el.style.display='flex'; el.style.flexDirection='column';
  document.getElementById('modal-bg').classList.add('open');
  if(name==='inventory') renderInventoryModal();
  if(name==='map') renderMapModal();
  if(name==='quests') renderQuestsModal();
  if(name==='skills') renderSkillsModal();
  if(name==='achievements') renderAchModal();
  if(name==='trade') renderTradeModal();
 },
 closeModal(){ document.querySelectorAll('.modal').forEach(m=>m.style.display='none'); document.getElementById('modal-bg').classList.remove('open'); },
 questTab(t){ questTabState=t; renderQuestsModal(); },
 achTab(t){ achTabState=t; renderAchModal(); },
 openHelp(){ Game.showModal('help'); }
};

/* ================= INIT ================= */
window.addEventListener('DOMContentLoaded', ()=>{
 buildLoreArt();
 renderRoster();
 updateContinueButton();
 if(!RAF) RAF = requestAnimationFrame(loop);
});
function buildLoreArt(){
 ['art-city','art-ruin'].forEach(id=>{
  const host = document.getElementById(id); if(!host) return;
  const sky = host.querySelector('.skyline'); if(!sky) return;
  const sun = document.createElement('div'); sun.className='sun'; sky.appendChild(sun);
  const n = id==='art-city'?7:5;
  for(let i=0;i<n;i++){
   const b = document.createElement('div'); b.className='bld';
   const w = 40+Math.random()*70, h=60+Math.random()*140;
   b.style.left=(i*(100/n))+'%'; b.style.width=w+'px'; b.style.height=h+'px';
   sky.appendChild(b);
   for(let wI=0; wI<Math.floor(h/18); wI++){
    const win = document.createElement('div'); win.className='win';
    win.style.left=(parseFloat(b.style.left))+ (10+Math.random()*(w-20)) +'px';
    win.style.bottom=(8+wI*18)+'px';
    sky.appendChild(win);
   }
  }
 });
}
