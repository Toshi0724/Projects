'use strict';
/* ================= DEAD HORIZON: REVELATION — ENGINE ================= */

/* ---------- utility ---------- */
function rand(a,b){ return a + Math.random()*(b-a); }
function randInt(a,b){ return Math.floor(rand(a,b+1)); }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function clamp(v,a,b){ return Math.max(a, Math.min(b,v)); }
function dist(x1,y1,x2,y2){ return Math.hypot(x2-x1, y2-y1); }
function lerp(a,b,t){ return a + (b-a)*t; }
function angleTo(x1,y1,x2,y2){ return Math.atan2(y2-y1, x2-x1); }
function angleDiff(a,b){ let d = a-b; while(d>Math.PI) d-=Math.PI*2; while(d<-Math.PI) d+=Math.PI*2; return d; }

/* ---------- global state ---------- */
let S = null;           // survivor runtime state
let W = null;           // current world/location state
let dlgState = null;    // {tree, node, npc}
let RAF = null, lastT = 0;
const KEYS = {};
let selectedSurvivor = null;

const canvas = document.getElementById('gamecanvas');
const ctx = canvas.getContext('2d');
const fogCanvas = document.createElement('canvas');
const fogCtx = fogCanvas.getContext('2d');
function resizeCanvases(){
 canvas.width = window.innerWidth; canvas.height = window.innerHeight;
 fogCanvas.width = window.innerWidth; fogCanvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvases);
resizeCanvases();

const DAY_LENGTH_MS = 12*60*1000; // one full in-game day per 12 real minutes

/* ================= STATE FACTORY ================= */
function newState(survivorId){
 const sv = SURVIVORS.find(s=>s.id===survivorId);
 const st = {
  id:sv.id, name:sv.name, role:sv.role, perk:sv.perk, color:sv.color,
  END:sv.END, AGI:sv.AGI, STR:sv.STR, PER:sv.PER, STA:sv.STA,
  level:1, xp:0, xpNext:xpToNext(1), skillPoints:0, skills:{},
  maxHp:100+sv.END*5, hp:100+sv.END*5,
  maxStamina:70+sv.STA*4, stamina:70+sv.STA*4,
  hunger:100, thirst:100,
  charisma:5, karma:0, tokens:15, kills:0, banditKills:0, campKills:0,
  companions:[], companionTrust:{},
  equipped:{armor:null, backpack:null}, armorDurability:0,
  carryCap:BACKPACK_BASE_CAPACITY,
  inventory:[],
  weaponSlots:{melee:sv.startWeapon && WEAPONS_MELEE[sv.startWeapon] ? sv.startWeapon : 'fists', secondary:null, primary:null, rocket:null, throwable:null},
  magAmmo:{secondary:0, primary:0, rocket:0},
  reloadingSlot:null, reloadEndsAt:0,
  activeSlot:'melee',
  status:{bleeding:0, infected:0, infectedSeverity:0, sick:0},
  flags:{}, questsMain:{}, questsSide:{}, achievements:{}, journalPages:{}, visitedLocations:{},
  flashlight:false, facing:{x:0,y:1},
  gameMinutes:480, dayCount:1,
  buffs:[], secondWindUsed:false, konami:false,
  currentLocation:null
 };
 COMPANIONS.forEach(c=> st.companionTrust[c.id]=0 );
 if(sv.kit) sv.kit.forEach(itemId=>{
  if(WEAPONS_RANGED[itemId]){ giveWeaponItem(st,itemId); }
  else if(findConsumableById(itemId)){ addToInventory(st,itemId, consumableKind(itemId), 1); }
 });
 if(sv.startAmmo){
  for(const ammoType in sv.startAmmo){
   addToInventory(st, 'ammo_'+ammoType, 'ammo', sv.startAmmo[ammoType]);
  }
 }
 for(const mq in MAIN_QUESTS) st.questsMain[mq] = {status:'locked', progress:0};
 for(const sq in SIDE_QUESTS) st.questsSide[sq] = {status:'locked', progress:0};
 for(const a of ACHIEVEMENTS) st.achievements[a.id] = false;
 return st;
}
function consumableKind(id){ if(DRINKS[id]) return 'drink'; if(FOODS[id]) return 'food'; if(MEDS[id]) return 'med'; if(BUFF_ITEMS[id]) return 'buff'; return 'item'; }

/* ================= INVENTORY ================= */
function itemWeight(kind){
 switch(kind){
  case 'weapon_melee': return 4;
  case 'weapon_ranged': return 7;
  case 'weapon_throwable': return 1;
  case 'ammo': return 0.1;
  case 'drink': case 'food': case 'med': return 1;
  case 'armor': return 6;
  case 'backpack': return 4;
  default: return 1;
 }
}
function carryWeight(st){
 let w=0;
 st.inventory.forEach(it=> w += itemWeight(it.kind)*it.qty );
 return Math.round(w*10)/10;
}
function findInv(st,id){ return st.inventory.find(i=>i.id===id); }
function addToInventory(st, id, kind, qty){
 qty = qty||1;
 const addWeight = itemWeight(kind)*qty;
 if(carryWeight(st)+addWeight > st.carryCap){ toast('Not enough carrying capacity.', 'bad'); return false; }
 const ex = findInv(st,id);
 if(ex){ ex.qty += qty; } else { st.inventory.push({id,kind,qty}); }
 return true;
}
function removeFromInventory(st, id, qty){
 qty = qty||1;
 const ex = findInv(st,id);
 if(!ex) return false;
 ex.qty -= qty;
 if(ex.qty<=0) st.inventory = st.inventory.filter(i=>i.id!==id);
 return true;
}
function giveWeaponItem(st, wid){
 const cat = weaponCategory(wid);
 if(cat==='melee'){
  addToInventory(st, wid, 'weapon_melee', 1);
 } else if(cat==='ranged'){
  addToInventory(st, wid, 'weapon_ranged', 1);
 } else if(cat==='throwable'){
  addToInventory(st, wid, 'weapon_throwable', 1);
 }
}
function equipWeaponFromInventory(st, wid){
 const cat = weaponCategory(wid);
 if(cat==='melee'){
  const old = st.weaponSlots.melee;
  st.weaponSlots.melee = wid;
  removeFromInventory(st, wid, 1);
  if(old && old!=='fists') addToInventory(st, old, 'weapon_melee', 1);
 } else if(cat==='ranged'){
  const w = WEAPONS_RANGED[wid]; const slot = w.slot;
  const old = st.weaponSlots[slot];
  st.weaponSlots[slot] = wid;
  st.magAmmo[slot] = 0;
  removeFromInventory(st, wid, 1);
  if(old) addToInventory(st, old, 'weapon_ranged', 1);
 } else if(cat==='throwable'){
  st.weaponSlots.throwable = wid;
 }
 renderWeaponSlots(); renderInventoryModal();
}
function equipArmor(st, aid){
 const a = ARMOR[aid]; if(!a) return;
 if(st.equipped.armor) addToInventory(st, st.equipped.armor, 'armor', 1);
 removeFromInventory(st, aid, 1);
 st.equipped.armor = aid; st.armorDurability = a.durability;
 toast('Equipped '+a.name+'.', 'amber');
 checkGearedUp(); renderInventoryModal();
}
function unequipArmor(st){
 if(!st.equipped.armor) return;
 addToInventory(st, st.equipped.armor, 'armor', 1);
 st.equipped.armor = null; st.armorDurability = 0;
 renderInventoryModal();
}
function equipBackpack(st, bid){
 const b = BACKPACKS[bid]; if(!b) return;
 if(st.equipped.backpack) addToInventory(st, st.equipped.backpack, 'backpack', 1);
 removeFromInventory(st, bid, 1);
 st.equipped.backpack = bid;
 st.carryCap = BACKPACK_BASE_CAPACITY + b.bonus + (st.skills.packmule?15:0);
 toast('Equipped '+b.name+'.', 'amber');
 checkGearedUp(); renderInventoryModal();
}
function unequipBackpack(st){
 if(!st.equipped.backpack) return;
 addToInventory(st, st.equipped.backpack, 'backpack', 1);
 st.equipped.backpack = null;
 st.carryCap = BACKPACK_BASE_CAPACITY + (st.skills.packmule?15:0);
 renderInventoryModal();
}
function checkGearedUp(){
 if(S.equipped.armor==='assault' && S.equipped.backpack==='tactical'){
  unlockAchievement('fully_geared');
 }
 if(S.equipped.armor && S.equipped.backpack && !S.flags.geared_up){
  S.flags.geared_up = true; completeQuestByFlag('geared_up');
 }
}

/* ================= COMPANIONS ================= */
function recruitCompanion(cid){
 if(S.companions.includes(cid)) return;
 const idx = S.companions.length;
 const cost = companionRecruitCost(idx);
 if(!cost){ toast('Your squad is already full.', 'bad'); return; }
 if(cost.type==='karma'){
  if(S.karma < cost.amount){ toast('Not enough karma yet (needs '+cost.amount+').', 'bad'); return; }
  S.karma -= cost.amount;
 } else {
  if(S.tokens < cost.amount){ toast('Not enough tokens yet (needs '+cost.amount+').', 'bad'); return; }
  S.tokens -= cost.amount;
 }
 S.companions.push(cid);
 const c = COMPANIONS.find(x=>x.id===cid);
 toast(c.name+' joins your squad. (−'+cost.amount+' '+(cost.type==='karma'?'Karma':'Tokens')+')', 'amber');
 if(!S.flags.recruited_one){ S.flags.recruited_one = true; completeQuestByFlag('recruited_one'); }
 if(S.companions.length>=COMPANIONS.length) unlockAchievement('squad_goals');
 spawnCompanionsInWorld();
 updateHudDynamic();
}

/* ================= LOCATION LAYOUT (procedural, per kit) ================= */
function seededRand(seed){ let s = seed%2147483647; if(s<=0) s+=2147483646; return function(){ s = s*16807 % 2147483647; return (s-1)/2147483646; }; }
function rectOverlap(ax,ay,aw,ah,bx,by,bw,bh){
 return ax < bx+bw && ax+aw > bx && ay < by+bh && ay+ah > by;
}
function buildRoads(loc){
 const roads = [];
 const W_=loc.w, H_=loc.h;
 function road(x,y,w,h){ roads.push({x,y,w,h}); }
 switch(loc.kit){
  case 'suburbs':
   road(0, H_/2-40, W_, 80);
   road(W_/2-40, 0, 80, H_);
   break;
  case 'parking_lot':
   road(0, H_-56, W_, 56);
   break;
  case 'bus_station':
   road(0, H_-46, W_, 46);
   break;
  case 'restaurant':
   road(0, 0, 60, H_);
   break;
  case 'bank':
   road(0, H_-64, W_, 64);
   break;
  case 'supermarket':
   road(0, H_-54, W_, 54);
   break;
  case 'warehouse':
   road(0, H_-60, W_, 60);
   break;
  case 'quarantine_zone':
   road(0, H_-40, W_, 40);
   break;
  case 'embassy':
   road(0, H_-40, W_, 40);
   break;
  case 'military_base':
   road(0, H_-60, W_, 60);
   break;
  case 'shipyard':
   road(0, H_-60, W_, 60);
   break;
  case 'airport':
   road(0, H_-70, W_-260, 70);
   break;
  case 'police_station':
   road(0, H_-50, W_, 50);
   break;
  case 'army_outpost':
   road(0, H_-60, W_, 60);
   break;
  case 'radio_station':
   road(0, H_-46, W_, 46);
   break;
  case 'gas_station':
   road(0, H_-50, W_, 50);
   break;
  case 'church':
   road(0, H_-40, W_, 40);
   break;
  case 'city_hall':
   road(0, H_-50, W_, 50);
   break;
  case 'military_blockade':
   road(0, H_/2-40, W_, 80);
   break;
  case 'farm':
   road(0, H_-50, W_, 50);
   break;
  case 'bandit_camp':
   road(0, H_-50, W_, 50);
   break;
 }
 return roads;
}
function buildProps(loc, roads){
 const rnd = seededRand(loc.id.length*97 + loc.w);
 const raw = [];
 const W_=loc.w, H_=loc.h;
 (roads||[]).forEach(r=> raw.push({x:r.x, y:r.y, w:r.w, h:r.h, __road:true}));
 function overlapsExisting(x,y,w,h){ return raw.some(p=>rectOverlap(x,y,w,h,p.x,p.y,p.w,p.h)); }
 function rect(x,y,w,h,label,fill){ raw.push({x,y,w,h,label,fill}); }
 function rectSpaced(x,y,w,h,label,fill){
  // used for freely-scattered layouts: retry a few times so props can't stack
  // into a dense, inescapable cluster (and now also steer clear of roads)
  for(let tries=0; tries<8 && overlapsExisting(x-24,y-24,w+48,h+48); tries++){
   x = 40+rnd()*(W_-w-80); y = 40+rnd()*(H_-h-80);
  }
  raw.push({x,y,w,h,label,fill});
 }
 switch(loc.kit){
  case 'suburbs':
   for(let i=0;i<7;i++){
    rectSpaced(80+rnd()*(W_-260), 80+rnd()*(H_-260), 90+rnd()*70, 60+rnd()*70, 'House', '#171810');
    raw[raw.length-1].variant = (i%3===0) ? 'flat' : 'peaked';
   }
   break;
  case 'camp':
   rect(70, H_-260, 280, 200, 'Camp Hall', '#1c1d13');
   for(let i=0;i<6;i++) rect(60+i*140, 40, 40, 40, 'Tent', '#26271a');
   break;
  case 'hospital':
   for(let i=0;i<5;i++) rect(100+i*220, 120, 180, 90, 'Ward', '#151710');
   rect(W_/2-60,H_/2-40,120,80,'Nurse Station','#1c1d13');
   break;
  case 'warehouse':
   for(let r=0;r<3;r++) for(let c=0;c<4;c++) rect(120+c*280, 100+r*260, 220, 160, 'Shelving', '#171810');
   break;
  case 'ruins':
   for(let i=0;i<8;i++) rectSpaced(rnd()*(W_-180), rnd()*(H_-180), 70+rnd()*90, 70+rnd()*90, 'Rubble', '#141510');
   break;
  case 'cemetery':
   for(let r=0;r<5;r++) for(let c=0;c<7;c++) rect(80+c*130,90+r*130,26,40,'Headstone','#22241a');
   break;
  case 'bus_station':
   rect(W_/2-220,H_/2-70,440,140,'Terminal','#171810');
   for(let i=0;i<3;i++) rect(120+i*300,H_-160,160,60,'Bus','#20261a');
   break;
  case 'library':
   for(let r=0;r<4;r++) for(let c=0;c<6;c++) rect(90+c*140,100+r*140,100,26,'Shelf','#171810');
   break;
  case 'supermarket':
   for(let r=0;r<4;r++) for(let c=0;c<5;c++) rect(100+c*220,110+r*160,170,40,'Aisle','#171810');
   break;
  case 'bank':
   rect(W_/2-260,80,520,120,'Teller Row','#171810');
   rect(W_/2-70,H_/2+40,160,160,'Vault','#221a12');
   break;
  case 'parking_lot':
   for(let r=0;r<4;r++) for(let c=0;c<8;c++){
    const truck = (r+c)%3===0;
    rect(70+c*140,90+r*180,110,60,'Car', truck?'#20261a':'#171d20');
    raw[raw.length-1].variant = truck?'truck':'sedan';
   }
   break;
  case 'quarantine_zone':
   for(let i=0;i<10;i++) rectSpaced(80+rnd()*(W_-220), 80+rnd()*(H_-220), 80, 80, 'Tent', '#1c1408');
   rect(40,40,W_-80,20,'Barrier Fence','#3a2010'); rect(40,H_-60,W_-80,20,'Barrier Fence','#3a2010');
   break;
  case 'shipyard':
   for(let r=0;r<3;r++) for(let c=0;c<6;c++) rect(80+c*220, 100+r*220, 180, 130, 'Container', '#151d1f');
   rect(W_-260,H_/2-40,180,80,'Crane Base','#20201a');
   break;
  case 'airport':
   rect(120,140,W_-400,200,'Terminal','#171810');
   for(let i=0;i<4;i++) rect(160+i*260,H_-260,180,90,'Luggage Cart','#1a1a1a');
   rect(W_-260,80,160,H_-260,'Runway Edge','#101210');
   break;
  case 'embassy':
   rect(W_/2-200,120,400,240,'Main Building','#171810');
   rect(80,80,W_-160,20,'Perimeter Fence','#2a2a1a'); rect(80,H_-100,W_-160,20,'Perimeter Fence','#2a2a1a');
   rect(W_/2-6,340,12,120,'Flagpole','#3a3a2a');
   break;
  case 'restaurant':
   for(let r=0;r<3;r++) for(let c=0;c<4;c++) rect(90+c*160,110+r*140,60,60,'Table','#1a1610');
   rect(W_-220,60,160,H_-140,'Kitchen','#20160e');
   break;
  case 'military_base':
   rect(W_/2-260,100,520,180,'Bunker','#14150f');
   rect(W_/2-90,H_/2+60,180,160,'Deep Lab Access','#241a0a');
   break;
  case 'police_station':
   rect(W_/2-220,120,440,240,'Main Building','#1c2230');
   for(let i=0;i<3;i++) rect(90+i*160,H_-170,130,60,'Car','#1c2230');
   rect(80,80,W_-160,20,'Barrier Fence','#2a1a0a');
   rectSpaced(140,420,180,120,'Shelving','#171810');
   rectSpaced(W_-340,420,180,120,'Shelving','#171810');
   break;
  case 'army_outpost':
   rect(W_/2-260,100,520,180,'Bunker','#14150f');
   rect(90,90,70,220,'Watchtower','#20201a');
   rect(W_-160,90,70,220,'Watchtower','#20201a');
   rect(80,H_/2+40,W_-160,20,'Barrier Fence','#2a1a0a');
   for(let i=0;i<4;i++) rect(140+i*220,H_/2+120,160,110,'Container','#151d1f');
   break;
  case 'radio_station':
   rect(320,140,360,220,'House','#1c1a14');
   rect(720,60,30,300,'Antenna','#3a3a2a');
   rectSpaced(140,420,160,90,'Table','#1a1610');
   break;
  case 'gas_station':
   rect(120,120,220,160,'House','#1c1a14');
   rect(420,260,60,80,'GasPump','#2a2a1e');
   rect(540,260,60,80,'GasPump','#2a2a1e');
   rect(420,380,110,60,'Car','#171d20');
   rect(560,380,110,60,'Car','#20261a');
   break;
  case 'church':
   rect(W_/2-140,110,280,260,'Church','#241a12');
   for(let i=0;i<10;i++) rectSpaced(80+rnd()*(W_-260),H_-320+rnd()*160,26,34,'Headstone','#22241a');
   break;
  case 'city_hall':
   rect(W_/2-220,110,440,260,'Main Building','#1c1a14');
   rect(W_/2-6,380,12,110,'Flagpole','#3a3a2a');
   rectSpaced(120,H_-260,220,140,'Rubble','#141510');
   rectSpaced(W_-340,H_-260,220,140,'Rubble','#141510');
   break;
  case 'military_blockade':
   rect(90,H_/2-260,80,220,'Watchtower','#20201a');
   rect(W_-170,H_/2-260,80,220,'Watchtower','#20201a');
   rect(90,H_/2+40,80,180,'Bunker','#14150f');
   rect(W_-170,H_/2+40,80,180,'Bunker','#14150f');
   for(let i=0;i<3;i++) rect(300+i*220,H_/2-180,140,90,'Container','#151d1f');
   break;
  case 'farm':
   rect(140,H_-380,220,180,'House','#3a2418');
   rect(420,H_-360,170,170,'Barn','#5a1a10');
   rect(650,H_-400,90,150,'Silo','#8a8a7a');
   rect(60,60,W_-120,20,'Barrier Fence','#2a1a0a');
   rect(820,H_-260,110,60,'Car','#3a2a1a');
   break;
  case 'train_station':
   rect(W_/2-260,120,520,180,'Terminal','#171810');
   rect(80,H_-260,W_-160,50,'Tracks','#151510');
   for(let i=0;i<3;i++) rect(140+i*260,H_-380,180,80,'Luggage Cart','#1a1a1a');
   break;
  case 'bandit_camp':
   for(let i=0;i<5;i++) rectSpaced(80+rnd()*(W_-260),80+rnd()*(H_-260),120,90,'Tent','#26271a');
   rectSpaced(W_/2-100,H_/2-60,200,120,'Rubble','#141510');
   rect(60,60,W_-120,20,'Barrier Fence','#2a1a0a');
   rect(60,H_-160,W_-120,20,'Barrier Fence','#2a1a0a');
   break;
 }
 // The survivor always spawns at the exact center of the location — guarantee
 // that point (plus a margin) is never covered by a prop, or they'd be trapped
 // inside a structure the instant they walk in.
 const clearW=200, clearH=200, clearX=W_/2-clearW/2, clearY=H_/2-clearH/2;
 return raw.filter(p=>!p.__road && !rectOverlap(p.x,p.y,p.w,p.h, clearX,clearY,clearW,clearH));
}

/* ================= ZOMBIES / BANDITS ================= */
function spawnZombie(loc){
 const tierHp = 24 + loc.tier*9;
 return {
  kind:'zombie', x:rand(60,loc.w-60), y:rand(60,loc.h-60),
  hp:tierHp, maxHp:tierHp, dmg:6+loc.tier*1.5, speed:rand(0.55,0.85),
  aggro:false, atkCd:0, r:14
 };
}
function spawnBandit(loc, type){
 type = type || (Math.random()<0.65?'melee':'ranged');
 const base = {melee:{hp:50,dmg:12,speed:1.15}, ranged:{hp:38,dmg:9,speed:0.9}, elite:{hp:130,dmg:16,speed:1.0}}[type];
 return {
  kind:'bandit', banditType:type, x:rand(60,loc.w-60), y:rand(60,loc.h-60),
  hp:base.hp+loc.tier*6, maxHp:base.hp+loc.tier*6, dmg:base.dmg, speed:base.speed,
  aggro:false, atkCd:0, fireCd:0, r:15
 };
}

/* Open-point placement: rejection-samples a spot that isn't inside (or hugging)
   any prop, so loot, NPCs, and enemies never spawn unreachable inside a wall.
   Falls back to the map's guaranteed-clear center if it can't find one. */
function randomOpenPoint(props, w, h, margin){
 margin = margin===undefined ? 36 : margin;
 for(let i=0;i<25;i++){
  const x = rand(50,w-50), y = rand(50,h-50);
  let clear = true;
  for(const p of props){ if(rectOverlap(x-margin,y-margin,margin*2,margin*2, p.x,p.y,p.w,p.h)){ clear=false; break; } }
  if(clear) return {x,y};
 }
 return {x:w/2, y:h/2};
}
/* Safety net for anything placed at a fixed/hand-authored coordinate (NPCs) —
   shoves it back out if it happens to land inside a prop. */
function nudgeOutOfProps(ent, props, radius){
 radius = radius||24;
 for(const p of props){
  const cx = clamp(ent.x, p.x, p.x+p.w);
  const cy = clamp(ent.y, p.y, p.y+p.h);
  const dx = ent.x-cx, dy = ent.y-cy;
  const distSq = dx*dx+dy*dy;
  if(distSq < radius*radius){
   const d = Math.sqrt(distSq) || 0.001;
   const push = (radius-d)+4;
   ent.x += (dx/d)*push; ent.y += (dy/d)*push;
  }
 }
}

/* ================= ENTER LOCATION ================= */
function enterLocation(id){
 const loc = findLocation(id);
 S.currentLocation = id;
 const roads = buildRoads(loc);
 const props = buildProps(loc, roads);
 const zCount = randInt(loc.zRange[0],loc.zRange[1]);
 const zombies = [];
 for(let i=0;i<zCount;i++){
  const z = spawnZombie(loc);
  const pt = randomOpenPoint(props, loc.w, loc.h, 24);
  z.x=pt.x; z.y=pt.y;
  zombies.push(z);
 }
 const bandits = [];
 if(loc.isBanditCamp){
  const n = randInt(7,11);
  for(let i=0;i<n;i++){
   const roll = Math.random();
   const b = spawnBandit(loc, roll<0.25?'elite':(roll<0.6?'melee':'ranged'));
   const pt = randomOpenPoint(props, loc.w, loc.h, 24);
   b.x=pt.x; b.y=pt.y;
   bandits.push(b);
  }
 } else if(!loc.noLoot && Math.random()<loc.banditChance*3){
  const n = randInt(1,3);
  for(let i=0;i<n;i++){
   const roll = Math.random();
   const b = spawnBandit(loc, roll<0.15?'elite':(roll<0.55?'melee':'ranged'));
   const pt = randomOpenPoint(props, loc.w, loc.h, 24);
   b.x=pt.x; b.y=pt.y;
   bandits.push(b);
  }
 }
 const crates = [];
 if(!loc.noLoot){
  const cCount = randInt(4,8);
  for(let i=0;i<cCount;i++){
   const pt = randomOpenPoint(props, loc.w, loc.h, 40);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'normal'});
  }
  if(loc.special && !S.flags[loc.special]){
   const pt = randomOpenPoint(props, loc.w, loc.h, 40);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'special', flag:loc.special});
  }
  const page = JOURNAL_PAGES.find(j=>j.loc===id && !S.journalPages[j.id]);
  if(page){
   const pt = randomOpenPoint(props, loc.w, loc.h, 40);
   crates.push({x:pt.x, y:pt.y, looted:false, kind:'journal', pageId:page.id});
  }
 }
 let npcs = (NPC_MARKERS[id]||[]).filter(n=>!n.once || !S.flags[n.once]).map(n=>Object.assign({},n));
 npcs.forEach(n=>nudgeOutOfProps(n, props, 30));
 W = {
  locId:id, w:loc.w, h:loc.h,
  player:{x:loc.w/2, y:loc.h/2},
  zombies, bandits, npcs, crates, props, roads,
  projectiles:[], meleeFx:[], explosionFx:[], companionsEnt:[],
  campSpawnCd: 8000
 };
 spawnCompanionsInWorld();
 updateHudLocation();
 S.visitedLocations[id] = true;
 if(Object.keys(S.visitedLocations).length >= LOCATIONS.length) unlockAchievement('well_traveled');
 if(id==='military_base' && S.flags.boss_pending && !S.flags.boss_defeated){ spawnBoss(); }
}
/* All 5 companions are always physically present at camp — recruited or not —
   so the player can walk up to any of them and see the recruit dialogue. Only
   recruited companions follow and fight alongside the player elsewhere. */
function spawnCompanionsInWorld(){
 if(!W) return;
 if(W.locId==='camp'){
  W.companionsEnt = COMPANIONS.map((c,i)=>({
   id:c.id, name:c.name, color:c.color, x:280+i*70, y:220, hp:400, maxHp:400,
   weapon:c.weapon, atkCd:0, recruited:S.companions.includes(c.id), isCampStatic:true
  }));
  W.companionsEnt.forEach(c=>nudgeOutOfProps(c,W.props,26));
 } else {
  W.companionsEnt = COMPANIONS.filter(c=>S.companions.includes(c.id)).map((c,i)=>({
   id:c.id, name:c.name, color:c.color, x:W.player.x+30+i*26, y:W.player.y+34, hp:400, maxHp:400,
   weapon:c.weapon, atkCd:0, recruited:true, isCampStatic:false
  }));
 }
}

/* ================= BOSS ================= */
function spawnBoss(){
 W.boss = {kind:'boss', x:W.w/2, y:W.h/2+60, hp:900, maxHp:900, dmg:26, speed:0.7, atkCd:0, r:34};
 document.getElementById('bossbar').style.display='block';
 toast('The Harrowed stirs.', 'bad');
}
function onBossDefeated(){
 S.flags.boss_pending = false;
 document.getElementById('bossbar').style.display='none';
 gainXP(300);
 openDialogue('final_choice');
}
function resolveEnding(choice){
 S.flags.boss_defeated = true;
 if(S.questsMain.m8) S.questsMain.m8.status='done';
 let final = choice;
 if(choice==='good' && (S.karma<10 || S.charisma<10)) final='neutral';
 S.ending = final;
 Game.goto('ending');
 renderEnding(final, false);
}
const ENDING_COPY = {
 good:{title:'THE LONG DAWN', body:"The incinerator array roars to life beneath the Ridge, and RVL-9 burns with it — every sample, every note, every chance of this happening again. It costs the lab, and it costs you something too. But when you walk out to the tree line, Harrow County's survivors are still there, waiting, and for the first time in months, nobody is looking over their shoulder. You didn't save everything. You saved enough."},
 bad:{title:'NEW BUYER', body:"The samples go into a case, the case goes into a truck, and somewhere down the line someone with a lot of money stops asking where they came from. Harrow County doesn't get its answers. It gets a payout instead, and a very quiet warning never to ask what RVL-9 was really worth."},
 neutral:{title:'QUIET GROUND', body:"You seal the lab and walk away from it, samples and all, and tell yourself that's the responsible choice. Maybe it is. The Ridge goes quiet again, the county keeps digging out from what's already happened, and nobody ever really finds out what was down there. Some doors are better left shut."},
 death:{title:'DID NOT MAKE IT', body:"Harrow County keeps score whether you're there to see it or not. Your name goes on the fence with the others — one more marker in a county that ran out of room for them a long time ago."}
};
function renderEnding(kind, isDeath){
 const screen = document.getElementById('screen-ending');
 screen.className = 'screen active end-'+(isDeath?'bad':kind);
 const copy = isDeath ? ENDING_COPY.death : (ENDING_COPY[kind]||ENDING_COPY.neutral);
 document.getElementById('end-title').textContent = copy.title;
 document.getElementById('end-body').textContent = copy.body;
 const stats = document.getElementById('end-stats');
 const journalCount = Object.keys(S.journalPages).length;
 const achCount = Object.values(S.achievements).filter(Boolean).length;
 stats.innerHTML = [
  ['Level Reached', S.level], ['Zombies Killed', S.kills], ['Bandits Killed', S.banditKills],
  ['Charisma', S.charisma], ['Karma', (S.karma>=0?'+':'')+S.karma], ['Companions', S.companions.length+'/'+COMPANIONS.length],
  ['Journal Pages', journalCount+'/'+JOURNAL_PAGES.length], ['Achievements', achCount+'/'+ACHIEVEMENTS.length]
 ].map(([label,val])=>`<div><b>${val}</b>${label}</div>`).join('');
 document.getElementById('bossbar').style.display='none';
}

/* ================= DAMAGE / STATUS ================= */
function applyBuffMult(stat, base){
 let mult=1;
 S.buffs.forEach(b=>{ if(b.stat===stat && b.mult) mult*=b.mult; });
 return base*mult;
}
function meleeDamageMult(){
 let m=1;
 if(S.skills.melee_mastery) m*=1.15;
 if(S.role==='Lumberjack') m*=1.20;
 m = applyBuffMult('meleeDmg', m);
 return m;
}
function rangedDamageMult(weaponId){
 let m=1;
 if(S.skills.marksman) m*=1.15;
 if(S.skills.heavy_hands && (weaponId==='rpg'||weaponId==='law'||weaponId==='saw')) m*=1.20;
 const w = WEAPONS_RANGED[weaponId];
 if(w && w.slot==='secondary') m = applyBuffMult('apPistolDmg', m);
 if(w && w.slot==='primary') m = applyBuffMult('apRifleDmg', m);
 return m;
}
function armorReduction(){
 if(!S.equipped.armor || S.armorDurability<=0) return 0;
 let r = ARMOR[S.equipped.armor].reduction;
 if(S.skills.armorer) r = Math.min(0.95, r+0.05);
 return r;
}
function damagePlayer(dmg, kind){
 if(kind==='melee' && S.skills.evasive && Math.random()<0.08){ toast('Dodged!', 'amber'); return; }
 let r = armorReduction();
 let inRoster = COMPANIONS.find(c=>c.id==='rorke' && S.companions.includes('rorke'));
 if(inRoster) dmg *= 0.9;
 dmg *= (1-r);
 S.hp -= dmg;
 if(S.equipped.armor && S.armorDurability>0){
  S.armorDurability -= (S.skills.armorer?1.6:2);
  if(S.armorDurability<=0){ toast(ARMOR[S.equipped.armor].name+' broke!', 'bad'); S.equipped.armor=null; }
 }
 if(kind==='zombie'){
  if(Math.random()<0.28) inflictStatus('bleeding', 15000);
  if(Math.random()<0.14) inflictStatus('infected', 0);
  if(Math.random()<0.08) inflictStatus('sick', 20000);
 }
 if(S.hp<=0){
  if(!S.secondWindUsed && S.skills.second_wind){ S.secondWindUsed=true; S.hp=1; toast('Second Wind! You barely survive.', 'amber'); }
  else onPlayerDeath();
 } else if(S.hp <= 5){ unlockAchievement('iron_will'); }
}
function inflictStatus(type, ms){
 if(type==='infected' && S.equipped.armor==='cbrn') return; // CBRN suit blocks infection entirely
 if(type==='bleeding') S.status.bleeding = Math.max(S.status.bleeding, ms);
 else if(type==='sick') S.status.sick = Math.max(S.status.sick, ms);
 else if(type==='infected'){
  S.status.infected = 1;
  S.status.infectedSeverity = Math.min(3, S.status.infectedSeverity+1);
 }
}
function cureStatus(key){
 if(key==='bleeding') S.status.bleeding = 0;
 else if(key==='sick') S.status.sick = 0;
 else if(key==='infected'){ S.status.infected=0; S.status.infectedSeverity=0; }
 else if(key==='infected_early'){ if(S.status.infectedSeverity<=1){ S.status.infected=0; S.status.infectedSeverity=0; toast('Antibiotics worked.', 'amber'); } else toast("Too far gone — you need a Serum.", 'bad'); }
}
function onPlayerDeath(){
 S.hp = 0;
 renderEnding('bad', true);
 Game.goto('ending');
}

function damageEntity(ent, dmg, isPlayerSource){
 ent.hp -= dmg;
 if(ent.hp<=0) killEntity(ent, isPlayerSource);
}
function killEntity(ent, isPlayerSource){
 if(ent.kind==='zombie'){
  W.zombies = W.zombies.filter(z=>z!==ent);
  if(isPlayerSource){
   S.kills++;
   if(S.currentLocation==='camp') S.campKills++;
   gainXP(8 + findLocation(S.currentLocation).tier*2);
   if(S.kills===1) unlockAchievement('first_blood');
   if(S.kills>=50) unlockAchievement('exterminator');
   if(S.campKills>=20) unlockAchievement('camp_defender');
   progressQuestKill();
   progressSideKillQuests('zombie');
  }
 } else if(ent.kind==='bandit'){
  W.bandits = W.bandits.filter(b=>b!==ent);
  if(isPlayerSource){
   S.banditKills++;
   gainXP(ent.banditType==='elite'?40:(ent.banditType==='ranged'?18:15));
   if(S.banditKills>=25) unlockAchievement('bandit_hunter');
   progressSideKillQuests('bandit');
  }
 } else if(ent.kind==='boss'){
  W.boss = null;
  onBossDefeated();
 }
}
function progressQuestKill(){
 if(S.questsMain.m2 && S.questsMain.m2.status==='active' && S.currentLocation==='camp'){
  S.questsMain.m2.progress++;
  if(S.questsMain.m2.progress>=MAIN_QUESTS.m2.target){ S.questsMain.m2.status='done'; activateNextQuests(); toast('Objective complete: Camp Fire', 'amber'); }
 }
}

/* ================= XP / LEVEL / SKILLS ================= */
function gainXP(n){
 if(S.role==='Citizen') n = Math.round(n*1.1);
 S.xp += n;
 while(S.xp>=S.xpNext && S.level<MAX_LEVEL){
  S.xp -= S.xpNext; S.level++; S.skillPoints++; S.xpNext = xpToNext(S.level);
  toast('Level up! Now level '+S.level, 'amber');
  if(S.level>=25) unlockAchievement('hardened_survivor');
 }
 updateHudDynamic();
}
function unlockSkill(id){
 let node=null;
 for(const branch in SKILL_TREE){ const f = SKILL_TREE[branch].find(n=>n.id===id); if(f){node=f;break;} }
 if(!node || S.skills[id]) return;
 if(node.req && !S.skills[node.req]){ toast('Requires a prerequisite skill.', 'bad'); return; }
 if(S.skillPoints<node.cost){ toast('Not enough skill points.', 'bad'); return; }
 S.skillPoints -= node.cost; S.skills[id]=true;
 if(id==='thick_skin') S.maxHp += 20;
 if(id==='packmule') S.carryCap += 15;
 toast('Unlocked: '+node.name, 'amber');
 renderSkillsModal(); updateHudDynamic();
}

/* ================= ACHIEVEMENTS ================= */
function unlockAchievement(id){
 if(S.achievements[id]) return;
 S.achievements[id] = true;
 const a = ACHIEVEMENTS.find(x=>x.id===id);
 toast('Achievement: '+(a?a.name:id), 'amber');
}
function checkAchievements(){
 if(carryWeight(S)>=40) unlockAchievement('pack_rat');
 if(S.charisma>=15) unlockAchievement('silver_tongue');
 if(S.karma>=30) unlockAchievement('good_samaritan');
 if(S.karma<=-15) unlockAchievement('hard_case');
 const rangedOwned = new Set();
 Object.values(S.weaponSlots).forEach(w=>{ if(w && WEAPONS_RANGED[w]) rangedOwned.add(w); });
 S.inventory.forEach(i=>{ if(WEAPONS_RANGED[i.id]) rangedOwned.add(i.id); });
 if(rangedOwned.size>=5) unlockAchievement('armory_complete');
 const journalCount = Object.keys(S.journalPages).length;
 if(journalCount>=1) unlockAchievement('first_page');
 if(journalCount>=JOURNAL_PAGES.length) unlockAchievement('complete_journal');
 const sideDone = Object.values(S.questsSide).filter(q=>q.status==='done').length;
 if(sideDone>=10) unlockAchievement('side_hustler');
}

/* ================= QUESTS ================= */
function activateNextQuests(){
 const order = ['m1','m2','m5','m6','m7','m8'];
 for(const id of order){
  const q = S.questsMain[id];
  if(q.status==='locked'){
   if(id==='m1'){ q.status='active'; }
   else if(id==='m2' && S.questsMain.m1.status==='done'){ q.status='active'; }
   else if(id==='m5' && S.questsMain.m2.status==='done'){ q.status='active'; }
   else if(id==='m6' && S.questsMain.m2.status==='done'){ q.status='active'; }
   else if(id==='m7' && S.flags.hospital_choice_done && S.flags.warehouse_choice_done){ q.status='active'; }
   else if(id==='m8' && S.flags.boss_pending){ q.status='active'; }
   break;
  }
 }
 for(const id in S.questsSide){
  if(S.questsSide[id].status==='locked') S.questsSide[id].status='active';
 }
 renderQuestsModal();
}
function completeQuestByFlag(flag){
 for(const id in S.questsMain){ if(MAIN_QUESTS[id].flag===flag && S.questsMain[id].status==='active'){ S.questsMain[id].status='done'; } }
 for(const id in S.questsSide){ if(SIDE_QUESTS[id].flag===flag && S.questsSide[id].status==='active'){ S.questsSide[id].status='done'; } }
 activateNextQuests();
}
function progressLootQuest(){
 if(S.questsMain.m1 && S.questsMain.m1.status==='active'){
  S.questsMain.m1.progress++;
  if(S.questsMain.m1.progress>=MAIN_QUESTS.m1.target){ S.questsMain.m1.status='done'; activateNextQuests(); toast('Objective complete: First Light', 'amber'); }
 }
}

/* ================= LOOT ================= */
const LOOT_TABLE = {
 1:[['ammo_mm9','ammo',6],['bandage','med',3],['jerky','food',3],['bread','food',3],['popcola','drink',3],['knife','weapon_melee',1]],
 2:[['ammo_rifle','ammo',5],['medkit','med',2],['chips','food',3],['protein','food',2],['nukacola','drink',2],['ninemm','weapon_ranged',1]],
 3:[['ammo_shells','ammo',4],['antibiotics','med',1],['rice','food',2],['royal','drink',2],['ak47','weapon_ranged',1],['civilian','armor',1],['revolver','weapon_ranged',1]],
 4:[['ammo_rocket','ammo',2],['medkit','med',2],['megacrusher','drink',2],['fitz','drink',2],['spas12','weapon_ranged',1],['hunter','armor',1],['scar','weapon_ranged',1],['m1garand','weapon_ranged',1]]
};
const SPECIAL_FIND_NAMES = {
 vault_cracked:'the bank vault open', quarantine_files:'the quarantine files', black_box:"the aircraft's black box", diplomatic_pouch:'a sealed diplomatic pouch'
};
let lootPending = null; // {items:[{id,kind,qty,rare}], tokens}
function lootCrate(crate){
 if(crate.looted) return;
 if(crate.kind==='journal'){
  crate.looted = true;
  const page = findJournalPage(crate.pageId);
  S.journalPages[crate.pageId] = true;
  toast('Journal page found: '+(page?page.title:'???'), 'amber');
  progressJournalQuest();
  checkAchievements();
  return;
 }
 if(crate.kind==='special'){
  crate.looted = true;
  const flag = crate.flag;
  if(flag==='boss_arena'){ S.flags.boss_pending=true; openDialogue('boss_intro'); }
  else {
   S.flags[flag] = true;
   toast('You find '+(SPECIAL_FIND_NAMES[flag]||'something important')+'.', 'amber');
   completeQuestByFlag(flag);
  }
  activateNextQuests();
  return;
 }
 crate.looted = true;
 const loc = findLocation(S.currentLocation);
 const table = LOOT_TABLE[loc.lootTier] || LOOT_TABLE[1];
 const rolls = randInt(1,2) + (S.skills.scavenger?1:0);
 const items = [];
 for(let i=0;i<rolls;i++){
  const entry = pick(table);
  let [id,kind,maxQty] = entry;
  let qty = kind==='ammo' ? randInt(4,12) : randInt(1,maxQty);
  items.push({id,kind,qty});
 }
 if(Math.random()<0.03) items.push({id:'serum',kind:'med',qty:1,rare:true});
 openLootPanel(items, randInt(0,4));
}
function openLootPanel(items, tokens){
 lootPending = {items, tokens};
 Game.showModal('loot');
 const body = document.getElementById('loot-body');
 const takeAllBtn = document.getElementById('loot-takeall');
 if(body) body.innerHTML = '<div class="loot-loading"><div class="loot-spinner"></div><div>Searching...</div></div>';
 if(takeAllBtn) takeAllBtn.style.display='none';
 setTimeout(renderLootPanel, 650);
}
function renderLootPanel(){
 const body = document.getElementById('loot-body');
 const takeAllBtn = document.getElementById('loot-takeall');
 if(!body || !lootPending) return;
 body.innerHTML = '';
 const hasItems = lootPending.items.length>0;
 const hasTokens = lootPending.tokens>0;
 if(takeAllBtn) takeAllBtn.style.display = (hasItems||hasTokens) ? '' : 'none';
 if(!hasItems && !hasTokens){
  body.innerHTML = '<div class="inv-empty">Nothing left in here.</div>';
  return;
 }
 if(hasTokens){
  const row = document.createElement('div'); row.className='loot-row';
  row.innerHTML = `<span class="loot-ic"><span class="icon-emoji">🪙</span></span><span class="loot-nm">Tokens</span><span class="loot-qty">×${lootPending.tokens}</span>`;
  const btn = document.createElement('button'); btn.className='btn btn-small'; btn.textContent='Take';
  btn.onclick = ()=>{ S.tokens += lootPending.tokens; lootPending.tokens = 0; updateHudDynamic(); renderLootPanel(); };
  row.appendChild(btn); body.appendChild(row);
 }
 lootPending.items.forEach((it,idx)=>{
  const isEquippable = it.kind==='armor' || it.kind==='backpack';
  const row = document.createElement('div'); row.className='loot-row'+(it.kind==='armor'?' loot-set':'');
  row.innerHTML = `<span class="loot-ic">${itemIcon(it.id,it.kind)}</span><span class="loot-nm">${itemDisplayName(it.id)}${it.rare?' <b class="loot-rare">RARE</b>':''}${isEquippable?' <span class="loot-hint">(right-click to equip)</span>':''}</span><span class="loot-qty">×${Math.round(it.qty)}</span>`;
  const btn = document.createElement('button'); btn.className='btn btn-small'; btn.textContent='Take';
  btn.onclick = ()=> takeLootItem(idx);
  row.appendChild(btn);
  if(isEquippable) row.oncontextmenu = (e)=>{ e.preventDefault(); showLootCtxMenu(e, idx); };
  body.appendChild(row);
 });
}
function takeLootItem(idx){
 if(!lootPending) return;
 const it = lootPending.items[idx]; if(!it) return;
 if(it.kind==='weapon_melee'||it.kind==='weapon_ranged'||it.kind==='weapon_throwable'){
  giveWeaponItem(S, it.id); toast('Took '+findWeaponById(it.id).name, 'amber');
 } else {
  addToInventory(S, it.id, it.kind, it.qty);
  toast('Took '+Math.round(it.qty)+'x '+itemDisplayName(it.id), 'amber');
 }
 lootPending.items.splice(idx,1);
 progressLootQuest(); progressLootAtQuests(S.currentLocation); checkAchievements();
 renderInventoryModal(); renderWeaponSlots();
 renderLootPanel();
}
function takeAllLoot(){
 if(!lootPending) return;
 if(lootPending.tokens>0){ S.tokens += lootPending.tokens; lootPending.tokens = 0; }
 [...lootPending.items].forEach(it=>{
  if(it.kind==='weapon_melee'||it.kind==='weapon_ranged'||it.kind==='weapon_throwable'){ giveWeaponItem(S, it.id); }
  else addToInventory(S, it.id, it.kind, it.qty);
 });
 lootPending.items = [];
 progressLootQuest(); progressLootAtQuests(S.currentLocation); checkAchievements();
 renderInventoryModal(); renderWeaponSlots(); updateHudDynamic();
 toast('Took everything.', 'amber');
 renderLootPanel();
}
function showLootCtxMenu(e, idx){
 closeLootCtxMenu();
 if(!lootPending) return;
 const it = lootPending.items[idx]; if(!it) return;
 const host = document.getElementById('modal-loot');
 const rect = host.getBoundingClientRect();
 const menu = document.createElement('div'); menu.id='loot-ctx-menu'; menu.className='loot-ctx-menu';
 menu.style.left = Math.max(4, e.clientX - rect.left) + 'px';
 menu.style.top = Math.max(4, e.clientY - rect.top) + 'px';
 const btn = document.createElement('button');
 btn.textContent = it.kind==='armor' ? 'Equip Set' : 'Equip Backpack';
 btn.onclick = ()=>{
  addToInventory(S, it.id, it.kind, 1);
  if(it.kind==='armor') equipArmor(S, it.id); else equipBackpack(S, it.id);
  it.qty -= 1;
  if(it.qty<=0) lootPending.items.splice(idx,1);
  closeLootCtxMenu();
  renderInventoryModal(); renderLootPanel();
 };
 menu.appendChild(btn);
 host.appendChild(menu);
 setTimeout(()=> document.addEventListener('click', closeLootCtxMenu, {once:true}), 0);
}
function closeLootCtxMenu(){ const m=document.getElementById('loot-ctx-menu'); if(m) m.remove(); }
function progressLootAtQuests(locId){
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id];
  const st = S.questsSide[id];
  if(def.type==='loot_at' && def.locHint===locId && st.status==='active'){
   st.progress++;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); }
   renderQuestsModal();
  }
 }
}
function progressJournalQuest(){
 const count = Object.keys(S.journalPages).length;
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id]; const st = S.questsSide[id];
  if(def.type==='journal_count' && st.status==='active'){
   st.progress = count;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); }
  }
 }
 renderQuestsModal();
}
function progressSideKillQuests(kind){
 let changed=false;
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id]; const st = S.questsSide[id];
  if(st.status!=='active') continue;
  if((def.type==='kill_bandits' && kind==='bandit') || (def.type==='kill_total' && (kind==='bandit'||kind==='zombie'))){
   st.progress++; changed=true;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); checkAchievements(); }
  }
 }
 if(changed) renderQuestsModal();
}
function itemDisplayName(id){
 const c = findConsumableById(id); if(c) return c.name;
 if(AMMO_TYPES[id.replace('ammo_','')]) return AMMO_TYPES[id.replace('ammo_','')].name;
 const a = ARMOR[id]; if(a) return a.name;
 const b = BACKPACKS[id]; if(b) return b.name;
 const w = findWeaponById(id); if(w) return w.name;
 return id;
}

/* ================= COMBAT: MELEE ================= */
let lastAttackAt = 0;
function playerMelee(){
 const wid = S.weaponSlots.melee || 'fists';
 const w = WEAPONS_MELEE[wid];
 const now = performance.now();
 const cd = w.cooldown * (S.skills.berserker?0.85:1);
 if(now - lastAttackAt < cd) return;
 lastAttackAt = now;
 const staminaCost = w.stamina || 0;
 let fatigued = false;
 if(staminaCost>0){
  if(S.stamina < staminaCost*0.4) fatigued = true;
  S.stamina = Math.max(0, S.stamina - staminaCost);
 }
 const ang = Math.atan2(S.facing.y, S.facing.x);
 W.meleeFx.push({x:W.player.x,y:W.player.y, angle:ang, arcDeg:w.swing.arcDeg, reach:w.swing.reach, life:180, maxLife:180});
 const targets = [...W.zombies, ...W.bandits, ...(W.boss?[W.boss]:[])];
 let hitAny=false;
 targets.forEach(t=>{
  const d = dist(W.player.x,W.player.y,t.x,t.y);
  if(d>w.swing.reach+ (t.r||16)) return;
  const a2 = angleTo(W.player.x,W.player.y,t.x,t.y);
  if(Math.abs(angleDiff(ang,a2)) > (w.swing.arcDeg*Math.PI/180)/2) return;
  if(!w.cleave && hitAny) return;
  let dmg = w.dmg * meleeDamageMult() * (fatigued?0.6:1);
  if(S.skills.executioner && t.hp/t.maxHp < 0.25) dmg *= 1.25;
  damageEntity(t, dmg, true);
  hitAny=true;
 });
}

/* ================= COMBAT: RANGED ================= */
function playerRanged(){
 const slot = S.activeSlot;
 const wid = S.weaponSlots[slot];
 if(!wid){ toast('Nothing equipped there.', 'bad'); return; }
 const w = WEAPONS_RANGED[wid];
 const now = performance.now();
 if(S.reloadingSlot===slot) return;
 if(!w._lastFire) w._lastFire=0;
 if(now - w._lastFire < w.cooldown) return;
 if((S.magAmmo[slot]||0) <= 0){ toast('Out of ammo — press R to reload.', 'bad'); return; }
 w._lastFire = now;
 if(!(S.skills.ammo_efficiency && Math.random()<0.12)) S.magAmmo[slot]--;
 let spread = w.spread * (S.skills.steady_aim?0.75:1) * (S.companions.includes('john')?0.92:1);
 const ang = Math.atan2(S.facing.y,S.facing.x) + rand(-spread,spread)*Math.PI/180;
 W.projectiles.push({
  x:W.player.x, y:W.player.y, vx:Math.cos(ang)*w.pspeed, vy:Math.sin(ang)*w.pspeed,
  dmg:w.dmg*rangedDamageMult(wid), life:w.range/w.pspeed*1000, owner:'player', splash:w.splash||0
 });
 renderAmmoHud();
}
function reloadActive(){
 const slot = S.activeSlot;
 const wid = S.weaponSlots[slot];
 if(!wid || !WEAPONS_RANGED[wid]) return;
 const w = WEAPONS_RANGED[wid];
 if(S.magAmmo[slot]>=w.mag){ return; }
 const have = findInv(S, 'ammo_'+w.ammo);
 if(!have || have.qty<=0){ toast('No '+AMMO_TYPES[w.ammo].name+' in reserve.', 'bad'); return; }
 S.reloadingSlot = slot;
 const reloadMs = w.reload * (S.skills.quick_hands?0.8:1);
 S.reloadEndsAt = performance.now()+reloadMs;
 toast('Reloading...', 'amber');
 setTimeout(()=>{
  if(S.reloadingSlot!==slot) return;
  const need = w.mag - S.magAmmo[slot];
  const avail = findInv(S,'ammo_'+w.ammo);
  const take = Math.min(need, avail?avail.qty:0);
  S.magAmmo[slot]+= take;
  removeFromInventory(S, 'ammo_'+w.ammo, take);
  S.reloadingSlot = null;
  renderAmmoHud(); renderInventoryModal();
 }, reloadMs);
}
function throwActive(){
 const wid = S.weaponSlots.throwable;
 if(!wid) { toast('No throwable equipped.', 'bad'); return; }
 const inv = findInv(S, wid);
 if(!inv || inv.qty<=0){ toast('Out of '+WEAPONS_THROWABLE[wid].name+'.', 'bad'); return; }
 removeFromInventory(S, wid, 1);
 const w = WEAPONS_THROWABLE[wid];
 const ang = Math.atan2(S.facing.y,S.facing.x);
 W.projectiles.push({x:W.player.x,y:W.player.y, vx:Math.cos(ang)*380, vy:Math.sin(ang)*380, dmg:w.dmg, life:w.fuse||900, owner:'player', splash:w.splash*(S.skills.demolitionist?1.25:1), throwableFx:true});
 renderWeaponSlots();
}

/* ================= UPDATE LOOP ================= */
function update(dt){
 // day/night clock
 S.gameMinutes += dt*(1440/DAY_LENGTH_MS);
 if(S.gameMinutes>=1440){ S.gameMinutes-=1440; S.dayCount++; }

 const sprinting = KEYS['shift'] && S.stamina>0.5;
 const spd = 2.6 * (sprinting?1.6*(S.skills.sprinter?1.1:1):1);
 let dx=0,dy=0;
 if(KEYS['w']) dy-=1; if(KEYS['s']) dy+=1; if(KEYS['a']) dx-=1; if(KEYS['d']) dx+=1;
 if(dx||dy){
  const len=Math.hypot(dx,dy); dx/=len; dy/=len;
  S.facing = {x:dx,y:dy};
  let nx = W.player.x+dx*spd*(dt/16), ny = W.player.y+dy*spd*(dt/16);
  W.player.x = clamp(nx,20,W.w-20); W.player.y = clamp(ny,20,W.h-20);
  if(sprinting){ S.stamina = Math.max(0,S.stamina - dt*0.02*(S.skills.light_feet?0.85:1)); }
 }
 resolvePlayerCollisions();
 if(!sprinting || !(dx||dy)){
  S.stamina = Math.min(S.maxStamina, S.stamina + dt*0.012*applyBuffMult('staminaRegen',1)*(S.skills.fleet_footed?1.2:1));
 }

 // hunger/thirst
 const decayMult = S.skills.iron_gut?0.75:1;
 S.hunger = Math.max(0, S.hunger - dt*0.00045*decayMult);
 S.thirst = Math.max(0, S.thirst - dt*0.0006*decayMult);
 if(S.hunger<=0 || S.thirst<=0) S.hp -= dt*0.0015;

 // status ticking
 if(S.status.bleeding>0){ S.status.bleeding -= dt; S.hp -= dt*0.0016; }
 if(S.status.sick>0){ S.status.sick -= dt; }
 if(S.status.infected>0){
  S.status._timer = (S.status._timer||0) + dt;
  const growRate = S.skills.iron_lungs?9000:6300;
  if(S.status._timer>growRate){ S.status._timer=0; S.status.infectedSeverity = Math.min(4,S.status.infectedSeverity+1); }
  S.hp -= dt*0.0006*S.status.infectedSeverity;
 }
 // buffs expiry
 const nowT = performance.now();
 S.buffs = S.buffs.filter(b=> b.expiresAt>nowT );

 if(S.hp<=0){ onPlayerDeath(); return; }

 // camp defense spawner
 if(S.currentLocation==='camp'){
  W.campSpawnCd -= dt;
  if(W.campSpawnCd<=0 && W.zombies.length<5){
   W.campSpawnCd = 9000;
   const loc = findLocation('camp');
   const z = spawnZombie(loc); z.x = pick([20,W.w-20]); z.y = rand(20,W.h-20);
   W.zombies.push(z);
  }
 }

 updateEnemies(dt);
 updateCompanionsEnt(dt);
 updateProjectiles(dt);
 W.meleeFx.forEach(f=> f.life-=dt); W.meleeFx = W.meleeFx.filter(f=>f.life>0);
 W.explosionFx.forEach(f=> f.life-=dt); W.explosionFx = W.explosionFx.filter(f=>f.life>0);

 if(S.reloadingSlot) { /* handled via setTimeout */ }
 updateHudDynamic();
}
/* Push-out collision: the player is treated as a circle and shoved to the nearest
   clear point outside every overlapping prop, every single frame. Unlike a simple
   "block the move" check, this can never leave the survivor permanently frozen —
   even if they somehow end up overlapping geometry (e.g. spawn point, a pushed
   sequence of props), the very next frame resolves them back out. */
const PLAYER_RADIUS = 16;
function resolvePlayerCollisions(){
 for(const p of W.props){
  const cx = clamp(W.player.x, p.x, p.x+p.w);
  const cy = clamp(W.player.y, p.y, p.y+p.h);
  const dx = W.player.x-cx, dy = W.player.y-cy;
  const distSq = dx*dx+dy*dy;
  if(distSq < PLAYER_RADIUS*PLAYER_RADIUS){
   const d = Math.sqrt(distSq);
   if(d < 0.0001){
    // player center is exactly inside/on the rect boundary line — push out along
    // whichever axis has the smaller overlap so there's no divide-by-zero jitter.
    const overlapLeft = W.player.x-p.x, overlapRight = (p.x+p.w)-W.player.x;
    const overlapTop = W.player.y-p.y, overlapBottom = (p.y+p.h)-W.player.y;
    const min = Math.min(overlapLeft,overlapRight,overlapTop,overlapBottom);
    if(min===overlapLeft) W.player.x = p.x - PLAYER_RADIUS;
    else if(min===overlapRight) W.player.x = p.x+p.w + PLAYER_RADIUS;
    else if(min===overlapTop) W.player.y = p.y - PLAYER_RADIUS;
    else W.player.y = p.y+p.h + PLAYER_RADIUS;
   } else {
    const push = (PLAYER_RADIUS-d) + 0.5;
    W.player.x += (dx/d)*push;
    W.player.y += (dy/d)*push;
   }
  }
 }
 W.player.x = clamp(W.player.x, 20, W.w-20);
 W.player.y = clamp(W.player.y, 20, W.h-20);
}
function updateEnemies(dt){
 const aggroRangeBase = 220 * (S.skills.silent_steps?0.75:1);
 W.zombies.forEach(z=>{
  const d = dist(z.x,z.y,W.player.x,W.player.y);
  if(d<aggroRangeBase) z.aggro=true;
  if(z.aggro){
   const a = angleTo(z.x,z.y,W.player.x,W.player.y);
   if(d>26){ z.x += Math.cos(a)*z.speed*(dt/16); z.y += Math.sin(a)*z.speed*(dt/16); }
   else { z.atkCd-=dt; if(z.atkCd<=0){ z.atkCd=900; damagePlayer(z.dmg,'zombie'); } }
  }
 });
 W.bandits.forEach(b=>{
  const d = dist(b.x,b.y,W.player.x,W.player.y);
  if(d<300) b.aggro=true;
  if(!b.aggro) return;
  const a = angleTo(b.x,b.y,W.player.x,W.player.y);
  if(b.banditType==='ranged' || (b.banditType==='elite' && d>70)){
   if(d>220){ b.x += Math.cos(a)*b.speed*(dt/16); b.y += Math.sin(a)*b.speed*(dt/16); }
   else if(d<140){ b.x -= Math.cos(a)*b.speed*0.6*(dt/16); b.y -= Math.sin(a)*b.speed*0.6*(dt/16); }
   b.fireCd -= dt;
   if(b.fireCd<=0 && d<320){
    b.fireCd = 1100;
    W.projectiles.push({x:b.x,y:b.y, vx:Math.cos(a)*520, vy:Math.sin(a)*520, dmg:b.dmg, life:900, owner:'enemy'});
   }
  } else {
   if(d>28){ b.x += Math.cos(a)*b.speed*(dt/16); b.y += Math.sin(a)*b.speed*(dt/16); }
   else { b.atkCd-=dt; if(b.atkCd<=0){ b.atkCd=800; damagePlayer(b.dmg,'melee'); } }
  }
 });
 if(W.boss){
  const b=W.boss; const d=dist(b.x,b.y,W.player.x,W.player.y); const a=angleTo(b.x,b.y,W.player.x,W.player.y);
  if(d>50){ b.x+=Math.cos(a)*b.speed*(dt/16); b.y+=Math.sin(a)*b.speed*(dt/16); }
  else { b.atkCd-=dt; if(b.atkCd<=0){ b.atkCd=1000; damagePlayer(b.dmg,'melee'); } }
  document.getElementById('bossfill').style.width = Math.max(0,(b.hp/b.maxHp*100))+'%';
 }
}
function updateCompanionsEnt(dt){
 if(!W.companionsEnt) return;
 W.companionsEnt.forEach(c=>{
  if(c.isCampStatic) return; // stands at camp for chat/recruit only, no AI
  const d = dist(c.x,c.y,W.player.x,W.player.y);
  if(d>90){ const a=angleTo(c.x,c.y,W.player.x,W.player.y); c.x+=Math.cos(a)*1.6*(dt/16); c.y+=Math.sin(a)*1.6*(dt/16); }
  const targets=[...W.zombies,...W.bandits, ...(W.boss?[W.boss]:[])];
  if(!targets.length) return;
  let nearest=null,nd=9999;
  targets.forEach(t=>{ const dd=dist(c.x,c.y,t.x,t.y); if(dd<nd){nd=dd;nearest=t;} });
  const w = WEAPONS_RANGED[c.weapon];
  if(nearest && w && nd<w.range){
   c.atkCd -= dt;
   const cd = w.cooldown*3*(S.companions.includes('nikolai')?0.9:1);
   if(c.atkCd<=0){
    c.atkCd=cd;
    const a = angleTo(c.x,c.y,nearest.x,nearest.y);
    W.projectiles.push({
     x:c.x, y:c.y, vx:Math.cos(a)*w.pspeed, vy:Math.sin(a)*w.pspeed,
     dmg:w.dmg*0.5, life:w.range/w.pspeed*1000, owner:'companion', color:c.color
    });
   }
  }
 });
}
function updateProjectiles(dt){
 const remain=[];
 W.projectiles.forEach(p=>{
  p.x += p.vx*(dt/1000); p.y += p.vy*(dt/1000); p.life -= dt;
  let hit=false;
  if(p.owner==='player' || p.owner==='companion'){
   const targets=[...W.zombies,...W.bandits, ...(W.boss?[W.boss]:[])];
   for(const t of targets){ if(dist(p.x,p.y,t.x,t.y) < (t.r||16)){ 
     if(p.splash>0){ explode(p.x,p.y,p.splash,p.dmg); } else damageEntity(t,p.dmg,true);
     hit=true; break; } }
  } else {
   if(dist(p.x,p.y,W.player.x,W.player.y) < 18){ damagePlayer(p.dmg,'ranged'); hit=true; }
  }
  if(!hit && p.life>0 && p.x>0 && p.x<W.w && p.y>0 && p.y<W.h) remain.push(p);
  else if(!hit && p.throwableFx && p.life<=0){ explode(p.x,p.y,p.splash,p.dmg); }
 });
 W.projectiles = remain;
}
function explode(x,y,radius,dmg){
 W.explosionFx.push({x,y,radius,life:260,maxLife:260});
 [...W.zombies,...W.bandits, ...(W.boss?[W.boss]:[])].forEach(t=>{
  if(dist(x,y,t.x,t.y)<=radius) damageEntity(t,dmg,true);
 });
 if(dist(x,y,W.player.x,W.player.y)<=radius*0.6) damagePlayer(dmg*0.4,'blast');
}

/* ================= INTERACT ================= */
function interact(){
 if(!W) return;
 for(const c of W.crates){
  if(!c.looted && dist(c.x,c.y,W.player.x,W.player.y)<46){ lootCrate(c); return; }
 }
 for(const n of W.npcs){
  if(dist(n.x,n.y,W.player.x,W.player.y)<50){
   if(n.dialogue){ openDialogue(n.dialogue, n); return; }
   if(n.trade){ openDialogue('joe_intro', n); return; }
  }
 }
 if(W.companionsEnt) for(const c of W.companionsEnt){
  if(dist(c.x,c.y,W.player.x,W.player.y)<50){ openDialogue('companion_'+c.id, c); return; }
 }
 for(const c2 of COMPANIONS){
  if(S.currentLocation==='camp' && !W.companionsEnt.some(e=>e.id===c2.id)){
   // uninvited companions still stand around camp for recruitment dialogue
  }
 }
}

/* ================= DIALOGUE ================= */
function openDialogue(id, npc){
 dlgState = {tree:id, node:'start', npc};
 document.getElementById('dialogue').style.display='block';
 renderDialogueNode();
}
function resolveText(t){ return typeof t==='function' ? t(S) : t; }
function renderDialogueNode(){
 const tree = DIALOGUES[dlgState.tree]; if(!tree) return;
 const node = tree[dlgState.node]; if(!node) return;
 document.getElementById('dlg-who').textContent = resolveText(node.who);
 document.getElementById('dlg-txt').textContent = resolveText(node.text);
 const wrap = document.getElementById('dlg-opts'); wrap.innerHTML='';
 (node.opts||[]).forEach((o,i)=>{
  if(o.showIf && !o.showIf(S)) return;
  const b = document.createElement('button');
  b.className='dlg-opt';
  b.innerHTML = (o.tag?`<span class="tag">${o.tag}</span>`:'') + resolveText(o.label);
  b.onclick = ()=>chooseOption(o);
  wrap.appendChild(b);
 });
}
function chooseOption(o){
 if(o.cha) S.charisma += o.cha;
 if(o.karma) S.karma += o.karma;
 if(o.trust && dlgState.tree.startsWith('companion_')){
  const cid = dlgState.tree.replace('companion_','');
  S.companionTrust[cid] = (S.companionTrust[cid]||0) + o.trust;
  if(Object.values(S.companionTrust).filter(v=>v>=3).length>=S.companions.length && S.companions.length>0){
   /* trust-based flavor only, no hard gate */
  }
 }
 if(o.action){ runDialogueAction(o.action, dlgState.npc); }
 if(o.ending){ resolveEnding(o.ending); document.getElementById('dialogue').style.display='none'; return; }
 if(o.next){ dlgState.node=o.next; renderDialogueNode(); }
 else { document.getElementById('dialogue').style.display='none'; dlgState=null; }
}
function grantRandomSurvivorReward(){
 const roll = Math.random();
 if(roll<0.4){
  const amt = randInt(20,55);
  S.tokens += amt;
  return amt+' Tokens';
 }
 if(roll<0.75){
  const pool = ['bandage','medkit','jerky','bread','popcola','nukacola','protein','mre'];
  const id = pool[Math.floor(Math.random()*pool.length)];
  const qty = randInt(1,3);
  addToInventory(S, id, consumableKind(id), qty);
  return qty+'x '+itemDisplayName(id);
 }
 const pool = ['knife','wrench','bat','ninemm'];
 const id = pool[Math.floor(Math.random()*pool.length)];
 giveWeaponItem(S, id);
 return itemDisplayName(id);
}
function trySurvivorTurnin(npcId){
 const n = SURVIVOR_NPCS.find(x=>x.id===npcId);
 if(!n) return;
 if(S.flags['survivor_done_'+npcId]){ toast('Already helped them out.', 'bad'); return; }
 const have = findInv(S, n.want.id);
 if(!have || have.qty < n.want.qty){ toast("You don't have "+n.want.label+" yet.", 'bad'); return; }
 removeFromInventory(S, n.want.id, n.want.qty);
 S.karma += 5;
 const rewardText = grantRandomSurvivorReward();
 S.flags['survivor_done_'+npcId] = true;
 toast(n.name+' thanks you. (+5 Karma, +'+rewardText+')', 'amber');
 progressCommunityAidQuest();
 checkAchievements();
 renderInventoryModal();
 updateHudDynamic();
}
function progressCommunityAidQuest(){
 const count = SURVIVOR_NPCS.filter(n=>S.flags['survivor_done_'+n.id]).length;
 for(const id in S.questsSide){
  const def = SIDE_QUESTS[id]; const st = S.questsSide[id];
  if(def.type==='community_aid' && st.status==='active'){
   st.progress = count;
   if(st.progress>=def.target){ st.status='done'; toast('Objective complete: '+def.title, 'amber'); checkAchievements(); }
  }
 }
 renderQuestsModal();
}
function giveSuppliesForPeace(){
 const eligible = S.inventory.filter(i=> i.kind!=='weapon_melee' && i.kind!=='weapon_ranged' && i.kind!=='armor' && i.kind!=='backpack');
 let takenAny = false;
 const rounds = Math.min(2, eligible.length);
 for(let i=0;i<rounds;i++){
  if(!eligible.length) break;
  const idx = Math.floor(Math.random()*eligible.length);
  const it = eligible[idx];
  const take = Math.min(it.qty, randInt(1, Math.max(1, Math.ceil(it.qty/2))));
  removeFromInventory(S, it.id, take);
  takenAny = true;
  eligible.splice(idx,1);
 }
 S.karma += 4;
 S.flags.warehouse_choice = 'peace';
 S.flags.warehouse_choice_done = true;
 toast(takenAny ? "You hand over some supplies. Truce. (+4 Karma)" : "Kade takes the truce even though you've got nothing to give. (+4 Karma)", 'amber');
 completeQuestByFlag('warehouse_choice');
 renderInventoryModal();
}
function runDialogueAction(action, npc){
 if(action.startsWith('recruit_')){ recruitCompanion(action.slice(8)); return; }
 if(action.startsWith('survivor_meet_')){ S.flags['survivor_met_'+action.slice(14)] = true; return; }
 if(action.startsWith('survivor_turnin_')){ trySurvivorTurnin(action.slice(17)); return; }
 switch(action){
  case 'open_trade': S.tradeContext='camp'; document.getElementById('dialogue').style.display='none'; Game.showModal('trade'); break;
  case 'open_trade_blockade': S.tradeContext='blockade'; document.getElementById('dialogue').style.display='none'; Game.showModal('trade'); break;
  case 'hospital_save': S.karma+=8; S.flags.hospital_choice='save'; S.flags.hospital_choice_done=true; toast("Dr. Voss will join the camp's medical staff.", 'amber'); completeQuestByFlag('hospital_choice'); break;
  case 'hospital_abandon': S.karma-=8; S.flags.hospital_choice='abandon'; S.flags.hospital_choice_done=true; toast('You leave him behind.', 'bad'); completeQuestByFlag('hospital_choice'); break;
  case 'warehouse_fight': S.flags.warehouse_choice='fight'; S.flags.warehouse_choice_done=true; W.bandits.push(spawnBandit(findLocation('warehouse'),'elite'), spawnBandit(findLocation('warehouse'),'melee')); toast('Kade\'s crew opens fire!', 'bad'); completeQuestByFlag('warehouse_choice'); break;
  case 'warehouse_peace': giveSuppliesForPeace(); break;
  case 'warehouse_corrupt': S.karma-=6; S.tokens+=15; S.flags.warehouse_choice='corrupt'; S.flags.warehouse_choice_done=true; toast('Tokens change hands quietly.', 'bad'); completeQuestByFlag('warehouse_choice'); break;
  case 'ruins_expose': S.karma+=5; S.flags.bad_trade='expose'; toast('You call Milo out.', 'amber'); completeQuestByFlag('bad_trade'); break;
  case 'ruins_ignore': S.karma-=3; S.tokens+=10; S.flags.bad_trade='ignore'; toast('You keep quiet.', 'bad'); completeQuestByFlag('bad_trade'); break;
  case 'ghost_easter_egg': addToInventory(S,'pillow','weapon_melee',1); S.flags.ghost_story='found'; toast('You take the pillow.', 'amber'); completeQuestByFlag('ghost_story'); break;
  case 'start_boss': document.getElementById('dialogue').style.display='none'; spawnBoss(); break;
 }
 checkAchievements();
}

/* ================= HUD SYNC ================= */
function updateHudLocation(){
 const loc = findLocation(S.currentLocation);
 document.getElementById('hud-loc').textContent = loc.name;
 document.getElementById('hud-danger').textContent = 'DANGER: '+loc.danger;
 document.getElementById('hud-name').textContent = S.name.toUpperCase();
}
function fmtClock(min){
 const h = Math.floor(min/60)%24, m = Math.floor(min%60);
 return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
}
function updateHudDynamic(){
 if(!S) return;
 document.getElementById('v-hp').style.width = clamp(S.hp/S.maxHp*100,0,100)+'%';
 document.getElementById('v-stam').style.width = clamp(S.stamina/S.maxStamina*100,0,100)+'%';
 document.getElementById('v-hunger').style.width = clamp(S.hunger,0,100)+'%';
 document.getElementById('v-thirst').style.width = clamp(S.thirst,0,100)+'%';
 document.getElementById('hud-lvl').textContent = S.level+(S.level>=MAX_LEVEL?' (MAX)':'');
 document.getElementById('hud-xp').style.width = clamp(S.xp/S.xpNext*100,0,100)+'%';
 const xpText = document.getElementById('hud-xp-text');
 if(xpText) xpText.textContent = S.level>=MAX_LEVEL ? 'MAX LEVEL' : (Math.floor(S.xp)+' / '+S.xpNext+' XP');
 document.getElementById('hud-cha').textContent = S.charisma;
 const karEl = document.getElementById('hud-kar');
 karEl.textContent = (S.karma>=0?'+':'')+S.karma;
 karEl.style.color = S.karma>0?'var(--toxin)':(S.karma<0?'var(--blood-bright)':'var(--bone)');
 document.getElementById('hud-tok').textContent = S.tokens;
 document.getElementById('hud-kills').textContent = S.kills+S.banditKills;
 const spRow = document.getElementById('hud-sp-row');
 if(spRow){ spRow.style.display = S.skillPoints>0 ? 'flex' : 'none'; document.getElementById('hud-sp').textContent = S.skillPoints; }
 document.getElementById('hud-clock').textContent = 'DAY '+S.dayCount+' · '+fmtClock(S.gameMinutes);
 renderStatusIcons();
 renderAmmoHud();
}
function renderStatusIcons(){
 const wrap = document.getElementById('status-icons'); if(!wrap) return;
 wrap.innerHTML='';
 const active=[];
 if(S.status.bleeding>0) active.push('bleeding');
 if(S.status.infected>0) active.push('infected');
 if(S.status.sick>0) active.push('sick');
 if(S.hunger<=0) active.push('hungry');
 if(S.thirst<=0) active.push('dehydrated');
 active.forEach(k=>{
  const d=document.createElement('div'); d.className='status-icon'; d.title=STATUS_INFO[k].name+': '+STATUS_INFO[k].desc;
  d.textContent = STATUS_INFO[k].icon; wrap.appendChild(d);
 });
}
function renderWeaponSlots(){
 const wrap = document.getElementById('weaponSlots'); wrap.innerHTML='';
 const order=[['melee','1'],['secondary','2'],['primary','3'],['rocket','4'],['throwable','5']];
 order.forEach(([slot,num])=>{
  const wid = S.weaponSlots[slot];
  const d = document.createElement('div');
  d.className='slot'+(S.activeSlot===slot?' active':'');
  d.onclick=()=>{ S.activeSlot=slot; renderWeaponSlots(); };
  const w = wid?findWeaponById(wid):null;
  d.innerHTML = `<span class="num">${num}</span>${w?`<span>${iconHtml(w.icon,w.img,16)}</span><span class="nm">${w.name}</span>`:`<span class="nm">—</span>`}`;
  wrap.appendChild(d);
 });
 renderAmmoHud();
}
function renderAmmoHud(){
 const wrap = document.getElementById('ammo-hud'); if(!wrap) return;
 wrap.innerHTML='';
 ['secondary','primary','rocket'].forEach(slot=>{
  const wid = S.weaponSlots[slot]; if(!wid) return;
  const w = WEAPONS_RANGED[wid];
  const reserve = findInv(S,'ammo_'+w.ammo); const rq = reserve?reserve.qty:0;
  const low = (S.magAmmo[slot]||0)<=0;
  const row = document.createElement('div'); row.className='ammo-row'+(low?' low':'');
  row.innerHTML = `<span>${iconHtml(w.icon,w.img,16)} ${w.name}</span><b>${S.magAmmo[slot]||0} / ${rq}</b>${low?'<span class="reload-hint">[R] RELOAD</span>':''}`;
  wrap.appendChild(row);
 });
 const twid = S.weaponSlots.throwable;
 const trow = document.getElementById('throwable-hud');
 if(trow){
  if(twid){ const inv=findInv(S,twid); trow.innerHTML = `${WEAPONS_THROWABLE[twid].icon} ${WEAPONS_THROWABLE[twid].name} × ${inv?inv.qty:0}`; }
  else trow.innerHTML = '';
 }
}

/* ================= RENDER ================= */
function facingAngle(){ return Math.atan2(S.facing.y,S.facing.x); }

/* ---- small drawing helpers shared by structures + character tokens ---- */
function roundRectPath(x,y,w,h,r){
 r = Math.min(r, Math.abs(w)/2, Math.abs(h)/2);
 ctx.moveTo(x+r,y);
 ctx.arcTo(x+w,y,x+w,y+h,r);
 ctx.arcTo(x+w,y+h,x,y+h,r);
 ctx.arcTo(x,y+h,x,y,r);
 ctx.arcTo(x,y,x+w,y,r);
 ctx.closePath();
}
function roundRect(x,y,w,h,r){ ctx.beginPath(); roundRectPath(x,y,w,h,r); }
function shadeColor(hex, percent){
 if(!hex || hex[0]!=='#') return hex;
 const num = parseInt(hex.slice(1),16);
 let r=(num>>16)+percent, g=((num>>8)&0xff)+percent, b=(num&0xff)+percent;
 r=clamp(r,0,255); g=clamp(g,0,255); b=clamp(b,0,255);
 return '#'+((1<<24)+(Math.round(r)<<16)+(Math.round(g)<<8)+Math.round(b)).toString(16).slice(1);
}
function labelTag(p){
 if(!p.label) return;
 ctx.fillStyle='rgba(220,214,189,.4)'; ctx.font='10px monospace'; ctx.fillText(p.label, p.x+4, p.y-4);
}

/* ---- character token: small human silhouette (legs, torso, head) instead of a plain circle ---- */
const WEAPON_IMG_CACHE = {};
function weaponImg(w){
 if(!w || !w.img) return null;
 if(!WEAPON_IMG_CACHE[w.img]){ const im=new Image(); im.src=w.img; WEAPON_IMG_CACHE[w.img]=im; }
 return WEAPON_IMG_CACHE[w.img];
}
/* Draws the given weapon's art in the local (already-translated) character
   space, pointing along `angle`. Returns false (and draws nothing) if the
   image isn't loaded yet, so callers can fall back to a simple stroke. */
function drawHeldWeapon(w, angle, size){
 const img = weaponImg(w);
 if(!img || !img.complete || !img.naturalWidth) return false;
 size = size||26;
 const asp = img.naturalHeight/img.naturalWidth;
 ctx.save();
 ctx.rotate(angle);
 ctx.translate(4,0);
 ctx.drawImage(img, 0, -size*asp/2, size, size*asp);
 ctx.restore();
 return true;
}
function drawCharToken(x,y,r,color,facing,extra){
 ctx.save(); ctx.translate(x,y);
 // ground shadow
 ctx.beginPath(); ctx.ellipse(0,r*0.85,r*0.9,r*0.32,0,0,Math.PI*2); ctx.fillStyle='rgba(0,0,0,.35)'; ctx.fill();
 // legs
 ctx.fillStyle='rgba(10,10,8,.55)';
 ctx.fillRect(-r*0.36,r*0.15,r*0.3,r*0.72);
 ctx.fillRect(r*0.06,r*0.15,r*0.3,r*0.72);
 // torso
 roundRect(-r*0.62,-r*0.35,r*1.24,r*0.95,r*0.32);
 ctx.fillStyle=color; ctx.fill();
 ctx.lineWidth=1.5; ctx.strokeStyle='rgba(0,0,0,.45)'; ctx.stroke();
 // head
 ctx.beginPath(); ctx.arc(0,-r*0.78,r*0.48,0,Math.PI*2);
 ctx.fillStyle=shadeColor(color,-20); ctx.fill();
 ctx.lineWidth=1.2; ctx.strokeStyle='rgba(0,0,0,.45)'; ctx.stroke();
 // facing direction
 if(facing){ const a=Math.atan2(facing.y,facing.x); ctx.beginPath(); ctx.moveTo(Math.cos(a)*r*0.3,Math.sin(a)*r*0.3); ctx.lineTo(Math.cos(a)*r*1.5,Math.sin(a)*r*1.5); ctx.strokeStyle='rgba(220,214,189,.9)'; ctx.lineWidth=3; ctx.stroke(); }
 if(extra) extra();
 ctx.restore();
}

/* ---- structures: each prop kit label gets a distinct silhouette instead of a flat rectangle ---- */
function drawStructure(p){
 ctx.save();
 switch(p.label){
  case 'House': drawHouse(p,false); break;
  case 'Main Building': drawHouse(p,true); break;
  case 'Camp Hall': drawHall(p,'#1c1d13','#2a2b1c'); break;
  case 'Ward': drawHall(p,'#151710','#232418'); break;
  case 'Nurse Station': drawHall(p,'#1c1d13','#2a2b1c'); break;
  case 'Terminal': drawHall(p,'#171810','#2a2a1a'); break;
  case 'Teller Row': drawHall(p,'#171810','#2a2a1a'); break;
  case 'Kitchen': drawHall(p,'#20160e','#2e2013'); break;
  case 'Tent': drawTent(p); break;
  case 'Shelving': case 'Shelf': case 'Aisle': drawShelfBlock(p); break;
  case 'Rubble': drawRubble(p); break;
  case 'Headstone': drawHeadstone(p); break;
  case 'Bus': drawBus(p); break;
  case 'Vault': drawVault(p); break;
  case 'Car': drawCar(p); break;
  case 'Barrier Fence': case 'Perimeter Fence': drawFence(p); break;
  case 'Container': drawContainer(p); break;
  case 'Crane Base': drawCrane(p); break;
  case 'Luggage Cart': drawCart(p); break;
  case 'Runway Edge': drawRunway(p); break;
  case 'Flagpole': drawFlagpole(p); break;
  case 'Table': drawTable(p); break;
  case 'Bunker': drawBunker(p); break;
  case 'Deep Lab Access': drawLabDoor(p); break;
  case 'GasPump': drawGasPump(p); break;
  case 'Church': drawChurch(p); break;
  case 'Silo': drawSilo(p); break;
  case 'Barn': drawBarn(p); break;
  case 'Tracks': drawTracks(p); break;
  case 'Watchtower': drawWatchtower(p); break;
  case 'Antenna': drawAntenna(p); break;
  default: drawGenericBlock(p);
 }
 ctx.restore();
}
function drawGenericBlock(p){
 ctx.fillStyle = p.fill||'#171810'; ctx.fillRect(p.x,p.y,p.w,p.h);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.lineWidth=1; ctx.strokeRect(p.x,p.y,p.w,p.h);
 labelTag(p);
}
function drawHouse(p, big){
 const {x,y,w,h}=p;
 if(p.variant==='flat' && !big){ drawHall(p, p.fill||'#1c1a14', '#2a2015'); return; }
 const roofH = h*0.32, wallH = h-roofH, wallY = y+roofH;
 ctx.fillStyle = p.fill||'#1c1a14';
 ctx.fillRect(x, wallY, w, wallH);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.lineWidth=1; ctx.strokeRect(x,wallY,w,wallH);
 ctx.beginPath();
 ctx.moveTo(x-6, wallY+3);
 ctx.lineTo(x+w/2, y);
 ctx.lineTo(x+w+6, wallY+3);
 ctx.closePath();
 ctx.fillStyle='#2a2015'; ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 const doorW = Math.min(22, w*0.16), doorH = Math.min(30, wallH*0.6);
 ctx.fillStyle='#100d08';
 ctx.fillRect(x+w/2-doorW/2, wallY+wallH-doorH, doorW, doorH);
 const cols = Math.max(2, Math.floor(w/60));
 for(let c=0;c<cols;c++){
  const wx = x+16+c*((w-32)/(cols-1||1));
  if(Math.abs(wx-(x+w/2))<doorW) continue;
  ctx.fillStyle='#0c1219'; ctx.fillRect(wx-6, wallY+10, 12, 12);
  ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(wx-6,wallY+10,12,12);
 }
 if(big){ ctx.fillStyle='#0c1219'; ctx.fillRect(x+w/2-6, wallY+wallH-doorH-24, 12,12); }
 labelTag(p);
}
function drawHall(p, wallColor, roofColor){
 const {x,y,w,h}=p;
 ctx.fillStyle = wallColor; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle = roofColor; ctx.fillRect(x-4,y-10,w+8,12);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.strokeRect(x-4,y-10,w+8,12);
 ctx.fillStyle='#0c0f0a'; ctx.fillRect(x+w/2-14,y+h-30,28,30);
 const cols = Math.max(2,Math.floor(w/70));
 for(let c=0;c<cols;c++){
  const wx = x+16+c*((w-32)/(cols-1||1));
  ctx.fillStyle='#0c1014'; ctx.fillRect(wx-8,y+12,16,16);
  ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(wx-8,y+12,16,16);
 }
 labelTag(p);
}
function drawTent(p){
 const {x,y,w,h}=p;
 ctx.fillStyle = p.fill||'#26271a';
 ctx.beginPath(); ctx.moveTo(x,y+h); ctx.lineTo(x+w/2,y); ctx.lineTo(x+w,y+h); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.lineWidth=1.5; ctx.stroke();
 ctx.beginPath(); ctx.moveTo(x+w/2,y); ctx.lineTo(x+w/2,y+h); ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.stroke();
 ctx.fillStyle='rgba(0,0,0,.5)';
 ctx.beginPath(); ctx.moveTo(x+w/2-8,y+h); ctx.lineTo(x+w/2,y+h-16); ctx.lineTo(x+w/2+8,y+h); ctx.closePath(); ctx.fill();
 labelTag(p);
}
function drawShelfBlock(p){
 const {x,y,w,h}=p;
 ctx.fillStyle = p.fill||'#171810'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 const rows = Math.max(2, Math.round(h/22));
 for(let r=1;r<rows;r++){
  const ry = y+(h/rows)*r;
  ctx.strokeStyle='rgba(0,0,0,.45)'; ctx.beginPath(); ctx.moveTo(x+3,ry); ctx.lineTo(x+w-3,ry); ctx.stroke();
 }
 for(let r=0;r<rows;r++){
  const ry = y+(h/rows)*r+4;
  const rowH = Math.max(6,(h/rows)-10);
  for(let c=0;c<Math.floor(w/26);c++){
   if((r+c)%3===0) continue;
   ctx.fillStyle = (r+c)%2===0?'rgba(232,178,61,.28)':'rgba(220,214,189,.18)';
   ctx.fillRect(x+6+c*26, ry, 14, rowH);
  }
 }
 labelTag(p);
}
function drawRubble(p){
 const {x,y,w,h}=p;
 const rnd = seededRand(Math.round(x*7+y*13)+1);
 ctx.fillStyle='rgba(0,0,0,.18)';
 ctx.beginPath(); ctx.ellipse(x+w/2,y+h+4,w*0.42,9,0,0,Math.PI*2); ctx.fill();
 const chunks = 5+Math.floor(rnd()*4);
 for(let i=0;i<chunks;i++){
  const cw=14+rnd()*(w*0.35), ch=10+rnd()*(h*0.3);
  const cx = x+rnd()*Math.max(1,w-cw), cy = y+rnd()*Math.max(1,h-ch);
  ctx.save(); ctx.translate(cx+cw/2,cy+ch/2); ctx.rotate((rnd()-0.5)*0.6);
  ctx.fillStyle='#141510'; ctx.fillRect(-cw/2,-ch/2,cw,ch);
  ctx.strokeStyle='rgba(232,178,61,.2)'; ctx.strokeRect(-cw/2,-ch/2,cw,ch);
  ctx.restore();
 }
 labelTag(p);
}
function drawHeadstone(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#22241a';
 ctx.beginPath();
 ctx.moveTo(x,y+h); ctx.lineTo(x,y+h*0.35);
 ctx.arc(x+w/2,y+h*0.35,w/2,Math.PI,0);
 ctx.lineTo(x+w,y+h); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 ctx.strokeStyle='rgba(0,0,0,.3)'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.moveTo(x+w/2,y+h*0.25); ctx.lineTo(x+w/2,y+h*0.7);
 ctx.moveTo(x+w*0.3,y+h*0.45); ctx.lineTo(x+w*0.7,y+h*0.45); ctx.stroke();
}
function drawBus(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#20261a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='rgba(0,0,0,.2)'; ctx.fillRect(x,y,w,6);
 ctx.fillStyle='#0c1014';
 for(let c=0;c<Math.floor(w/34);c++) ctx.fillRect(x+8+c*34,y+8,22,h*0.4);
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.arc(x+16,y+h,10,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(x+w-16,y+h,10,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawVault(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#221a12'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.4)'; ctx.lineWidth=2; ctx.strokeRect(x,y,w,h);
 const cx=x+w/2, cy=y+h/2, r=Math.min(w,h)/2-10;
 ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.strokeStyle='#8a6a24'; ctx.lineWidth=4; ctx.stroke();
 ctx.beginPath(); ctx.arc(cx,cy,r*0.4,0,Math.PI*2); ctx.fillStyle='#3a2c14'; ctx.fill(); ctx.stroke();
 for(let i=0;i<6;i++){
  const a=i*Math.PI/3;
  ctx.beginPath(); ctx.moveTo(cx+Math.cos(a)*r*0.4,cy+Math.sin(a)*r*0.4); ctx.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);
  ctx.strokeStyle='rgba(138,106,36,.6)'; ctx.lineWidth=2; ctx.stroke();
 }
 labelTag(p);
}
function drawCar(p){
 const {x,y,w,h}=p;
 if(p.variant==='truck'){
  ctx.fillStyle=p.fill||'#20261a';
  roundRect(x,y+h*0.3,w*0.6,h*0.5,4); ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
  ctx.fillStyle=shadeColor(p.fill||'#20261a',-16);
  roundRect(x+w*0.6,y+h*0.05,w*0.4,h*0.75,6); ctx.fill(); ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,.35)';
  roundRect(x+w*0.67,y+h*0.12,w*0.24,h*0.32,3); ctx.fill();
 } else {
  ctx.fillStyle=p.fill||'#171d20';
  roundRect(x,y+h*0.25,w,h*0.6,6); ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,.35)';
  roundRect(x+w*0.2,y,w*0.6,h*0.4,4); ctx.fill();
 }
 ctx.fillStyle='#0a0a0a';
 ctx.beginPath(); ctx.arc(x+w*0.22,y+h*0.85,9,0,Math.PI*2); ctx.fill();
 ctx.beginPath(); ctx.arc(x+w*0.78,y+h*0.85,9,0,Math.PI*2); ctx.fill();
 labelTag(p);
}
function drawFence(p){
 const {x,y,w,h}=p;
 ctx.strokeStyle='#3a2010'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x,y+h/2); ctx.lineTo(x+w,y+h/2); ctx.stroke();
 const posts = Math.max(2, Math.floor(w/40));
 for(let i=0;i<=posts;i++){
  const px = x+(w/posts)*i;
  ctx.fillStyle='#2a1a0a'; ctx.fillRect(px-2,y,4,h);
 }
 ctx.strokeStyle='rgba(138,106,36,.4)'; ctx.lineWidth=1;
 ctx.beginPath(); ctx.moveTo(x,y+h*0.25); ctx.lineTo(x+w,y+h*0.25); ctx.moveTo(x,y+h*0.75); ctx.lineTo(x+w,y+h*0.75); ctx.stroke();
}
function drawContainer(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#151d1f'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.lineWidth=1;
 for(let cx=x+8; cx<x+w-4; cx+=10){ ctx.beginPath(); ctx.moveTo(cx,y+4); ctx.lineTo(cx,y+h-4); ctx.stroke(); }
 ctx.strokeStyle='rgba(232,178,61,.35)'; ctx.lineWidth=2; ctx.strokeRect(x+w-26,y+4,20,h-8);
 labelTag(p);
}
function drawCrane(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#20201a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#2a2a1e';
 ctx.fillRect(x+w/2-6,y-140,12,140+h*0.2);
 ctx.fillRect(x+w/2-6,y-140,120,8);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x+w/2-6,y-140,120,8);
 labelTag(p);
}
function drawCart(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#1a1a1a'; ctx.fillRect(x,y,w,h*0.6);
 ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.strokeRect(x,y,w,h*0.6);
 ctx.fillStyle='#0a0a0a';
 for(let i=0;i<4;i++){ ctx.beginPath(); ctx.arc(x+8+i*(w-16)/3, y+h*0.6+6,5,0,Math.PI*2); ctx.fill(); }
 labelTag(p);
}
function drawRunway(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#101210'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(220,214,189,.5)'; ctx.lineWidth=3;
 for(let ry=y+10; ry<y+h; ry+=36){ ctx.beginPath(); ctx.moveTo(x+w/2-4,ry); ctx.lineTo(x+w/2-4,ry+18); ctx.stroke(); }
 labelTag(p);
}
function drawFlagpole(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#3a3a2a'; ctx.fillRect(x,y,w,h);
 ctx.fillStyle='#8ab82f';
 ctx.beginPath(); ctx.moveTo(x+w,y+4); ctx.lineTo(x+w+30,y+14); ctx.lineTo(x+w,y+24); ctx.closePath(); ctx.fill();
}
function drawTable(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#1a1610';
 roundRect(x,y,w,h,4); ctx.fill();
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.stroke();
 ctx.fillStyle='#141210';
 ctx.fillRect(x-8,y+h/2-6,8,12); ctx.fillRect(x+w,y+h/2-6,8,12);
}
function drawBunker(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#14150f'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(85,107,47,.4)'; ctx.lineWidth=2; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#2a2818';
 for(let c=0;c<Math.floor(w/26);c++){ ctx.beginPath(); ctx.ellipse(x+13+c*26,y+h-6,12,7,0,0,Math.PI*2); ctx.fill(); }
 ctx.fillStyle='#0a0a08';
 for(let c=0;c<Math.floor(w/70);c++) ctx.fillRect(x+20+c*70,y+16,26,8);
 labelTag(p);
}
function drawLabDoor(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#241a0a'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='#c94a2e'; ctx.lineWidth=2; ctx.setLineDash([6,4]); ctx.strokeRect(x+4,y+4,w-8,h-8); ctx.setLineDash([]);
 ctx.fillStyle='#c94a2e'; ctx.font='bold 10px monospace';
 ctx.fillText('RESTRICTED', x+w/2-30, y+h/2);
 labelTag(p);
}
function drawGasPump(p){
 const {x,y,w,h}=p;
 ctx.fillStyle=p.fill||'#2a2a1e'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#c94a2e'; ctx.fillRect(x+4,y+4,w-8,10);
 ctx.fillStyle='#0c0f0a'; ctx.fillRect(x+w*0.25,y+h*0.3,w*0.5,h*0.35);
 ctx.strokeStyle='#8a6a24'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x+w,y+h*0.4); ctx.lineTo(x+w+18,y+h*0.7); ctx.stroke();
 labelTag(p);
}
function drawChurch(p){
 const {x,y,w,h}=p;
 const wallH=h*0.68, roofH=h*0.32, wallY=y+h-wallH;
 ctx.fillStyle=p.fill||'#241a12'; ctx.fillRect(x,wallY,w,wallH);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.strokeRect(x,wallY,w,wallH);
 ctx.beginPath(); ctx.moveTo(x-6,wallY+4); ctx.lineTo(x+w/2,wallY-roofH); ctx.lineTo(x+w+6,wallY+4); ctx.closePath();
 ctx.fillStyle='#2e2015'; ctx.fill(); ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 const stX=x+w/2-16, stY=y-70, stW=32, stH=90;
 ctx.fillStyle='#2e2015'; ctx.fillRect(stX,stY,stW,stH);
 ctx.beginPath(); ctx.moveTo(stX-4,stY+4); ctx.lineTo(stX+stW/2,stY-40); ctx.lineTo(stX+stW+4,stY+4); ctx.closePath(); ctx.fill();
 ctx.strokeStyle='#dcd6bd'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(stX+stW/2,stY-40); ctx.lineTo(stX+stW/2,stY-70); ctx.moveTo(stX+stW/2-10,stY-58); ctx.lineTo(stX+stW/2+10,stY-58); ctx.stroke();
 ctx.fillStyle='#100d08'; ctx.fillRect(x+w/2-16,wallY+wallH-40,32,40);
 ctx.fillStyle='#0c1219';
 ctx.beginPath(); ctx.arc(x+w/2,wallY+30,16,Math.PI,0); ctx.fill();
 labelTag(p);
}
function drawSilo(p){
 const {x,y,w,h}=p;
 const col = p.fill||'#8a8a7a';
 roundRect(x,y+10,w,h-10,w/2); ctx.fillStyle=col; ctx.fill();
 ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.stroke();
 ctx.beginPath(); ctx.ellipse(x+w/2,y+10,w/2,10,0,0,Math.PI*2); ctx.fillStyle=shadeColor(col,20); ctx.fill(); ctx.stroke();
 ctx.strokeStyle='rgba(0,0,0,.25)'; ctx.lineWidth=1;
 for(let ry=y+30; ry<y+h; ry+=22){ ctx.beginPath(); ctx.moveTo(x+4,ry); ctx.lineTo(x+w-4,ry); ctx.stroke(); }
 labelTag(p);
}
function drawBarn(p){
 const {x,y,w,h}=p;
 const wallH=h*0.65, roofH=h*0.4, wallY=y+h-wallH;
 ctx.fillStyle=p.fill||'#5a1a10'; ctx.fillRect(x,wallY,w,wallH);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.strokeRect(x,wallY,w,wallH);
 ctx.beginPath();
 ctx.moveTo(x-8,wallY+6);
 ctx.lineTo(x+w*0.15,wallY-roofH*0.6);
 ctx.lineTo(x+w/2,wallY-roofH);
 ctx.lineTo(x+w*0.85,wallY-roofH*0.6);
 ctx.lineTo(x+w+8,wallY+6);
 ctx.closePath();
 ctx.fillStyle='#2e2015'; ctx.fill(); ctx.strokeStyle='rgba(232,178,61,.25)'; ctx.stroke();
 ctx.fillStyle='#dcd6bd';
 ctx.fillRect(x+w/2-18,wallY+10,36,36);
 ctx.strokeStyle='#5a1a10'; ctx.lineWidth=2;
 ctx.beginPath(); ctx.moveTo(x+w/2-18,wallY+10); ctx.lineTo(x+w/2+18,wallY+46); ctx.moveTo(x+w/2+18,wallY+10); ctx.lineTo(x+w/2-18,wallY+46); ctx.stroke();
 ctx.fillStyle='#1a0a06'; ctx.fillRect(x+w/2-24,wallY+wallH-50,48,50);
 labelTag(p);
}
function drawTracks(p){
 const {x,y,w,h}=p;
 ctx.fillStyle='#1c1a14'; ctx.fillRect(x,y,w,h);
 ctx.strokeStyle='rgba(0,0,0,.4)'; ctx.strokeRect(x,y,w,h);
 ctx.fillStyle='#3a2a1a';
 for(let cx=x+10; cx<x+w-10; cx+=26) ctx.fillRect(cx,y+4,8,h-8);
 ctx.strokeStyle='#8a8a7a'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(x+6,y+h*0.3); ctx.lineTo(x+w-6,y+h*0.3); ctx.moveTo(x+6,y+h*0.7); ctx.lineTo(x+w-6,y+h*0.7); ctx.stroke();
}
function drawWatchtower(p){
 const {x,y,w,h}=p;
 ctx.strokeStyle='#2a2a1e'; ctx.lineWidth=4;
 ctx.beginPath();
 ctx.moveTo(x+6,y+h); ctx.lineTo(x+w*0.3,y+20);
 ctx.moveTo(x+w-6,y+h); ctx.lineTo(x+w*0.7,y+20);
 ctx.stroke();
 ctx.lineWidth=2; ctx.strokeStyle='rgba(232,178,61,.25)';
 for(let ry=y+h*0.3; ry<y+h; ry+=h*0.22){
  ctx.beginPath(); ctx.moveTo(x+8,ry); ctx.lineTo(x+w-8,ry-14); ctx.stroke();
 }
 ctx.fillStyle='#20201a'; ctx.fillRect(x-6,y,w+12,22);
 ctx.strokeStyle='rgba(232,178,61,.3)'; ctx.strokeRect(x-6,y,w+12,22);
 ctx.beginPath(); ctx.moveTo(x-10,y); ctx.lineTo(x+w/2,y-26); ctx.lineTo(x+w+10,y); ctx.closePath();
 ctx.fillStyle='#2e2015'; ctx.fill();
 labelTag(p);
}
function drawAntenna(p){
 const {x,y,w,h}=p;
 const cx=x+w/2;
 ctx.strokeStyle='#3a3a2a'; ctx.lineWidth=3;
 ctx.beginPath(); ctx.moveTo(cx,y); ctx.lineTo(cx,y+h); ctx.stroke();
 ctx.lineWidth=1.5; ctx.strokeStyle='rgba(232,178,61,.3)';
 for(let ry=y+20; ry<y+h; ry+=36){
  ctx.beginPath(); ctx.moveTo(cx-16,ry+18); ctx.lineTo(cx,ry); ctx.lineTo(cx+16,ry+18); ctx.stroke();
 }
 ctx.beginPath(); ctx.arc(cx,y-6,5,0,Math.PI*2); ctx.fillStyle='#c94a2e'; ctx.fill();
 labelTag(p);
}
function drawRoad(r){
 ctx.fillStyle='#1c1c1a'; ctx.fillRect(r.x,r.y,r.w,r.h);
 ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.lineWidth=1; ctx.strokeRect(r.x,r.y,r.w,r.h);
 ctx.strokeStyle='rgba(220,214,189,.3)'; ctx.lineWidth=2; ctx.setLineDash([16,12]);
 ctx.beginPath();
 if(r.w>=r.h){ const cy=r.y+r.h/2; ctx.moveTo(r.x+6,cy); ctx.lineTo(r.x+r.w-6,cy); }
 else { const cx=r.x+r.w/2; ctx.moveTo(cx,r.y+6); ctx.lineTo(cx,r.y+r.h-6); }
 ctx.stroke(); ctx.setLineDash([]);
}
function render(){
 if(!document.getElementById('screen-game').classList.contains('active') || !W){ return; }
 ctx.clearRect(0,0,canvas.width,canvas.height);
 const camX = canvas.width/2 - W.player.x, camY = canvas.height/2 - W.player.y;
 ctx.save(); ctx.translate(camX,camY);

 // ground
 ctx.fillStyle = '#0d0e09'; ctx.fillRect(-40,-40,W.w+80,W.h+80);
 ctx.strokeStyle='rgba(232,178,61,.15)'; ctx.lineWidth=2; ctx.strokeRect(0,0,W.w,W.h);

 // roads (drawn first so buildings and props sit on top)
 if(W.roads) W.roads.forEach(r=> drawRoad(r));

 W.props.forEach(p=> drawStructure(p));

 W.crates.forEach(c=>{
  if(c.looted) return;
  ctx.font='22px sans-serif'; ctx.fillText(c.kind==='special'?'🗝️':(c.kind==='journal'?'📖':'📦'), c.x-11, c.y+8);
 });

 W.npcs.forEach(n=>{
  drawCharToken(n.x,n.y,15,n.color||'#8b8770', null);
  ctx.font='14px sans-serif'; ctx.fillText(n.glyph||'👤', n.x-7,n.y+5);
 });

 if(W.companionsEnt) W.companionsEnt.forEach(c=>{
  ctx.globalAlpha = c.recruited?1:0.55;
  drawCharToken(c.x,c.y,15,c.color, null, ()=>{
   const w = WEAPONS_RANGED[c.weapon];
   if(w){ const drew = drawHeldWeapon(w,0,22); if(!drew){ ctx.strokeStyle='#1a1a1a'; ctx.lineWidth=2.5; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(16,0); ctx.stroke(); } }
  });
  ctx.globalAlpha = 1;
  if(!c.recruited){ ctx.font='12px sans-serif'; ctx.fillText('🔒', c.x+6,c.y-10); }
  ctx.fillStyle= c.recruited?'#dcd6bd':'#8b8770'; ctx.font='9px monospace'; ctx.fillText(c.name, c.x-14,c.y-20);
 });

 W.zombies.forEach(z=>{
  drawCharToken(z.x,z.y,z.r,'#4a5a2a', null, ()=>{
   ctx.strokeStyle='rgba(0,0,0,.5)'; ctx.lineWidth=1.5;
   ctx.beginPath(); ctx.moveTo(-z.r*0.3,-z.r*0.15); ctx.lineTo(z.r*0.35,z.r*0.5); ctx.stroke();
  });
  ctx.font='16px sans-serif'; ctx.fillText('🧟', z.x-8,z.y+6);
  drawHpBar(z.x,z.y-z.r-8,z.hp,z.maxHp);
 });
 W.bandits.forEach(b=>{
  const col = b.banditType==='elite'?'#c94a2e':(b.banditType==='ranged'?'#8a6a24':'#a4341f');
  const bandana = b.banditType==='elite'?'#e8b23d':(b.banditType==='ranged'?'#3a2010':'#1a1a1a');
  drawCharToken(b.x,b.y,b.r,col,null, ()=>{
   ctx.fillStyle=bandana; ctx.fillRect(-b.r*0.5,-b.r*1.02,b.r*1.0,b.r*0.22);
  });
  ctx.font='15px sans-serif'; ctx.fillText(b.banditType==='ranged'?'🏹':'🏴', b.x-8,b.y+6);
  drawHpBar(b.x,b.y-b.r-8,b.hp,b.maxHp);
 });
 if(W.boss){
  drawCharToken(W.boss.x,W.boss.y,W.boss.r,'#5a1a10',null);
  ctx.font='30px sans-serif'; ctx.fillText('☣️', W.boss.x-15,W.boss.y+10);
 }

 // player
 drawCharToken(W.player.x,W.player.y,16,S.color||'#e8b23d', S.facing, ()=>{
  const wid = S.weaponSlots[S.activeSlot];
  const w = wid?findWeaponById(wid):null;
  const cat = wid?weaponCategory(wid):null;
  if(cat){
   const a=facingAngle();
   const drew = w ? drawHeldWeapon(w,a,28) : false;
   if(!drew){ ctx.strokeStyle='#1a1a1a'; ctx.lineWidth=3; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(Math.cos(a)*20,Math.sin(a)*20); ctx.stroke(); }
  }
 });

 // melee swing fx
 W.meleeFx.forEach(f=>{
  const t = f.life/f.maxLife;
  ctx.save(); ctx.translate(W.player.x,W.player.y);
  ctx.beginPath(); ctx.moveTo(0,0);
  const half = f.arcDeg*Math.PI/180/2;
  ctx.arc(0,0,f.reach, f.angle-half, f.angle+half);
  ctx.closePath();
  ctx.fillStyle = `rgba(232,178,61,${0.35*t})`;
  ctx.fill();
  ctx.restore();
 });

 // projectiles
 W.projectiles.forEach(p=>{
  ctx.strokeStyle = p.owner==='player' ? '#e8b23d' : (p.owner==='companion' ? (p.color||'#3fa0d8') : '#c94a2e');
  ctx.lineWidth=3;
  ctx.beginPath(); ctx.moveTo(p.x,p.y); ctx.lineTo(p.x-p.vx*0.02,p.y-p.vy*0.02); ctx.stroke();
 });
 W.explosionFx.forEach(f=>{
  const t=f.life/f.maxLife;
  ctx.beginPath(); ctx.arc(f.x,f.y,f.radius*(1-t*0.3),0,Math.PI*2);
  ctx.fillStyle=`rgba(196,74,30,${0.4*t})`; ctx.fill();
 });

 ctx.restore();

 drawFog(camX,camY);

 // interact prompt
 const promptEl = document.getElementById('prompt');
 let near=null;
 if(W.crates.some(c=>!c.looted && dist(c.x,c.y,W.player.x,W.player.y)<46)) near='Press E to loot';
 else if(W.npcs.some(n=>dist(n.x,n.y,W.player.x,W.player.y)<50)) near='Press E to talk';
 else if(W.companionsEnt && W.companionsEnt.some(c=>dist(c.x,c.y,W.player.x,W.player.y)<50)) near='Press E to talk';
 if(near){ promptEl.style.display='block'; promptEl.textContent=near; } else promptEl.style.display='none';
}
function drawHpBar(x,y,hp,maxHp){
 const camX = canvas.width/2 - W.player.x, camY = canvas.height/2 - W.player.y;
}
function darknessLevel(min){
 const dawnStart=300,dawnEnd=380,duskStart=1070,duskEnd=1180;
 if(min>=dawnEnd && min<=duskStart) return 0;
 if(min<dawnStart || min>duskEnd) return 0.80;
 if(min>=dawnStart && min<dawnEnd) return 0.80*(1-(min-dawnStart)/(dawnEnd-dawnStart));
 if(min>duskStart && min<=duskEnd) return 0.80*((min-duskStart)/(duskEnd-duskStart));
 return 0.3;
}
function drawFog(camX,camY){
 fogCtx.clearRect(0,0,fogCanvas.width,fogCanvas.height);
 const dark = darknessLevel(S.gameMinutes);
 if(dark>0.01){
  fogCtx.fillStyle = `rgba(2,3,1,${dark})`;
  fogCtx.fillRect(0,0,fogCanvas.width,fogCanvas.height);
  if(S.flashlight){
   const px = W.player.x+camX, py = W.player.y+camY;
   const a = facingAngle();
   fogCtx.save();
   fogCtx.globalCompositeOperation='destination-out';
   const grad = fogCtx.createRadialGradient(px,py,10,px,py,260);
   grad.addColorStop(0,'rgba(255,255,255,1)');
   grad.addColorStop(1,'rgba(255,255,255,0)');
   fogCtx.fillStyle=grad;
   fogCtx.beginPath(); fogCtx.moveTo(px,py);
   fogCtx.arc(px,py,260, a-0.5, a+0.5);
   fogCtx.closePath(); fogCtx.fill();
   fogCtx.restore();
  }
 }
 ctx.drawImage(fogCanvas,0,0);
}

/* ================= MODALS: INVENTORY ================= */
let draggedItemId = null;
const WEAPON_SLOT_LABELS = {melee:'Melee', secondary:'Secondary', primary:'Primary', rocket:'Rocket', throwable:'Throwable'};
function canEquipToSlot(id, slotName){
 const cat = weaponCategory(id);
 if(!cat) return false;
 if(slotName==='melee') return cat==='melee';
 if(slotName==='throwable') return cat==='throwable';
 if(cat!=='ranged') return false;
 return WEAPONS_RANGED[id].slot===slotName;
}
function renderInventoryModal(){
 const grid = document.getElementById('inv-grid'); grid.innerHTML='';
 if(S.inventory.length===0) grid.innerHTML = '<div class="inv-empty">Nothing here yet. Go loot something.</div>';
 S.inventory.forEach(it=>{
  const cell = document.createElement('div'); cell.className='inv-cell'; cell.draggable=true;
  cell.ondragstart=(e)=>{ draggedItemId=it.id; e.dataTransfer.setData('text/plain', it.id); };
  cell.ondragend=()=>{ draggedItemId=null; document.querySelectorAll('.eq-slot').forEach(s=>s.classList.remove('drag-over-ok','drag-over-bad')); };
  const icon = itemIcon(it.id,it.kind);
  cell.innerHTML = `<span class="qty">x${Math.round(it.qty*10)/10}</span><div class="ic">${icon}</div><div class="nm">${itemDisplayName(it.id)}</div>`;
  cell.onclick = ()=> useOrEquipItem(it);
  grid.appendChild(cell);
 });
 document.getElementById('carry-fill').style.width = clamp(carryWeight(S)/S.carryCap*100,0,100)+'%';
 document.getElementById('carry-txt').textContent = carryWeight(S)+' / '+S.carryCap;

 // paper doll — armor & backpack
 const armorSlot = document.getElementById('eq-armor-slot');
 const bpSlot = document.getElementById('eq-backpack-slot');
 armorSlot.innerHTML = S.equipped.armor ? `<div class="eq-item"><div class="ic">${ARMOR[S.equipped.armor].icon}</div><div class="nm">${ARMOR[S.equipped.armor].name}</div><div class="dur-track"><div class="dur-fill" style="width:${clamp(S.armorDurability/ARMOR[S.equipped.armor].durability*100,0,100)}%"></div></div></div>` : `<div class="eq-empty">Armor<br>slot</div>`;
 armorSlot.onclick = ()=> unequipArmor(S);
 armorSlot.ondragover = (e)=>{ e.preventDefault(); armorSlot.classList.toggle('drag-over-ok', !!ARMOR[draggedItemId]); armorSlot.classList.toggle('drag-over-bad', !!draggedItemId && !ARMOR[draggedItemId]); };
 armorSlot.ondragleave = ()=> armorSlot.classList.remove('drag-over-ok','drag-over-bad');
 armorSlot.ondrop = (e)=>{ e.preventDefault(); armorSlot.classList.remove('drag-over-ok','drag-over-bad'); const id=e.dataTransfer.getData('text/plain'); if(ARMOR[id]) equipArmor(S,id); else toast("That doesn't go in the armor slot.", 'bad'); };
 bpSlot.innerHTML = S.equipped.backpack ? `<div class="eq-item"><div class="ic">${BACKPACKS[S.equipped.backpack].icon}</div><div class="nm">${BACKPACKS[S.equipped.backpack].name}</div></div>` : `<div class="eq-empty">Backpack<br>slot</div>`;
 bpSlot.onclick = ()=> unequipBackpack(S);
 bpSlot.ondragover = (e)=>{ e.preventDefault(); bpSlot.classList.toggle('drag-over-ok', !!BACKPACKS[draggedItemId]); bpSlot.classList.toggle('drag-over-bad', !!draggedItemId && !BACKPACKS[draggedItemId]); };
 bpSlot.ondragleave = ()=> bpSlot.classList.remove('drag-over-ok','drag-over-bad');
 bpSlot.ondrop = (e)=>{ e.preventDefault(); bpSlot.classList.remove('drag-over-ok','drag-over-bad'); const id=e.dataTransfer.getData('text/plain'); if(BACKPACKS[id]) equipBackpack(S,id); else toast("That doesn't go in the backpack slot.", 'bad'); };

 // weapon slots — melee / secondary / primary / rocket / throwable
 ['melee','secondary','primary','rocket','throwable'].forEach(slotName=>{
  const el = document.getElementById('eq-'+slotName+'-slot');
  const wid = S.weaponSlots[slotName];
  const w = wid ? findWeaponById(wid) : null;
  el.innerHTML = w ? `<div class="eq-item"><div class="ic">${iconHtml(w.icon,w.img,18)}</div><div class="nm">${w.name}</div></div>` : `<div class="eq-empty">${WEAPON_SLOT_LABELS[slotName]}<br>slot</div>`;
  el.onclick = ()=>{
   if(slotName==='melee'){
    if(wid && wid!=='fists'){ addToInventory(S, wid, 'weapon_melee', 1); S.weaponSlots.melee='fists'; renderWeaponSlots(); renderInventoryModal(); toast('Put away.', 'amber'); }
   } else if(slotName==='throwable'){
    if(wid){ S.weaponSlots.throwable=null; renderWeaponSlots(); renderInventoryModal(); toast('Unequipped.', 'amber'); }
   } else {
    if(wid){ addToInventory(S, wid, 'weapon_ranged', 1); S.weaponSlots[slotName]=null; renderWeaponSlots(); renderInventoryModal(); toast('Unequipped.', 'amber'); }
   }
  };
  el.ondragover = (e)=>{ e.preventDefault(); const ok = !!draggedItemId && canEquipToSlot(draggedItemId, slotName); el.classList.toggle('drag-over-ok', ok); el.classList.toggle('drag-over-bad', !!draggedItemId && !ok); };
  el.ondragleave = ()=> el.classList.remove('drag-over-ok','drag-over-bad');
  el.ondrop = (e)=>{
   e.preventDefault();
   el.classList.remove('drag-over-ok','drag-over-bad');
   const id = e.dataTransfer.getData('text/plain');
   if(!id) return;
   if(!canEquipToSlot(id, slotName)){ toast("That doesn't go in the "+WEAPON_SLOT_LABELS[slotName]+' slot.', 'bad'); return; }
   if(slotName==='throwable'){ S.weaponSlots.throwable = id; renderWeaponSlots(); renderInventoryModal(); }
   else equipWeaponFromInventory(S, id);
  };
 });
}
function iconHtml(icon, img, sizePx){
 sizePx = sizePx||20;
 if(img) return `<img src="${img}" class="icon-img" style="width:${sizePx}px;height:${sizePx}px" alt="">`;
 return `<span class="icon-emoji">${icon||'❔'}</span>`;
}
function itemIcon(id,kind){
 const c = findConsumableById(id); if(c) return iconHtml(c.icon);
 if(id.startsWith('ammo_')) return iconHtml(AMMO_TYPES[id.replace('ammo_','')].icon);
 if(ARMOR[id]) return iconHtml(ARMOR[id].icon);
 if(BACKPACKS[id]) return iconHtml(BACKPACKS[id].icon);
 const w = findWeaponById(id); if(w) return iconHtml(w.icon, w.img);
 return iconHtml('❔');
}
function useOrEquipItem(it){
 if(ARMOR[it.id]){ equipArmor(S,it.id); return; }
 if(BACKPACKS[it.id]){ equipBackpack(S,it.id); return; }
 if(it.kind==='weapon_melee' || it.kind==='weapon_ranged' || it.kind==='weapon_throwable'){
  toast('Drag it to its weapon slot to equip it.', 'bad');
  return;
 }
 const c = findConsumableById(it.id);
 if(c){
  useConsumable(it.id, c);
  renderInventoryModal();
 }
}
function useConsumable(id, c){
 let restoreMult = S.skills.fast_metabolism ? 1.2 : 1;
 if(c.hunger) S.hunger = Math.min(100, S.hunger + c.hunger*restoreMult);
 if(c.thirst) S.thirst = Math.min(100, S.thirst + c.thirst*restoreMult);
 if(c.heal){ let h=c.heal*(S.skills.field_medic?1.2:1); S.hp = Math.min(S.maxHp, S.hp+h); }
 if(c.cure) cureStatus(c.cure);
 if(c.buff){ S.buffs.push({stat:c.buff.stat, mult:c.buff.mult, add:c.buff.add, expiresAt:performance.now()+c.buff.ms}); }
 removeFromInventory(S, id, 1);
 toast('Used '+c.name+'.', 'amber');
 updateHudDynamic();
}
function autoUseBest(){
 if(S.hp<S.maxHp*0.5){
  const heals = ['serum','medkit','antibiotics','bandage'].map(id=>({id,c:MEDS[id]})).filter(x=>findInv(S,x.id));
  if(heals.length){ useConsumable(heals[0].id, heals[0].c); renderInventoryModal(); return; }
 }
 if(S.hunger<30){ const f=Object.keys(FOODS).map(id=>({id,c:FOODS[id]})).find(x=>findInv(S,x.id)); if(f){useConsumable(f.id,f.c);renderInventoryModal();return;} }
 if(S.thirst<30){ const d=Object.keys(DRINKS).map(id=>({id,c:DRINKS[id]})).find(x=>findInv(S,x.id)); if(d){useConsumable(d.id,d.c);renderInventoryModal();return;} }
 toast('Nothing useful to use right now.', 'bad');
}

/* ================= MODALS: MAP / QUESTS / SKILLS / ACH / TRADE ================= */
function renderMapModal(){
 const grid = document.getElementById('map-grid'); grid.innerHTML='';
 LOCATIONS.forEach(loc=>{
  if(loc.locked==='both_choices' && !(S.flags.hospital_choice_done && S.flags.warehouse_choice_done)) return;
  const div = document.createElement('div'); div.className='maploc'+(S.currentLocation===loc.id?' cur':'');
  div.innerHTML = `<div class="nm">${loc.name}</div><div class="dg">DANGER: ${loc.danger}</div><div class="visited">${loc.id==='camp'?'NO LOOT · DEFEND':(loc.noLoot?'SAFE ZONE · TRADE':'Tap to travel')}</div>`;
  div.onclick = ()=>{ if(S.currentLocation!==loc.id){ enterLocation(loc.id); Game.closeModal(); } };
  grid.appendChild(div);
 });
}
let questTabState='main';
function renderQuestsModal(){
 document.querySelectorAll('#modal-quests .tab').forEach(t=>t.classList.toggle('active', t.dataset.qt===questTabState));
 const body = document.getElementById('quest-body'); body.innerHTML='';
 const src = questTabState==='main'?MAIN_QUESTS:SIDE_QUESTS;
 const state = questTabState==='main'?S.questsMain:S.questsSide;
 Object.keys(src).forEach(id=>{
  const q = src[id]; const st = state[id];
  if(st.status==='locked') return;
  const row = document.createElement('div'); row.className='qrow'+(questTabState==='side'?' side':'')+(st.status==='done'?' done':'');
  let objText = (q.type==='loot' || q.type==='kill_at_camp' || q.type==='loot_at' || q.type==='journal_count' || q.type==='kill_bandits' || q.type==='kill_total' || q.type==='community_aid') ? `${Math.min(st.progress,q.target)}/${q.target}` : (st.status==='done'?'Complete':'In progress');
  row.innerHTML = `<div class="qt">${q.title}</div><div class="qd">${q.desc}</div><div class="qobj">${objText}</div>`;
  body.appendChild(row);
 });
}
let skillTabState='survivor';
function renderSkillsModal(){
 document.getElementById('skillpoints').textContent = S.skillPoints;
 const tabs = document.getElementById('stree-tabs'); tabs.innerHTML='';
 Object.keys(SKILL_TREE).forEach(branch=>{
  const t = document.createElement('div'); t.className='stree-branch tab'+(skillTabState===branch?' active':'');
  t.textContent = branch; t.onclick=()=>{ skillTabState=branch; renderSkillsModal(); };
  tabs.appendChild(t);
 });
 const body = document.getElementById('stree-body'); body.innerHTML='';
 SKILL_TREE[skillTabState].forEach(node=>{
  const owned = !!S.skills[node.id];
  const lockedReq = node.req && !S.skills[node.req];
  const div = document.createElement('div'); div.className='snode'+(owned?' owned':'');
  div.innerHTML = `<div class="n"><b>${node.name}</b> (${node.cost}pt)<div class="d">${node.desc}${lockedReq?' — requires '+SKILL_TREE[skillTabState].find(n=>n.id===node.req).name:''}</div></div>`;
  const btn = document.createElement('button');
  btn.textContent = owned?'Owned':'Unlock';
  btn.disabled = owned || lockedReq || S.skillPoints<node.cost;
  btn.onclick = ()=>unlockSkill(node.id);
  div.appendChild(btn);
  body.appendChild(div);
 });
}
let achTabState='ach';
function renderAchModal(){
 document.querySelectorAll('#modal-achievements .tab').forEach(t=>t.classList.toggle('active', t.dataset.at===achTabState));
 const body = document.getElementById('ach-body'); body.innerHTML='';
 if(achTabState==='ach'){
  const g = document.createElement('div'); g.className='ach-grid';
  ACHIEVEMENTS.forEach(a=>{
   const got = S.achievements[a.id];
   const d = document.createElement('div'); d.className='ach'+(got?' got':'');
   d.innerHTML = `<div class="ic">${got?a.icon:'🔒'}</div><div><div class="nm">${a.name}</div><div class="ds">${got?a.desc:'???'}</div>${got?'<div class="bn">Unlocked</div>':''}</div>`;
   g.appendChild(d);
  });
  body.appendChild(g);
 } else {
  const pages = JOURNAL_PAGES.filter(j=>S.journalPages[j.id]);
  if(pages.length===0){
   body.innerHTML = '<div class="inv-empty">No journal pages found yet. Look for a 📖 icon while exploring.</div>';
  } else {
   const list = document.createElement('div'); list.className='journal-list';
   pages.forEach(p=>{
    const loc = findLocation(p.loc);
    const d = document.createElement('details'); d.className='journal-entry';
    d.innerHTML = `<summary>📖 <span class="jtitle">${p.title}</span><span class="jloc">${loc?loc.name:''}</span></summary><p>${p.text}</p>`;
    list.appendChild(d);
   });
   body.appendChild(list);
   const remaining = JOURNAL_PAGES.length - pages.length;
   const foot = document.createElement('div'); foot.className='inv-empty';
   foot.textContent = remaining>0 ? (pages.length+' / '+JOURNAL_PAGES.length+' pages found — '+remaining+' still out there.') : 'All '+JOURNAL_PAGES.length+' pages recovered.';
   body.appendChild(foot);
  }
 }
}
function renderTradeModal(){
 document.getElementById('trade-tokens').textContent = S.tokens;
 const buy = document.getElementById('trade-buy'); buy.innerHTML='';
 const sell = document.getElementById('trade-sell'); sell.innerHTML='';
 const ctx = S.tradeContext || 'camp';
 const titleEl = document.getElementById('trade-title');
 if(titleEl) titleEl.textContent = ctx==='blockade' ? 'Blockade Armory' : "Joe's Stock";
 const ammoList = [
  {id:'ammo_mm9',   name:AMMO_TYPES.mm9.name,   icon:AMMO_TYPES.mm9.icon,   price:1, isAmmo:true, kind:'ammo'},
  {id:'ammo_magnum',name:AMMO_TYPES.magnum.name,icon:AMMO_TYPES.magnum.icon,price:3, isAmmo:true, kind:'ammo'},
  {id:'ammo_rifle', name:AMMO_TYPES.rifle.name, icon:AMMO_TYPES.rifle.icon, price:1, isAmmo:true, kind:'ammo'},
  {id:'ammo_shells',name:AMMO_TYPES.shells.name,icon:AMMO_TYPES.shells.icon,price:2, isAmmo:true, kind:'ammo'},
  {id:'ammo_rocket',name:AMMO_TYPES.rocket.name,icon:AMMO_TYPES.rocket.icon,price:8, isAmmo:true, kind:'ammo'}
 ];
 let buyList;
 if(ctx==='blockade'){
  // Guns and ammo only — including the Blockade-exclusive hardware
  buyList = [
   ...Object.values(WEAPONS_RANGED),
   ...ammoList,
   ...Object.values(BUFF_ITEMS)
  ];
 } else {
  buyList = [
   ...Object.values(WEAPONS_MELEE).filter(w=>w.price>0),
   ...Object.values(WEAPONS_RANGED).filter(w=>w.exclusive!=='blockade'),
   ...Object.values(WEAPONS_THROWABLE),
   ...Object.values(ARMOR), ...Object.values(BACKPACKS),
   ...Object.values(DRINKS), ...Object.values(FOODS), ...Object.values(MEDS).filter(m=>!m.rare),
   ...ammoList
  ];
 }
 buyList.forEach(item=>{
  const row = document.createElement('div'); row.className='trow';
  row.innerHTML = `<span>${iconHtml(item.icon, item.img)} ${item.name}</span><span class="price">${item.price}t</span>`;
  const btn = document.createElement('button'); btn.textContent='Buy';
  btn.onclick = ()=>{
   if(S.tokens<item.price){ toast('Not enough tokens.', 'bad'); return; }
   const kind = item.isAmmo?'ammo': (ARMOR[item.id]?'armor':(BACKPACKS[item.id]?'backpack':(WEAPONS_MELEE[item.id]?'weapon_melee':(WEAPONS_RANGED[item.id]?'weapon_ranged':(WEAPONS_THROWABLE[item.id]?'weapon_throwable':consumableKind(item.id))))));
   const qty = item.isAmmo?10:1;
   let ok;
   if(kind==='weapon_melee'||kind==='weapon_ranged'||kind==='weapon_throwable'){ giveWeaponItem(S,item.id); ok=true; }
   else ok = addToInventory(S,item.id,kind,qty);
   if(ok){ S.tokens-=item.price; toast('Bought '+item.name+'.', 'amber'); renderTradeModal(); renderInventoryModal(); renderWeaponSlots(); checkAchievements(); }
  };
  row.appendChild(btn); buy.appendChild(row);
 });
 S.inventory.forEach(it=>{
  if(it.kind==='quest') return;
  const val = itemSellValue(it.id, it.kind);
  const row = document.createElement('div'); row.className='trow';
  row.innerHTML = `<span>${itemIcon(it.id,it.kind)} ${itemDisplayName(it.id)} ×${Math.round(it.qty)}</span><span class="price">${val}t</span>`;
  const btn = document.createElement('button'); btn.textContent='Sell';
  btn.onclick = ()=>{ removeFromInventory(S,it.id,1); S.tokens+=val; toast('Sold '+itemDisplayName(it.id)+'.', 'amber'); renderTradeModal(); renderInventoryModal(); };
  row.appendChild(btn); sell.appendChild(row);
 });
}
function itemBasePrice(id, kind){
 if(kind==='weapon_melee' || kind==='weapon_ranged' || kind==='weapon_throwable'){
  const w = findWeaponById(id); return w ? w.price : 0;
 }
 if(kind==='armor'){ return ARMOR[id] ? ARMOR[id].price : 0; }
 if(kind==='backpack'){ return BACKPACKS[id] ? BACKPACKS[id].price : 0; }
 if(kind==='ammo'){
  const t = id.replace('ammo_','');
  return {mm9:1, magnum:3, rifle:1, shells:2, rocket:8}[t] || 1;
 }
 const cons = findConsumableById(id);
 if(cons) return cons.price!==undefined ? cons.price : 3;
 return 2;
}
function itemSellValue(id, kind){
 return Math.max(1, Math.round(itemBasePrice(id,kind) * 0.45));
}

/* ================= TOAST ================= */
function toast(msg, kind){
 const stack = document.getElementById('toasts'); if(!stack) return;
 const t = document.createElement('div'); t.className='toast'+(kind?' '+kind:'');
 t.textContent = msg; stack.appendChild(t);
 setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),300); }, 2600);
}

/* ================= LOOP ================= */
function loop(t){
 if(!lastT) lastT=t;
 const dt = Math.min(50, t-lastT); lastT=t;
 if(S && !document.getElementById('screen-ending').classList.contains('active') &&
    document.getElementById('screen-game').classList.contains('active') &&
    !document.getElementById('modal-bg').classList.contains('open') && !dialogueOpen() && W){
  update(dt);
 }
 render();
 RAF = requestAnimationFrame(loop);
}
function dialogueOpen(){ return document.getElementById('dialogue').style.display==='block'; }

/* ================= INPUT ================= */
const KONAMI = ['arrowup','arrowup','arrowdown','arrowdown','arrowleft','arrowright','arrowleft','arrowright','b','a'];
let konamiBuf = [];
window.addEventListener('keydown', (e)=>{
 const k = e.key.toLowerCase();
 KEYS[k]=true;
 konamiBuf.push(k); konamiBuf = konamiBuf.slice(-10);
 if(konamiBuf.join(',')===KONAMI.join(',') && S && !S.konami){
  S.konami=true; addToInventory(S,'pillow','weapon_melee',1);
  toast('??? A pillow appears in your inventory.', 'amber'); checkAchievements(); unlockAchievement('old_habits');
 }
 if(!document.getElementById('screen-game').classList.contains('active')) return;
 if(dialogueOpen() || document.getElementById('modal-bg').classList.contains('open')){
  if(k==='escape'){ if(document.getElementById('modal-bg').classList.contains('open')) Game.closeModal(); }
  return;
 }
 if(k==='e') interact();
 if(k===' '){ e.preventDefault(); const cat = weaponCategory(S.weaponSlots[S.activeSlot]); if(cat==='melee') playerMelee(); else if(cat==='ranged') playerRanged(); else if(cat==='throwable') throwActive(); }
 if(k==='r') reloadActive();
 if(k==='f'){ S.flashlight=!S.flashlight; }
 if(k==='k') autoUseBest();
 if(['1','2','3','4','5'].includes(k)){ const map={1:'melee',2:'secondary',3:'primary',4:'rocket',5:'throwable'}; S.activeSlot=map[k]; renderWeaponSlots(); }
 if(k==='i') Game.toggleModal('inventory');
 if(k==='m') Game.toggleModal('map');
 if(k==='o') Game.toggleQuestsTab('main');
 if(k==='q') Game.toggleQuestsTab('side');
 if(k==='p') Game.toggleAchTab('ach');
 if(k==='j') Game.toggleAchTab('journal');
 if(k==='l') Game.toggleModal('skills');
 if(k==='escape') Game.toggleModal('pause');
});
window.addEventListener('keyup', (e)=>{ KEYS[e.key.toLowerCase()]=false; });

/* ================= UI RENDERERS: character/companion select ================= */
function renderRoster(){
 const roster = document.getElementById('roster'); roster.innerHTML='';
 SURVIVORS.forEach(sv=>{
  const card = document.createElement('div'); card.className='card'+(selectedSurvivor===sv.id?' picked':'');
  card.innerHTML = `<div class="avatar" style="background:${sv.color}">${buildFaceSVG(sv)}<span class="glyph">${classIcon(sv.role)}</span></div>
   <div class="card-name">${sv.name}</div><div class="card-role">${sv.role}</div>
   <div class="card-stats">END ${sv.END} · AGI ${sv.AGI} · STR ${sv.STR}<br>PER ${sv.PER} · STA ${sv.STA}</div>`;
  card.onclick = ()=>{ selectedSurvivor=sv.id; renderRoster(); renderCharDetail(sv); document.getElementById('btn-char-confirm').disabled=false; };
  roster.appendChild(card);
 });
}
function classIcon(role){
 return {Doctor:'⚕️',Engineer:'🔧',Teen:'🎧',Lumberjack:'🪓',Army:'🎖️',Police:'👮',Firefighter:'🚒',Citizen:'🙂',Builder:'👷',Hacker:'💻'}[role]||'❔';
}
function buildFaceSVG(sv){
 return `<svg width="40" height="40" viewBox="0 0 40 40" style="position:absolute">
  <circle cx="20" cy="18" r="12" fill="${sv.skin}"/>
  <path d="M8 14 Q20 2 32 14 L32 10 Q20 6 8 10 Z" fill="${sv.hair}"/>
  <circle cx="15" cy="18" r="1.6" fill="#1a1a1a"/><circle cx="25" cy="18" r="1.6" fill="#1a1a1a"/>
  <path d="M14 24 Q20 28 26 24" stroke="#1a1a1a" stroke-width="1.4" fill="none"/>
 </svg>`;
}
function renderCharDetail(sv){
 const d = document.getElementById('char-detail');
 const startW = findWeaponById(sv.startWeapon);
 d.innerHTML = `<div class="detail-name">${sv.name}</div><div class="detail-role">${sv.role}</div>
  <div class="detail-perk">${sv.perk}</div>
  ${statBars(sv)}
  <div style="margin-top:14px;font-size:12px;color:var(--bone-dim)">Starts equipped with: ${startW?startW.name:'Fists'}</div>`;
}
function statBars(sv){
 return ['END','AGI','STR','PER','STA'].map(k=>`
  <div class="statbar-row"><span>${k}</span><div class="statbar-track"><div class="statbar-fill" style="width:${sv[k]*10}%"></div></div><span>${sv[k]}</span></div>
 `).join('');
}

/* ================= SAVE / CONTINUE =================
   Saved to localStorage on the player's own machine — this is a real standalone
   game file running from disk in the player's own browser, not a sandboxed
   artifact, so localStorage is the right tool here. Only ever saved while the
   survivor is alive; dying does not write a save. */
const SAVE_KEY = 'dh_revelation_save_v1';
function saveGame(){
 try{
  const copy = JSON.parse(JSON.stringify(S));
  copy.reloadingSlot = null;   // a pending reload's setTimeout can't survive a reload
  copy.buffs = [];             // buff expiry timestamps are meaningless across sessions
  localStorage.setItem(SAVE_KEY, JSON.stringify(copy));
  return true;
 } catch(e){ console.error('Save failed', e); return false; }
}
function loadGame(){
 try{
  const raw = localStorage.getItem(SAVE_KEY);
  if(!raw) return null;
  return JSON.parse(raw);
 } catch(e){ console.error('Load failed', e); return null; }
}
function hasSave(){ try{ return !!localStorage.getItem(SAVE_KEY); } catch(e){ return false; } }
function updateContinueButton(){
 const btn = document.getElementById('btn-continue');
 if(btn) btn.disabled = !hasSave();
}

/* ================= GAME PUBLIC API ================= */
const Game = {
 goto(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById('screen-'+id).classList.add('active');
  if(id==='game'){ document.getElementById('screen-game').style.display='block'; renderWeaponSlots(); }
 },
 startGame(){
  S = newState(selectedSurvivor);
  Game.goto('game');
  activateNextQuests();
  enterLocation('suburbs');
  renderWeaponSlots();
  updateHudDynamic();
  if(!RAF) RAF = requestAnimationFrame(loop);
 },
 continueGame(){
  if(S){ Game.goto('game'); return; }
  const loaded = loadGame();
  if(!loaded){ toast('No saved game found.', 'bad'); return; }
  S = loaded;
  Game.goto('game');
  enterLocation(S.currentLocation || 'suburbs');
  renderWeaponSlots();
  updateHudDynamic();
  if(!RAF) RAF = requestAnimationFrame(loop);
 },
 quitToTitle(){
  if(S && S.hp>0){ saveGame(); }
  RAF && cancelAnimationFrame(RAF); RAF=null; lastT=0; S=null; W=null;
  document.getElementById('bossbar').style.display='none';
  document.getElementById('modal-bg').classList.remove('open');
  document.getElementById('flashOverlay').style.display='none';
  Game.goto('title');
  updateContinueButton();
 },
 toggleModal(name){
  const el = document.getElementById('modal-'+name);
  const bg = document.getElementById('modal-bg');
  if(bg.classList.contains('open') && el.style.display==='flex'){ Game.closeModal(); return; }
  Game.showModal(name);
 },
 toggleQuestsTab(tab){
  const el = document.getElementById('modal-quests');
  const bg = document.getElementById('modal-bg');
  if(bg.classList.contains('open') && el.style.display==='flex' && questTabState===tab){ Game.closeModal(); return; }
  questTabState = tab;
  Game.showModal('quests');
 },
 toggleAchTab(tab){
  const el = document.getElementById('modal-achievements');
  const bg = document.getElementById('modal-bg');
  if(bg.classList.contains('open') && el.style.display==='flex' && achTabState===tab){ Game.closeModal(); return; }
  achTabState = tab;
  Game.showModal('achievements');
 },
 showModal(name){
  document.querySelectorAll('.modal').forEach(m=>m.style.display='none');
  const el = document.getElementById('modal-'+name); if(!el) return;
  el.style.display='flex'; el.style.flexDirection='column';
  document.getElementById('modal-bg').classList.add('open');
  if(name==='inventory') renderInventoryModal();
  if(name==='map') renderMapModal();
  if(name==='quests') renderQuestsModal();
  if(name==='skills') renderSkillsModal();
  if(name==='achievements') renderAchModal();
  if(name==='trade') renderTradeModal();
 },
 closeModal(){ document.querySelectorAll('.modal').forEach(m=>m.style.display='none'); document.getElementById('modal-bg').classList.remove('open'); },
 questTab(t){ questTabState=t; renderQuestsModal(); },
 achTab(t){ achTabState=t; renderAchModal(); },
 openHelp(){ Game.showModal('help'); }
};

/* ================= INIT ================= */
window.addEventListener('DOMContentLoaded', ()=>{
 buildLoreArt();
 renderRoster();
 updateContinueButton();
 if(!RAF) RAF = requestAnimationFrame(loop);
});
function buildLoreArt(){
 ['art-city','art-ruin'].forEach(id=>{
  const host = document.getElementById(id); if(!host) return;
  const sky = host.querySelector('.skyline'); if(!sky) return;
  const sun = document.createElement('div'); sun.className='sun'; sky.appendChild(sun);
  const n = id==='art-city'?7:5;
  for(let i=0;i<n;i++){
   const b = document.createElement('div'); b.className='bld';
   const w = 40+Math.random()*70, h=60+Math.random()*140;
   b.style.left=(i*(100/n))+'%'; b.style.width=w+'px'; b.style.height=h+'px';
   sky.appendChild(b);
   for(let wI=0; wI<Math.floor(h/18); wI++){
    const win = document.createElement('div'); win.className='win';
    win.style.left=(parseFloat(b.style.left))+ (10+Math.random()*(w-20)) +'px';
    win.style.bottom=(8+wI*18)+'px';
    sky.appendChild(win);
   }
  }
 });
}
