'use strict';
/* ================= DEAD HORIZON: REVELATION — DIALOGUE TREES =================
   Node shape: { who, text: string|(S=>string), opts:[{label, tag?, next?, cha?, karma?,
   trust?, action?, ending?, showIf?:(S=>bool)}] }
   The engine hides any option whose showIf(S) returns false. `action` strings are
   matched in runDialogueAction(); `action` beginning with 'recruit_' is handled
   generically (recruits COMPANIONS[id]). */

const DIALOGUES = {

 camp_leader: {
  start: {
   who: `Camp Leader — Elias Marsh`,
   text: `Another face. Good — we lost three people to the last raid. You want to stay, you carry your weight. Simple as that.`,
   opts: [
    {label:`What do you need done?`, next:'need'},
    {label:`What is this place?`, next:'about'},
    {label:`What happened out there?`, tag:'Lore', next:'ridge'},
    {label:`Just looking around.`}
   ]
  },
  need: {
   who:`Elias Marsh`,
   text:`Keep this camp clear of anything that wanders in — we can't stash supplies here anymore, not since the fence line got so thin. Joe can outfit you. And the radio's been dead a week; somebody should find out why.`,
   opts:[{label:`Understood.`, cha:1}]
  },
  about:{
   who:`Elias Marsh`,
   text:`Sixty-some of us, behind a fence made of car doors and prayer. We had two hundred, first month. Camp holds if the fence holds. That's the whole philosophy.`,
   opts:[{label:`Back to business.`, next:'start'}]
  },
  ridge:{
   who:`Elias Marsh`,
   text:`Revelation Biotech ran a facility up on the north ridge. Whatever they were building got out three days before the news called it an "isolated health event." Find the answers if you want them. I stopped needing them to sleep at night.`,
   opts:[{label:`Back to business.`, next:'start'}]
  }
 },

 joe_intro:{
  start:{
   who:`Joe`,
   text:`Tokens or trade, friend, doesn't matter to me. Guns, gear, armor, packs — whatever's still standing in this county, I can probably get you a piece of it.`,
   opts:[
    {label:`Let's trade.`, action:'open_trade'},
    {label:`Just passing through.`}
   ]
  }
 },

 hospital_doctor:{
  start:{
   who:`Dr. Voss (through the door)`,
   text:`Please — I've been sealed in this ward since the outbreak. The lock's jammed, not me. I can still be useful. I was here when this started. I know things.`,
   opts:[
    {label:`I'll get you out.`, tag:'Karma +', next:'save_confirm'},
    {label:`Not my problem.`, tag:'Karma −', next:'abandon_confirm'}
   ]
  },
  save_confirm:{
   who:`Dr. Voss`,
   text:`Thank you. I mean that. Whatever's left of this county, it's going to need people willing to open doors instead of walking past them.`,
   opts:[{label:`Head back to camp.`, action:'hospital_save'}]
  },
  abandon_confirm:{
   who:`Dr. Voss`,
   text:`Wait — WAIT! You can't just — I have information about RVL-9 that could— The voice fades as you walk away.`,
   opts:[{label:`Keep moving.`, action:'hospital_abandon'}]
  }
 },

 warehouse_bandit:{
  start:{
   who:`Kade`,
   text:(S)=> S.flags.warehouse_choice ? `Back again. This floor's still ours — same terms as last time, if you're asking.` : `This floor's ours now. Turn around, pay a toll, or find out the hard way what happens to people who don't do either.`,
   opts:[
    {label:`I'm not paying anybody.`, tag:'Fight', next:'fight_confirm'},
    {label:`What's the toll?`, tag:'Peace', next:'peace_confirm'},
    {label:`What if I worked with you instead?`, tag:'Corrupt', next:'corrupt_confirm'}
   ]
  },
  fight_confirm:{ who:`Kade`, text:`Wrong answer. Everybody up!`, opts:[{label:`Ready weapon.`, action:'warehouse_fight'}] },
  peace_confirm:{ who:`Kade`, text:`Smart. Hand over some of what you're carrying, and this whole floor's yours to loot in peace.`, opts:[{label:`Deal.`, action:'warehouse_peace'}] },
  corrupt_confirm:{ who:`Kade`, text:`Now that's a language I speak. Keep your mouth shut about what you see here and there's tokens in it for you.`, opts:[{label:`Wouldn't dream of it.`, action:'warehouse_corrupt'}] }
 },

 ruins_trader:{
  start:{
   who:`Milo`,
   text:`Hey, hey — good gear, good prices, no questions. Interested?`,
   opts:[
    {label:`Take a closer look at his stock.`, next:'investigate'},
    {label:`Not interested.`}
   ]
  },
  investigate:{
   who:`Milo`,
   text:`The serial numbers are filed off. The "medicine" is loose pills in a sandwich bag. This isn't salvage — it's a trap for anyone desperate enough not to look twice.`,
   opts:[
    {label:`Call him out.`, tag:'Expose', next:'expose_confirm'},
    {label:`Say nothing. Walk away.`, tag:'Ignore', next:'ignore_confirm'}
   ]
  },
  expose_confirm:{ who:`Milo`, text:`He doesn't even deny it — just shrugs and starts packing up. "Word'll get around now. Fine. Plenty other buyers in this county."`, opts:[{label:`Leave.`, action:'ruins_expose'}] },
  ignore_confirm:{ who:`Milo`, text:`He slips you a little something for keeping quiet. "Pleasure doing business. Or not doing it, in this case."`, opts:[{label:`Leave.`, action:'ruins_ignore'}] }
 },

 ghost_story:{
  start:{
   who:`???`,
   text:`Something pale moves between the headstones — there and gone, always at the edge of the flashlight beam. It doesn't attack. It doesn't flee. It just watches.`,
   opts:[ {label:`Follow it.`, next:'follow'}, {label:`Leave it alone.`} ]
  },
  follow:{
   who:`???`,
   text:`It leads you to a small, freshly-dug plot with no headstone — just a child's pillow, soaked through, laid gently on the dirt. When you look up, whatever was watching you is gone.`,
   opts:[{label:`Take the pillow. Someone should remember this.`, action:'ghost_easter_egg'}]
  }
 },

 boss_intro:{
  start:{
   who:`???`,
   text:`The access door reads DEEP LAB — RESTRICTED in stenciled amber paint. Beyond it, something huge is breathing in the dark, slow and wet and much too aware of the door opening.`,
   opts:[ {label:`This is what you came for. Go in.`, action:'start_boss'}, {label:`...Not yet.`} ]
  }
 },

 final_choice:{
  start:{
   who:`???`,
   text:`The Harrowed stops moving. Past its ruin of a body, a console still blinks, patient, waiting on a decision three days of dying never got to make: what happens to RVL-9 now.`,
   opts:[
    {label:`Burn the samples. Burn all of it.`, tag:'Good', ending:'good'},
    {label:`Take the samples. Someone will pay.`, tag:'Bad', ending:'bad'},
    {label:`Seal the lab. Walk away.`, tag:'Neutral', ending:'neutral'}
   ]
  }
 }

};

/* ---------- Companion recruitment + bonding, generated per COMPANIONS entry ---------- */
const COMPANION_FLAVOR = {
 john:    {ask:`Ask how he's really doing.`,       resp:`Honestly? Some nights I still expect the radio to say this is over. It won't. But the fence held, and that's something. Thanks for asking.`, greet:`Fence held again last night. Barely. You holding up out there?`},
 alexa:   {ask:`Ask about her old life.`,            resp:`Dad taught me to hunt before I could ride a bike. Never thought I'd be grateful for it like this.`, greet:`You've got that look — counting whether the ammo you've got will outlast the ammo you'll need.`},
 rorke:   {ask:`Ask what he did before all this.`,   resp:`Moved furniture. Big trucks, bad backs, decent pay. Nobody trains you for this. You just find out what you can carry when you have to.`, greet:`(Cleaning the SAW, not looking up.) You need something, or you just like watching a man work?`},
 nikolai: {ask:`Sit with him a while.`,               resp:`(He doesn't say much. Neither do you. It helps anyway.) This is good. We should do this again — assuming, you know. Everything.`, greet:`You look like a person who needs to sit down and not think for five minutes.`},
 dana:    {ask:`Ask what keeps her going now.`,      resp:`Keeping this crew alive. That's it, that's the whole answer. Used to pour drinks so people felt looked-after for one night. Turns out I just kept doing that.`, greet:`(Wiping down the SPAS like it's a bar top out of habit.) Don't ask me about before.`}
};

COMPANIONS.forEach(c=>{
 const flav = COMPANION_FLAVOR[c.id];
 DIALOGUES['companion_'+c.id] = {
  start:{
   who: c.name,
   text:(S)=>{
    if(S.companions.includes(c.id)) return flav.greet;
    const cost = companionRecruitCost(S.companions.length);
    if(cost===null) return `${c.name} nods at you but stays put. "Squad's full up. Camp needs me right where I am."`;
    const unit = cost.type==='karma' ? 'Karma' : 'Tokens';
    const have = cost.type==='karma' ? S.karma : S.tokens;
    if(have >= cost.amount) return `${c.name} looks you over. "Word gets around, you know — about what you do out there. I'd follow that." (Costs ${cost.amount} ${unit} — you have ${have})`;
    return `${c.name} shrugs. "Ask me again once you've done more good out there than harm." (Needs ${cost.amount} ${unit} — you have ${have})`;
   },
   opts:[
    {label:flav.ask, trust:1, next:'response', showIf:(S)=>S.companions.includes(c.id)},
    {label:(S)=>{ const cost=companionRecruitCost(S.companions.length); const unit=cost.type==='karma'?'Karma':'Tokens'; return `Recruit them (−${cost.amount} ${unit})`; }, action:'recruit_'+c.id, showIf:(S)=>{
      const cost = companionRecruitCost(S.companions.length);
      if(!cost) return false;
      const have = cost.type==='karma' ? S.karma : S.tokens;
      return !S.companions.includes(c.id) && have>=cost.amount;
     }},
    {label:`Nothing right now.`}
   ]
  },
  response:{
   who:c.name, text:flav.resp,
   opts:[{label:`Take care of yourself.`}]
  }
 };
});

/* ---------- SURVIVOR QUEST-GIVERS (generated per SURVIVOR_NPCS entry) ---------- */
SURVIVOR_NPCS.forEach(n=>{
 DIALOGUES['survivor_'+n.id] = {
  start:{
   who: n.name,
   text:(S)=> S.flags['survivor_done_'+n.id] ? n.doneText : n.askText,
   opts:[
    {label:`Good to see a friendly face.`, action:'survivor_meet_'+n.id, cha:1, showIf:(S)=>!S.flags['survivor_met_'+n.id]},
    {label:`Here — ${n.want.label}.`, action:'survivor_turnin_'+n.id, showIf:(S)=> !S.flags['survivor_done_'+n.id]},
    {label:`Not yet. I'll keep an eye out.`, showIf:(S)=> !S.flags['survivor_done_'+n.id]},
    {label:`Take care of yourself.`, showIf:(S)=> !!S.flags['survivor_done_'+n.id]}
   ]
  }
 };
});

/* ---------- MILITARY BLOCKADE TRADER ---------- */
DIALOGUES.blockade_trader = {
 start:{
  who:`Quartermaster Voss`,
  text:`Guns and ammunition, that's the whole inventory — Blockade command doesn't authorize me to carry anything else. If it fires a round, I can probably get you one.`,
  opts:[
   {label:`Let's see the armory.`, action:'open_trade_blockade'},
   {label:`Just passing through.`}
  ]
 }
};
