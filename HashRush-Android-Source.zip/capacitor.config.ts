import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hashrush.cryptoempire',
  appName: 'HashRush',
  webDir: 'www',
  backgroundColor: '#0a0a0c',
  android: {
    backgroundColor: '#0a0a0c'
  }
};

export default config;
