package com.hashrush.cryptoempire;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
